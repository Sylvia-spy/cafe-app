import { UserService } from "./../services/user.service";
import { Request, Response, Router } from "express";
import { AdminProfileService } from "../services/adminProfile.service";
import { getJWTPayload } from "../jwt";
import { array, int, object, string } from "cast.ts";

export class AdminProfileController {
  router = Router();

  constructor(
    private adminProfileService: AdminProfileService,
    private userService: UserService
  ) {
    this.router.get("/admin/profile", this.showCafeProfile);
    this.router.patch("/admin/shop/basicInformation", this.editBasicInfo);
    this.router.patch("/admin/shop/operationTime", this.editOperationTime);
    this.router.patch("/admin/shop/features", this.editFeatures);
  }

  //////////////////////////////////admin show profile//////////////////////////////////
  showCafeProfile = async (req: Request, res: Response) => {
    try {
      let user_id = getJWTPayload(req).id;
      let shop_id = await this.userService.findShopByUserId(user_id);
      let json = await this.adminProfileService.getCafeProfile(shop_id);
      res.json(json);
    } catch (e: any) {
      console.log(e);
      res.status(e.statusCode || 500).json({ error: String(e) });
    }
  };

  //////////////////////////////////admin update basic information//////////////////////////////////
  editBasicInfo = async (req: Request, res: Response) => {
    try {
      let user_id = getJWTPayload(req).id;
      let shop_id = await this.userService.findShopByUserId(user_id);
      let parser = object({
        body: object({
          name: string(),
          address: string(),
          tel: string(),
          instagram: string(),
          facebook: string(),
        }),
      });
      let basicInfo = parser.parse(req).body;
      let json = await this.adminProfileService.updateBasicInfo(
        shop_id,
        basicInfo
      );
      res.json(json);
    } catch (e: any) {
      console.log(e);
      res.status(e.statusCode || 500).json({ error: String(e) });
    }
  };
  //////////////////////////////////admin update operation time//////////////////////////////////
  editOperationTime = async (req: Request, res: Response) => {
    try {
      let user_id = getJWTPayload(req).id;
      let shop_id = await this.userService.findShopByUserId(user_id);
      let parser = object({
        body: array(
          object({
            weekday: int({ min: 0, max: 6 }),
            start_time: string(),
            end_time: string(),
          })
        ),
      });
      let openingHours = parser.parse(req).body;
      let json = await this.adminProfileService.updateOperationTime(
        shop_id,
        openingHours
      );
      res.json(json);
    } catch (e: any) {
      console.log(e);
      res.status(e.statusCode || 500).json({ error: String(e) });
    }
  };
  //////////////////////////////////admin update features//////////////////////////////////

  editFeatures = async (req: Request, res: Response) => {
    try {
      let user_id = getJWTPayload(req).id;
      let shop_id = await this.userService.findShopByUserId(user_id);
      let parser = object({
        body: array(string()),
      });
      let features = parser.parse(req).body;
      let json = await this.adminProfileService.updateFeatures(
        shop_id,
        features
      );
      res.json(json);
    } catch (e: any) {
      console.log(e);
      res.status(e.statusCode || 500).json({ error: String(e) });
    }
  };
}
