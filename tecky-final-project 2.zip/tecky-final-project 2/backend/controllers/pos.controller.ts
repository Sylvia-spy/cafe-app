import { Router } from "express";
import { PosService } from "../services/pos.service";
import { getJWTPayload } from "../jwt";
import { array, id, int, object } from "cast.ts";

export class PosController {
  public router = Router();

  constructor(public posService: PosService) {
    //-----------------GET CafeMenu
    this.router.get("/shops/:id/menuList", async (req, res, next) => {
      try {
        let { id } = req.params;
        let json = await this.posService.getCafeMenu(id);
        res.json(json);
      } catch (error) {
        console.log(error);
        next(error);
      }
    });
    //-----------------POST myOrder
    this.router.post("/postMyOrder", async (req, res, next) => {
      try {
        let user_id = getJWTPayload(req).id;
        // let user_id = 46;
        let parser = object({
          body: array(
            object({
              variants_id: id(),
              count: int({ min: 1 }),
            })
          ),
        });
        const orderItems = parser.parse(req).body;

        let json = await this.posService.postOrder(orderItems, user_id);
        res.json(json);
        console.log("res.json(json) : ", json);
      } catch (error) {
        next(error);
      }
    });
    //------------- status : New to  Reject-----------
    this.router.post("/updateOrderStatusToReject", async (req, res, next) => {
      try {
        const order_id = req.body.order_id;
        let json = await this.posService.updateOrderStatusToReject(order_id);
        console.log("res.json(json) : ", json);
        res.status(200).json(json);
      } catch (error) {
        console.log(error);
        next(error);
      }
    });
    //------------- status : Pending to  New-----------
    this.router.post("/updateOrderStatusToNew", async (req, res, next) => {
      try {
        const order_id = req.body.order_id;
        let json = await this.posService.updateOrderStatusToNew(order_id);
        console.log("res.json(json) : ", json);
        res.status(200).json(json);
      } catch (error) {
        console.log(error);
        next(error);
      }
    });

    //------------- status : New to Pending -----------
    this.router.post("/updateOrderStatusToPending", async (req, res, next) => {
      try {
        const order_id = req.body.order_id;
        let json = await this.posService.updateOrderStatusToPending(order_id);
        console.log("res.json(json) : ", json);
        res.status(200).json(json);
      } catch (error) {
        console.log(error);
        next(error);
      }
    });

    //------------- status : Pending to Finished -----------
    this.router.post("/updateOrderStatusToFinished", async (req, res, next) => {
      try {
        const order_id = req.body.order_id;
        let json = await this.posService.updateOrderStatusToFinished(order_id);
        res.json(json);
        console.log("res.json(json) : ", json);
      } catch (error) {
        console.log(error);
        next(error);
      }
    });
    //------------- status : Finished to Received -----------
    this.router.post("/updateOrderStatusToReceived", async (req, res, next) => {
      try {
        const order_id = req.body.order_id;
        let json = await this.posService.updateOrderStatusToReceived(order_id);
        res.json(json);
        console.log("res.json(json) : ", json);
      } catch (error) {
        console.log(error);
        next(error);
      }
    });

    //-----------------GET myOrder
    this.router.get("/myOrder", async (req, res, next) => {
      try {
        let JWT = getJWTPayload(req);
        let json = await this.posService.getOrderByUser(JWT.id);
        res.json(json);
        console.log("res.json(json) : ", json);
      } catch (error) {
        console.log(error);
        next(error);
      }
    });

    //-----------------admin Page myOrder

    this.router.get("/admin/getNewOrder", async (req, res, next) => {
      try {
        let JWT = getJWTPayload(req);
        let json = await this.posService.getOrderByShop(JWT.id);

        console.log("JSON", json);

        return res.status(200).json(json);
      } catch (error) {
        console.log(error);
        return next(error);
      }
    });
  }
}
