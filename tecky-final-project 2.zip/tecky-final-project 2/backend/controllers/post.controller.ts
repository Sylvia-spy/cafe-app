import { PostService } from "./../services/post.service";
import { Request, Response, Router } from "express";
import { HttpError } from "../http.error";
import { getJWTPayload } from "../jwt";
import { form } from "../uploads";
import { array, object, string } from "cast.ts";
import { UserService } from "../services/user.service";

export class PostController {
  router = Router();

  constructor(
    private postService: PostService,
    private userService: UserService
  ) {
    this.router.post("/admin/shop/posts", this.addNewPost);
    this.router.get("/admin/getAllPost", this.showAllPost);
    this.router.delete("/admin/post/:id", this.deletePost);
  }

  //////////////////////////////////admin add new post//////////////////////////////////
  addNewPost_demo = (req: Request, res: Response) => {
    form.parse(req, async (err, fields, files) => {
      try {
        if (err) throw err;

        let user_id = getJWTPayload(req).id;
        let shop_id = await this.userService.findShopByUserId(user_id);

        let file = Array.isArray(files.image) ? files.image[0] : files.image;
        let image = file?.newFilename;

        let title = Array.isArray(fields.title)
          ? fields.title[0]
          : fields.title;

        let content = Array.isArray(fields.content)
          ? fields.content[0]
          : fields.content;

        if (!shop_id) throw new HttpError(400, "missing shop ID");
        if (!image) throw new HttpError(400, "missing image");
        if (!title) throw new HttpError(400, "missing title");
        if (!content) throw new HttpError(400, "missing content");

        const json = await this.postService.addNewPost(user_id, {
          shop_id,
          image,
          title,
          content,
        });

        res.json(json);
      } catch (e: any) {
        console.log(e);
        res.status(e.statusCode || 500).json({ error: String(e) });
      }
    });
  };
  addNewPost = (req: Request, res: Response) => {
    form.parse(req, async (err, fields, files) => {
      try {
        if (err) throw err;

        // console.log({ fields, files });

        let user_id = getJWTPayload(req).id;
        let shop_id = await this.userService.findShopByUserId(user_id);

        let parser = object({
          // req: object({
          //   params: object({
          //     id: id(),
          //   }),
          // }),
          fields: object({
            title: string({ trim: true, minLength: 3, maxLength: 255 }),
            content: string({ trim: true, minLength: 3, maxLength: 255 }),
          }),
          files: object({
            image: array(
              object({
                newFilename: string(),
              }),
              { maybeSingle: true, minLength: 1 }
            ),
          }),
        });

        let input = parser.parse({ req, fields, files });

        const json = await this.postService.addNewPost(user_id, {
          shop_id,
          image: input.files.image[0].newFilename,
          title: input.fields.title,
          content: input.fields.content,
        });

        res.json(json);
      } catch (e: any) {
        console.log(e);
        res.status(e.statusCode || 500).json({ error: String(e) });
      }
    });
  };

  //////////////////////////////////admin show all post//////////////////////////////////
  showAllPost = async (req: Request, res: Response) => {
    try {
      let user_id = getJWTPayload(req).id;
      let shop_id = await this.userService.findShopByUserId(user_id);
      console.log({ user_id, shop_id });
      let json = await this.postService.showAllPost(shop_id);
      res.json(json);
    } catch (e: any) {
      console.log(e);
      res.status(e.statusCode || 500).json({ error: String(e) });
    }
  };
  //////////////////////////////////admin delete post//////////////////////////////////
  deletePost = async (req: Request, res: Response) => {
    try {
      //post_id 係frd 個params
      let post_id = +req.params.id;
      // console.log(post_id);
      //經jwt攞id
      let user_id = getJWTPayload(req).id;
      //{ post_id, user_id } 對番service
      let json = await this.postService.deletePost({ post_id, user_id });
      res.json(json);
    } catch (e: any) {
      console.log(e);
      res.status(e.statusCode || 500).json({ error: String(e) });
    }
  };
}
