//get method set up (Step 2: edit shop.controller.ts)

import { Router } from "express";
import { ShopService } from "../services/shop.service";
import "cast.ts";
import { array, object, optional, string } from "cast.ts";

export class ShopController {
  public router = Router();

  constructor(public shopService: ShopService) {
    //home page: shop post
    this.router.get("/home/recent/posts", async (req, res, next) => {
      try {
        let json = await this.shopService.getCafePost();
        res.json(json);
      } catch (error) {
        next(error);
      }
    });

    //home page: new shop array
    this.router.get("/home/recent/shops", async (req, res, next) => {
      try {
        let json = await this.shopService.getNewShop();
        res.json(json);
      } catch (error) {
        next(error);
      }
    });

    //all cafe info page: shop list
    this.router.get("/shops", async (req, res, next) => {
      try {
        // console.log("query.feature:", req.query.feature);
        let checker = object({
          query: object({
            feature: optional(array(string(), { maybeSingle: true })),
          }),
        });
        let features = checker.parse(req).query.feature || [];
        // console.log("features:", features);
        let json = await this.shopService.getShopList(features);
        res.json(json);
      } catch (error) {
        console.log(error);

        next(error);
      }
    });

    //all cafe info page: shop list + id?
    this.router.get("/shops/:id", async (req, res, next) => {
      try {
        let { id } = req.params;
        let json = await this.shopService.getShopDetail(id);

        res.json(json);
      } catch (error) {
        // console.log(error);

        next(error);
      }
    });

    //map page: get shop address and latlng
    this.router.get("/map", async (req, res, next) => {
      try {
        let json = await this.shopService.getCafeLatLng();
        res.json(json);
      } catch (error) {
        next(error);
      }
    });
  }
}
