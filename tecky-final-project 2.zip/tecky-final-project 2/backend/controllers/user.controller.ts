//controller係驗證frd比我嘅野有無錯, 事後嘅野就service做
//盡量一個db table 做哂係同一個controller同service到
import { UserService } from "./../services/user.service";
import { Request, Response } from "express";
import { getJWTPayload } from "../jwt";
import { HttpError } from "../http.error";

export class UserController {
  constructor(private userService: UserService) {}

  //////////////////////////////////register part: step 1-3//////////////////////////////////
  register = async (req: Request, res: Response) => {
    try {
      const { user_name, phone, gender, birth_date, hashed_pw, email } =
        req.body;
      //step 1: 驗證frd有無比漏野
      if (!user_name) throw new HttpError(400, "missing user_name");
      if (!phone) throw new HttpError(400, "missing phone number");
      if (!gender) throw new HttpError(400, "missing gender");
      if (!birth_date) throw new HttpError(400, "missing birth_date");
      if (!hashed_pw) throw new HttpError(400, "missing hashed_pw");
      if (!email) throw new HttpError(400, "missing email");

      //step 2: 攞番service return出嚟嘅野
      const json = await this.userService.register({
        user_name,
        phone,
        gender,
        birth_date,
        hashed_pw,
        email,
      });

      //step 3: 把json比番frd
      res.json(json);
    } catch (e: any) {
      console.log(e);
      res.status(e.statusCode || 500).json({ error: String(e) });
    }
  };

  //////////////////////////////////login part: step 1-3//////////////////////////////////
  login = async (req: Request, res: Response) => {
    try {
      const { user_name, hashed_pw } = req.body;

      console.log(req.body);

      //step 1: 驗證frd有無比漏野
      if (!user_name) throw new HttpError(400, "missing user_name");
      if (!hashed_pw) throw new HttpError(400, "missing password");

      //step 2: 攞番service return出嚟嘅野
      //{ user_name, password }呢個名要對番service嘅input
      const json = await this.userService.login({
        user_name,
        password: hashed_pw,
      });

      //step 3: 把json比番frd
      res.json(json);
    } catch (e: any) {
      console.log(e);
      //因為service啲error code儲哂係http.error.ts嘅Error到
      //用e.statusCode會自動throw code, 無先比500
      //唔好用error: e.toString(), 因db爆error係null就做唔到toString
      res.status(e.statusCode || 500).json({ error: String(e) });
    }
  };

  //////////////////////////////////profile part: step 1-3//////////////////////////////////
  getProfile = async (req: Request, res: Response) => {
    try {
      let payload = getJWTPayload(req);
      //攞token個id
      let user_id = payload.id;

      //step 2: 攞番service return出嚟嘅野
      let json = await this.userService.getProfile(user_id);

      //step 3: 把json比番frd
      res.json(json);
    } catch (e: any) {
      console.log(e);
      res.status(e.statusCode || 500).json({ error: String(e) });
    }
  };
}
