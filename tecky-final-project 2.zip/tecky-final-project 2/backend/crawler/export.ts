import { unProxy } from "better-sqlite3-proxy";
import { proxy } from "../proxy";
import Knex from "knex";

let knex = Knex(require("../knexfile").production);

let shops = unProxy(proxy.shop);
console.log(shops);
// await knex('shop').insert(shops)

async function migrateTable(table: keyof typeof proxy) {
  for (let row of proxy[table]) {
    row = unProxy(row);
    if (await knex.select("id").from(table).where("id", row.id).first()) {
      await knex(table).update(row);
    } else {
      await knex(table).insert(row);
    }
  }
}

async function migrate() {
  await migrateTable("district");
  await migrateTable("shop");
}

migrate();
