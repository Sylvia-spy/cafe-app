import { readFileSync } from "fs";
import { Shop, WeeklyOperationPeriod, proxy } from "../proxy";
import { find } from "better-sqlite3-proxy";

type FeatureName = 'bean_for_sale' | 'milk_choices' | 'decaf' | 'awarded' | 'tables_seats' | 'outdoor' | 'bright' | 'socket' | 'wifi' | 'parking' | 'washroom' | 'CBD' | 'vibes' | 'pets_friendly' | 'pets_in_store' | 'BYOC' | 'meals' | 'sweets_bites' | 'vegan' | 'vegetarian'

type Data = {
    images?: {
        mapValue?: {
            fields?: {
                logo?: { stringValue: string }
                thumbnail?: { stringValue: string }
            }
        }
    },
    basicProfile?: {
        mapValue?: {
            fields?: {
                name?: { stringValue: string }
                address?: { stringValue: string }
                navigation_tip?: { stringValue: string }
                ig?: { stringValue: string }
                fb?: { stringValue: string }
                phone?: { stringValue: string }
                region3?: { stringValue: string }
                lat?: { doubleValue: number }
                long?: { doubleValue: number }
                open_hours?: {
                    mapValue?: {
                        fields?: {
                            tuesday_begin: { integerValue: string },
                            wednesday: { booleanValue: boolean },
                            friday: { booleanValue: boolean },
                            sunday_end: { integerValue: string },
                            thursday_begin: { integerValue: string },
                            saturday_begin: { integerValue: string },
                            sunday_begin: { integerValue: string },
                            monday_end: { integerValue: string },
                            thursday_end: { integerValue: string },
                            monday_begin: { integerValue: string },
                            tuesday_end: { integerValue: string },
                            monday: { booleanValue: boolean },
                            saturday: { booleanValue: boolean },
                            tuesday: { booleanValue: boolean },
                            saturday_end: { integerValue: string },
                            thursday: { booleanValue: boolean },
                            wednesday_begin: { integerValue: string },
                            wednesday_end: { integerValue: string },
                            public_holiday: { booleanValue: boolean },
                            friday_end: { integerValue: string },
                            sunday: { booleanValue: boolean },
                            friday_begin: { integerValue: string }
                        }
                    }
                }
            }
        }
    },
    toggles?: {
        mapValue?: {
            fields?: {
                meals?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                byoc?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                pets_in_store?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                milk?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                parking?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                sockets?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                cbd?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                bean4sale?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                tables?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                bites?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                vibes?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                awarded_barista?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                vege?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                vegan?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                washroom?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                outdoor?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                pets_friendly?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                bright?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                wifi?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                },
                decaf?: {
                    mapValue?: {
                        fields?: {
                            on?: { booleanValue: boolean }
                        }
                    }

                }
            }
        }

    }
}[]

export function extractCafeProfile(data: Data) {
    for (let item of data) {

        let name = item.basicProfile?.mapValue?.fields?.name?.stringValue

        let instagram = item.basicProfile?.mapValue?.fields?.ig?.stringValue || null
        let facebook = item.basicProfile?.mapValue?.fields?.fb?.stringValue || null
        let tel = item.basicProfile?.mapValue?.fields?.phone?.stringValue || null
        let address = item.basicProfile?.mapValue?.fields?.address?.stringValue || null
        let lat = item.basicProfile?.mapValue?.fields?.lat?.doubleValue || null
        let long = item.basicProfile?.mapValue?.fields?.long?.doubleValue || null
        let avatar = item.images?.mapValue?.fields?.logo?.stringValue || null
        let navigation_tip = item.basicProfile?.mapValue?.fields?.navigation_tip?.stringValue || null
        let thumbnail = item.images?.mapValue?.fields?.thumbnail?.stringValue || null

        let district_name = address?.match(/, ([\w ]+), Hong Kong/)?.[1] || null
        let district_code = item.basicProfile?.mapValue?.fields?.region3?.stringValue

        if (!name || !lat || !long || !district_code) continue

        let latlng = `${lat},${long}`

        // console.log('>', address, '<')
        // console.log({ district: district_name })

        let district_id = find(proxy.district, { code: district_code })?.id || proxy.district.push({
            code: district_code,
            name: district_name
        })

        let shop: Shop = {
            name,
            latlng,
            tel,
            bean: null,
            instagram,
            facebook,
            avatar,
            address,
            district_id,
            navigation_tip,
            thumbnail,
        }

        let shop_id = find(proxy.shop, { name })?.id || proxy.shop.push(shop)
        proxy.shop[shop_id] = shop

        //to extract cafe background image into shop_image table

        // let ds = item.bookmarks?.mapValue?.fields?.residue?.arrayValue?.values?.map(v => v.stringValue)
        // console.log({ ds })


        let open_hours = item.basicProfile?.mapValue?.fields?.open_hours?.mapValue?.fields

        // console.log(open_hours)


        function extractOpenHours(name: string, weekday: number) {
            let o = open_hours as any
            if (o?.[name].booleanValue) {

                let period: WeeklyOperationPeriod = {
                    shop_id,
                    weekday,
                    start_time: intToTime(+o[name + '_begin'].integerValue),
                    end_time: intToTime(+o[name + '_end'].integerValue)
                }
                let period_id = find(proxy.weekly_operation_period, { shop_id, weekday })?.id || proxy.weekly_operation_period.push(period)
                proxy.weekly_operation_period[period_id] = period
            } else {
                let id = find(proxy.weekly_operation_period, { shop_id, weekday })?.id
                if (id) {
                    delete proxy.weekly_operation_period[id]
                }
            }
        }
        let weekdays = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']

        weekdays
            .forEach((name, weekday) => {
                extractOpenHours(name, weekday)
            })

        // if (open_hours.sunday.booleanValue) {
        //     let weekday = 0
        //     let period: WeeklyOperationPeriod = {
        //         shop_id,
        //         weekday,
        //         start_time: intToTime(+open_hours.sunday_begin.integerValue),
        //         end_time: intToTime(+open_hours.sunday_end.integerValue)
        //     }
        //     let period_id = find(proxy.weekly_operation_period, { shop_id, weekday })?.id || proxy.weekly_operation_period.push(period)
        //     proxy.weekly_operation_period[period_id] = period
        // }
        // if (open_hours.monday.booleanValue) {
        //     let weekday = 1
        //     let period: WeeklyOperationPeriod = {
        //         shop_id,
        //         weekday,
        //         start_time: intToTime(+open_hours.monday_begin.integerValue),
        //         end_time: intToTime(+open_hours.monday_begin.integerValue)
        //     }
        //     // knex('week').insert(period).returning('id')
        //     let period_id = find(proxy.weekly_operation_period, { shop_id, weekday })?.id || proxy.weekly_operation_period.push(period)
        //     proxy.weekly_operation_period[period_id] = period
        // }

        // if (open_hours.tuesday.booleanValue) {
        //     let weekday = 2
        //     let period: WeeklyOperationPeriod = {
        //         shop_id,
        //         weekday,
        //         start_time: intToTime(+open_hours.tuesday_begin.integerValue),
        //         end_time: intToTime(+open_hours.tuesday_begin.integerValue)
        //     }
        //     // knex('week').insert(period).returning('id')
        //     let period_id = find(proxy.weekly_operation_period, { shop_id, weekday })?.id || proxy.weekly_operation_period.push(period)
        //     proxy.weekly_operation_period[period_id] = period
        // }
        // if (open_hours.wednesday.booleanValue) {
        //     let weekday = 3
        //     let period: WeeklyOperationPeriod = {
        //         shop_id,
        //         weekday,
        //         start_time: intToTime(+open_hours.wednesday_begin.integerValue),
        //         end_time: intToTime(+open_hours.wednesday_begin.integerValue)
        //     }
        //     // knex('week').insert(period).returning('id')
        //     let period_id = find(proxy.weekly_operation_period, { shop_id, weekday })?.id || proxy.weekly_operation_period.push(period)
        //     proxy.weekly_operation_period[period_id] = period
        // }
        // if (open_hours.thursday.booleanValue) {
        //     let weekday = 4
        //     let period: WeeklyOperationPeriod = {
        //         shop_id,
        //         weekday,
        //         start_time: intToTime(+open_hours.thursday_begin.integerValue),
        //         end_time: intToTime(+open_hours.thursday_begin.integerValue)
        //     }
        //     // knex('week').insert(period).returning('id')
        //     let period_id = find(proxy.weekly_operation_period, { shop_id, weekday })?.id || proxy.weekly_operation_period.push(period)
        //     proxy.weekly_operation_period[period_id] = period
        // }
        // if (open_hours.friday.booleanValue) {
        //     let weekday = 5
        //     let period: WeeklyOperationPeriod = {
        //         shop_id,
        //         weekday,
        //         start_time: intToTime(+open_hours.friday_begin.integerValue),
        //         end_time: intToTime(+open_hours.friday_begin.integerValue)
        //     }
        //     // knex('week').insert(period).returning('id')
        //     let period_id = find(proxy.weekly_operation_period, { shop_id, weekday })?.id || proxy.weekly_operation_period.push(period)
        //     proxy.weekly_operation_period[period_id] = period
        // }
        // if (open_hours.saturday.booleanValue) {
        //     let weekday = 6
        //     let period: WeeklyOperationPeriod = {
        //         shop_id,
        //         weekday,
        //         start_time: intToTime(+open_hours.saturday_begin.integerValue),
        //         end_time: intToTime(+open_hours.saturday_begin.integerValue)
        //     }
        //     // knex('week').insert(period).returning('id')
        //     let period_id = find(proxy.weekly_operation_period, { shop_id, weekday })?.id || proxy.weekly_operation_period.push(period)
        //     proxy.weekly_operation_period[period_id] = period
        // }




        //to get the features of cafe
        function extractFeature(
            featureName: FeatureName,
            hasFeature: boolean | undefined

        ) {
            let feature_id = find(proxy.feature, { name: featureName })?.id || proxy.feature.push({ name: featureName })
            if (hasFeature) {
                find(proxy.shop_feature, { shop_id, feature_id })?.id || proxy.shop_feature.push({ shop_id, feature_id })

            } else {
                let id = find(proxy.shop_feature, { shop_id, feature_id })?.id
                if (id) {
                    delete proxy.shop_feature[id]
                }
            }
        }

        extractFeature('meals', item.toggles?.mapValue?.fields?.meals?.mapValue?.fields?.on?.booleanValue)
        extractFeature('BYOC', item.toggles?.mapValue?.fields?.byoc?.mapValue?.fields?.on?.booleanValue)
        extractFeature('pets_in_store', item.toggles?.mapValue?.fields?.pets_in_store?.mapValue?.fields?.on?.booleanValue)
        extractFeature('milk_choices', item.toggles?.mapValue?.fields?.milk?.mapValue?.fields?.on?.booleanValue)
        extractFeature('parking', item.toggles?.mapValue?.fields?.parking?.mapValue?.fields?.on?.booleanValue)
        extractFeature('socket', item.toggles?.mapValue?.fields?.sockets?.mapValue?.fields?.on?.booleanValue)
        extractFeature('CBD', item.toggles?.mapValue?.fields?.cbd?.mapValue?.fields?.on?.booleanValue)
        extractFeature('bean_for_sale', item.toggles?.mapValue?.fields?.bean4sale?.mapValue?.fields?.on?.booleanValue)
        extractFeature('tables_seats', item.toggles?.mapValue?.fields?.tables?.mapValue?.fields?.on?.booleanValue)
        extractFeature('sweets_bites', item.toggles?.mapValue?.fields?.bites?.mapValue?.fields?.on?.booleanValue)
        extractFeature('vibes', item.toggles?.mapValue?.fields?.vibes?.mapValue?.fields?.on?.booleanValue)
        extractFeature('awarded', item.toggles?.mapValue?.fields?.awarded_barista?.mapValue?.fields?.on?.booleanValue)
        extractFeature('vegetarian', item.toggles?.mapValue?.fields?.vege?.mapValue?.fields?.on?.booleanValue)
        extractFeature('vegan', item.toggles?.mapValue?.fields?.vegan?.mapValue?.fields?.on?.booleanValue)
        extractFeature('washroom', item.toggles?.mapValue?.fields?.washroom?.mapValue?.fields?.on?.booleanValue)
        extractFeature('outdoor', item.toggles?.mapValue?.fields?.outdoor?.mapValue?.fields?.on?.booleanValue)
        extractFeature('pets_friendly', item.toggles?.mapValue?.fields?.pets_friendly?.mapValue?.fields?.on?.booleanValue)
        extractFeature('bright', item.toggles?.mapValue?.fields?.bright?.mapValue?.fields?.on?.booleanValue)
        extractFeature('wifi', item.toggles?.mapValue?.fields?.wifi?.mapValue?.fields?.on?.booleanValue)
        extractFeature('bright', item.toggles?.mapValue?.fields?.bright?.mapValue?.fields?.on?.booleanValue)
        extractFeature('decaf', item.toggles?.mapValue?.fields?.decaf?.mapValue?.fields?.on?.booleanValue)



    }







}

function intToTime(int: number) {
    let min = int % 60
    let hour = (int - min) / 60
    let time = `${d2(hour)}:${d2(min)}:00`
    return time
}
function d2(x: number) {
    return x < 10 ? '0' + x : x
}

let json = JSON.parse(readFileSync('data/cafes_fullProfile.json').toString())

extractCafeProfile(json)