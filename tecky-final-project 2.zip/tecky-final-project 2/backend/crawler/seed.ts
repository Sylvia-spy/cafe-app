// import { knex } from "../knex";
import { proxy } from "../proxy";

proxy.district[1] = {
  name: "adasd",
  code: "cc",
};

proxy.shop[1] = {
  name: "cafe shop",
  latlng: "123,456",
  tel: "98765432",
  bean: "choco toy",
  instagram: "toya",
  facebook: "dasd",
  avatar: "dsa",
  address: "asd",
  district_id: 1,
  navigation_tip: null,
  thumbnail: null,
};

console.log(proxy.shop[1].district?.name);

delete proxy.shop[1];
delete proxy.district[1];

for (let district of proxy.district) {
  // await knex('district').insert({
  //     id: district.id,
  //     name: district.name
  // })
  console.log({
    id: district.id,
    name: district.name,
  });
}
