INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		2,
		'Quarry Bay',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'hk_ea_qb'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		3,
		'North Point',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'hk_ea_np'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		4,
		'Wan Chai',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'hk_wc_wc'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		5,
		'Central',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'hk_caw_ct'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		6,
		'Tsim Sha Tsui',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'kl_ytm_tst'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		7,
		'Lantau Island',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'nt_is_li'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		8,
		'Sham Shui Po',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'kl_ssp_ssp'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		9,
		'Tseung Kwan O',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'nt_sk_two'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		10,
		'Causeway Bay',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'hk_wc_cwb'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		11,
		'San Po Kong',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'kl_wts_spk'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		12,
		'Tai Po',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'nt_tp_tp'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		13,
		'Kennedy Town',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'hk_caw_kt'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		14,
		'Fanling',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'nt_nor_fl'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		15,
		'Causeway Bay',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'hk_ea_th'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		16,
		'Sai Ying Pun',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'hk_caw_syp'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		17,
		'Kwai Chung',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'nt_kt_kc'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		18,
		'Kowloon',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'kl_ssp_csw'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		19,
		'Tuen Mun',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'nt_tm_tm'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		20,
		'Kowloon',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'kl_kt_kt'
	);
INSERT INTO "district" ("id", "name", "created_at", "updated_at", "code")
VALUES (
		21,
		'Sai Kung',
		'2023-01-16 15:21:17',
		'2023-01-16 15:21:17',
		'nt_sk_sk'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		1,
		'meals',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		2,
		'BYOC',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		3,
		'pets_in_store',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		4,
		'milk_choices',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		5,
		'parking',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		6,
		'socket',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		7,
		'CBD',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		8,
		'bean_for_sale',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		9,
		'tables_seats',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		10,
		'sweets_bites',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		11,
		'vibes',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		12,
		'awarded',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		13,
		'vegetarian',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		14,
		'vegan',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		15,
		'washroom',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		16,
		'outdoor',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		17,
		'pets_friendly',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		18,
		'bright',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		19,
		'wifi',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "feature" ("id", "name", "created_at", "updated_at")
VALUES (
		20,
		'decaf',
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		2,
		'Affee - Quarry Bay',
		'22.28766,114.2107',
		'63792755',
		NULL,
		'affeehk',
		'affeehk',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FwWNbJ1GCSoTxhJaFi7VAPlzFfwI2%2FprofileImages%2FwWNbJ1GCSoTxhJaFi7VAPlzFfwI2.logo_trans.png?alt=media&token=68fcfd77-80e2-4c7a-b735-aec6632de8ec',
		'Shop 2, G/F, 36 Hoi Kwong Street, Quarry Bay, Hong Kong
香港鰂魚涌海光街36號地下2號鋪',
		2,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'Exit A, Quarry Bay MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FwWNbJ1GCSoTxhJaFi7VAPlzFfwI2%2FprofileImages%2FwWNbJ1GCSoTxhJaFi7VAPlzFfwI2.thumbnail.png?alt=media&token=376fbd16-fe0d-4a14-9138-831feaebbdee'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		3,
		'Nutsy Coffee Bar - Hoi Kwong Street',
		'22.28767,114.21077',
		'92452747',
		NULL,
		'nutsycoffee',
		'nutsycoffee',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FS3RVy1KPDtOixfa0B4f6sZWXzgl1%2FprofileImages%2FS3RVy1KPDtOixfa0B4f6sZWXzgl1.logo_trans.png?alt=media&token=8939cea9-62a6-423d-88ec-15fe8eec1f9e',
		'G/F, 32 Hoi Kwong Street, Quarry Bay, Hong Kong
香港鰂魚涌海光街32號地下',
		2,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'Exit A, Quarry Bay MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FS3RVy1KPDtOixfa0B4f6sZWXzgl1%2FprofileImages%2FS3RVy1KPDtOixfa0B4f6sZWXzgl1.thumbnail.png?alt=media&token=06b6ba57-54b3-4532-99a1-a5889cac82db'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		4,
		'Hap Coffee - North Point',
		'22.29269,114.20169',
		'9555 9301',
		NULL,
		'hapcoffeehk',
		'hapcoffeehk',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2F3vEcE8FWZgfL04bOiqn8b8igWL92%2FprofileImages%2F3vEcE8FWZgfL04bOiqn8b8igWL92.logo_trans.png?alt=media&token=da21f2c7-c120-44dc-9954-e95982562da1',
		'G25, G/F, Phase 3, Harbour North, 133 Java Road, North Point, Hong Kong
香港北角渣華道133號北角匯三期地下G25號舖',
		3,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'Exit A1, North Point MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2F3vEcE8FWZgfL04bOiqn8b8igWL92%2FprofileImages%2F3vEcE8FWZgfL04bOiqn8b8igWL92.thumbnail.png?alt=media&token=e68ccdb9-8661-4c17-ad56-8260c505bd2e'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		5,
		'A Basic Coffee Production ABCP',
		'22.27565,114.17136',
		'61581040',
		NULL,
		'a.basic.coffee.production',
		NULL,
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2F1VE1jV5yLkdjJggubqv29guG6QL2%2FprofileImages%2F1VE1jV5yLkdjJggubqv29guG6QL2.logo_trans.png?alt=media&token=bf50ca53-dd0d-4968-b853-7d27fb024ac7',
		'G/F, 3 Ming Yan Lane, Wan Chai, Hong Kong
香港灣仔明仁里3號地下',
		4,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'Exit D, Wan Chai MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2F1VE1jV5yLkdjJggubqv29guG6QL2%2FprofileImages%2F1VE1jV5yLkdjJggubqv29guG6QL2.thumbnail.png?alt=media&token=5dadc35d-cd01-482a-bf43-efd32dfe421d'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		6,
		'As Usual Cafe',
		'22.28354,114.15425',
		'27579878',
		NULL,
		'asusual_cafe',
		'nn.asusualcafe',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FmO1zG7CCMrdpOed83UbLoir6fIx1%2FprofileImages%2FmO1zG7CCMrdpOed83UbLoir6fIx1.logo_trans.png?alt=media&token=109781d3-3fe1-4819-a66e-b9d9fd6a9e6f',
		'2D, 2/F, Welley Building, 97 Wellington Street, Central, Hong Kong
香港中環威靈頓街97號威利大廈2樓D室',
		5,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'Exit E2, Sheung Wan MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FmO1zG7CCMrdpOed83UbLoir6fIx1%2FprofileImages%2FmO1zG7CCMrdpOed83UbLoir6fIx1.thumbnail.png?alt=media&token=5a7571c6-3c18-4c7f-b0bc-3198eea52468'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		7,
		'Ukiyo',
		'22.29448,114.17505',
		'27628822',
		NULL,
		'ukiyo_hk',
		'ukiyo.hk',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FQTvwc6Mrp8RYxbrNHzmCT4DJHlL2%2FprofileImages%2FQTvwc6Mrp8RYxbrNHzmCT4DJHlL2.logo_trans.png?alt=media&token=e9bd8247-06ab-4f0b-823c-85d8f730e962',
		'Shop 610, 6/F, K11 Musea, Victoria Dockside, 18 Salisbury Road, Tsim Sha Tsui, Hong Kong
香港尖沙咀梳士巴利道18號維港文化匯K11 Musea 6樓610號舖',
		6,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'Exit J, Tsim Sha Tsui/ TST East MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FQTvwc6Mrp8RYxbrNHzmCT4DJHlL2%2FprofileImages%2FQTvwc6Mrp8RYxbrNHzmCT4DJHlL2.thumbnail.png?alt=media&token=7c16ce8f-d3ac-4eed-ac44-fffab55441a5'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		8,
		'Cupping Room Coffee Roasters - Tung Chung Citygate',
		'22.28956,113.94015',
		'61226106',
		NULL,
		'cuppingroom.hk',
		NULL,
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FMduG0TWHHoaRpBMJhE6tuecK0Bg2%2FprofileImages%2FMduG0TWHHoaRpBMJhE6tuecK0Bg2.logo_trans.png?alt=media&token=8273264f-0e7c-426a-99a4-5186831aa207',
		'Shop 263, 2/F, Citygate Outlets, 20 Tat Tung Road, Tung Chung, Lantau Island, Hong Kong
香港東涌達東路20號東薈城名店倉2樓263號舖',
		7,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'Exit C, Tung Chung MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FMduG0TWHHoaRpBMJhE6tuecK0Bg2%2FprofileImages%2FMduG0TWHHoaRpBMJhE6tuecK0Bg2.thumbnail.png?alt=media&token=b7833108-7cd5-41a0-a29e-c41fe3cb2469'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		9,
		'Saloon',
		'22.32727,114.16339',
		NULL,
		NULL,
		'saloon_hongkong',
		NULL,
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2F3FkxSUuetKcrOREIxrBBIww74eD2%2FprofileImages%2F3FkxSUuetKcrOREIxrBBIww74eD2.logo_trans.png?alt=media&token=a23fa820-aa6c-47ca-b505-be35e0a6f561',
		'G/F, 196 Tai Nan Street, Sham Shui Po, Hong Kong
香港深水埗大南街196號地下',
		8,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'8-min walk from Exit D, Prince Edward MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2F3FkxSUuetKcrOREIxrBBIww74eD2%2FprofileImages%2F3FkxSUuetKcrOREIxrBBIww74eD2.thumbnail.png?alt=media&token=a879fd31-1ad8-4955-a254-9f97c9575c56'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		10,
		'Nations Coffee HK - Wan Chai',
		'22.27555,114.17184',
		'27021909',
		NULL,
		'nationscoffeehk',
		'nationscoffeehk',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FJrVUTPvgAcSEFeWzMpd3mAFdqHZ2%2FprofileImages%2FJrVUTPvgAcSEFeWzMpd3mAFdqHZ2.logo_trans.png?alt=media&token=fa6f1f81-a1a2-4d15-93c1-27f61b5934aa',
		'Unit B, 2/F, Hundred City Centre, 7-17 Amoy Street, Wan Chai, Hong Kong
香港灣仔廈門街7-17號百旺都中心2樓B號舖',
		4,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'Exit D, Wan Chai MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FJrVUTPvgAcSEFeWzMpd3mAFdqHZ2%2FprofileImages%2FJrVUTPvgAcSEFeWzMpd3mAFdqHZ2.thumbnail.png?alt=media&token=eabb0756-47d5-43ec-8875-c7812e8d9dd9'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		11,
		'Chatroom 茶語啡 - Tseung Kwan O',
		'22.32444,114.25751',
		'68276619',
		NULL,
		'chatroom.tko',
		NULL,
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FgGd639SuFudECw83CVmQ57XGEmY2%2FprofileImages%2FgGd639SuFudECw83CVmQ57XGEmY2.logo_trans.png?alt=media&token=1897e0e8-1519-4d65-b175-079d8c8b702b',
		'Shop G04, G/F, MCP Central (Phase 2), 8 Yan King Road, Po Lam, Tseung Kwan O, Hong Kong
香港將軍澳寶琳欣景路8號新都城中心2期地下4號舖',
		9,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'Exit A2, Po Lam Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FgGd639SuFudECw83CVmQ57XGEmY2%2FprofileImages%2FgGd639SuFudECw83CVmQ57XGEmY2.thumbnail.png?alt=media&token=6a5e7bf3-ec5a-4ee7-b236-a97e72a9f292'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		12,
		'Better Late Than Never',
		'22.27761,114.18698',
		NULL,
		NULL,
		'bltncoffee.hk',
		'profile.php?id=100087188703096&mibextid=LQQJ4d',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FANBgx05kV7WqHluE34drDhUMPxh2%2FprofileImages%2FANBgx05kV7WqHluE34drDhUMPxh2.logo_trans.png?alt=media&token=a0b2843e-03d6-4694-8bc9-9fd21161e381',
		'G/F, 27 Haven Street, Causeway Bay, Hong Kong
香港銅鑼灣希雲街27號地下',
		10,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'6-min walk from Exit F1, Causeway Bay MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FANBgx05kV7WqHluE34drDhUMPxh2%2FprofileImages%2FANBgx05kV7WqHluE34drDhUMPxh2.thumbnail.png?alt=media&token=2ae352df-e356-4e1f-b4af-76d361032d50'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		13,
		'Brew Dog Coffee Company',
		'22.33823,114.1992',
		'62371175',
		NULL,
		'brewdogcoffeecompany',
		NULL,
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FLGnSkXl4TufqnH5Hg0m1rdblEw92%2FprofileImages%2FLGnSkXl4TufqnH5Hg0m1rdblEw92.logo_trans.png?alt=media&token=84fe4ad0-97bf-4a1a-9d0b-29541c829e8a',
		'Shop L, 1/F, Maxgrand Plaza, 3 Tai Yau Street, San Po Kong, Hong Kong
香港新蒲崗大有街3號萬迪廣場1樓L舖',
		11,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'5-min walk from Exit A2, Diamond Hill MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FLGnSkXl4TufqnH5Hg0m1rdblEw92%2FprofileImages%2FLGnSkXl4TufqnH5Hg0m1rdblEw92.thumbnail.png?alt=media&token=4fc5d408-06ef-41e5-a81a-13ec84533245'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		14,
		'Oneness Team',
		'22.45341,114.16462',
		'67599141',
		NULL,
		'oneness.team2022',
		NULL,
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FU07BVBotuthwNdYLlY2j199FmuQ2%2FprofileImages%2FU07BVBotuthwNdYLlY2j199FmuQ2.logo_trans.png?alt=media&token=a9791acd-29c2-4f97-8cec-4cf8bc27d37a',
		'G08, G/F, Fuller Gardens, 8 Chui Lok Street, Tai Po, Hong Kong
香港大埔翠樂街8號富萊花園地下G08號舖',
		12,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'>10-min walk from Exit B, Tai Wo MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FU07BVBotuthwNdYLlY2j199FmuQ2%2FprofileImages%2FU07BVBotuthwNdYLlY2j199FmuQ2.thumbnail.png?alt=media&token=2fa2b212-49a7-4180-9863-596b6b2a128d'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		15,
		'Jessy Coffee',
		'22.28336,114.152',
		NULL,
		NULL,
		'jessycoffeeco',
		NULL,
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FSixokJBh2OUTTH0ycGzSfIqzMCk1%2FprofileImages%2FSixokJBh2OUTTH0ycGzSfIqzMCk1.logo_trans.png?alt=media&token=299a1100-6166-4fb3-9666-eb252140a05e',
		'Shop H105, 1/F, Hollywood (Block B), PMQ, 35 Aberdeen Street, Central, Hong Kong
香港中環鴨巴甸街35號PMQ B座1樓H105號舖',
		5,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'Exit E2, Sheung Wan MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FSixokJBh2OUTTH0ycGzSfIqzMCk1%2FprofileImages%2FSixokJBh2OUTTH0ycGzSfIqzMCk1.thumbnail.png?alt=media&token=d5e9205c-9709-4d8a-8959-0583d8c1863c'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		16,
		'IntiMATE Coffee',
		'22.29014,114.20039',
		NULL,
		NULL,
		'intimate.coffeee',
		NULL,
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FrsKUCplXkuRioJoPEoKWZqrnoq22%2FprofileImages%2FrsKUCplXkuRioJoPEoKWZqrnoq22.logo_trans.png?alt=media&token=51d10882-4464-4a2c-be88-c18eef35c827',
		'G/F, Block B, Tung Fat Building, 31A Kam Ping Street, North Point, Hong Kong
香港北角錦屏街31A東發大廈B座地下',
		3,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'Exit B4, North Point MTR Station (Access via Shu Kuk Street 書局街)',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FrsKUCplXkuRioJoPEoKWZqrnoq22%2FprofileImages%2FrsKUCplXkuRioJoPEoKWZqrnoq22.thumbnail.png?alt=media&token=444c76db-178e-490d-ace5-0572acebc801'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		17,
		'Little Cove Espresso - Kennedy Town',
		'22.28388,114.12836',
		'67376242',
		NULL,
		'littlecove.espresso',
		'littlecove.espresso',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2Firmin5QtUJabLCwuV2uOHmEnS9f2%2FprofileImages%2Firmin5QtUJabLCwuV2uOHmEnS9f2.logo_trans.png?alt=media&token=4edee198-ff34-4500-a89f-90332009364d',
		'Shop 3, G/F, New Fortune House, 3-5 New Praya Road, Kennedy Town, Hong Kong
香港堅尼地城新海旁街3-5號五福大廈地下3號舖',
		13,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'3-min walk from Exit B, Kennedy Town MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2Firmin5QtUJabLCwuV2uOHmEnS9f2%2FprofileImages%2Firmin5QtUJabLCwuV2uOHmEnS9f2.thumbnail.png?alt=media&token=5179187d-9192-46ad-afcd-90b81d594018'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		18,
		'CoHee - Fanling',
		'22.49514,114.13985',
		'66990898',
		NULL,
		'coheehk',
		'coheehk',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FVofKfympaATO4ck90Pro4yOPTkV2%2FprofileImages%2FVofKfympaATO4ck90Pro4yOPTkV2.logo_trans.png?alt=media&token=27ed0bba-8795-4f40-a6f7-9fdf1b87e838',
		'G/F, Former Fanling Magistracy, 302 Jockey Club Road, Fanling, Hong Kong
香港粉嶺馬會道302號前粉嶺裁判法院地下',
		14,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'6-min walk from Exit C, Fanling MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FVofKfympaATO4ck90Pro4yOPTkV2%2FprofileImages%2FVofKfympaATO4ck90Pro4yOPTkV2.thumbnail.png?alt=media&token=f4b98f56-4722-4659-8bc6-c4dbba4caadc'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		19,
		'Coffee Hermosa',
		'22.28669,114.19087',
		'28861030',
		NULL,
		'coffeehermosahk',
		'Coffee-Hermosa-101869916006442/',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2F3KHw9HFL6GPMqGNZ87BatEs6jTf2%2FprofileImages%2F3KHw9HFL6GPMqGNZ87BatEs6jTf2.logo_trans.png?alt=media&token=72634723-cb37-4286-96a1-57d8fb0ab229',
		'G/F, 6 Whitfield Road, Causeway Bay, Hong Kong
香港銅鑼灣威非路道6號地下',
		15,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'6-min walk from Exit A, Tin Hau MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2F3KHw9HFL6GPMqGNZ87BatEs6jTf2%2FprofileImages%2F3KHw9HFL6GPMqGNZ87BatEs6jTf2.thumbnail.png?alt=media&token=0e33b8fc-c159-47b8-ac27-7169f0061e82'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		20,
		'野田珈琲 Noda Coffee',
		'22.27824,114.17829',
		'65308822',
		NULL,
		'nodacoffeehk',
		'nodacoffeehk',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FCF5AirAiUfNfKYeyxlVk2BjkIXl2%2FprofileImages%2FCF5AirAiUfNfKYeyxlVk2BjkIXl2.logo_trans.png?alt=media&token=b4204a26-3ebe-4497-b621-2ab5fdf10d4e',
		'Shop B, G/F, W Square, 314-324 Hennessy Road, Wan Chai, Hong Kong
香港灣仔軒尼詩道314-324號W Square地下B號舖',
		4,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'7-min walk from Exit A4, Wan Chai MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FCF5AirAiUfNfKYeyxlVk2BjkIXl2%2FprofileImages%2FCF5AirAiUfNfKYeyxlVk2BjkIXl2.thumbnail.png?alt=media&token=8c906440-caa4-4f94-a4a3-879ccc9b1704'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		21,
		'Live A Little',
		'22.28703,114.14478',
		NULL,
		NULL,
		'livealittle_hk',
		NULL,
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FLg7kOM60DDP6RVOeEh7zcznwa6A3%2FprofileImages%2FLg7kOM60DDP6RVOeEh7zcznwa6A3.logo_trans.png?alt=media&token=3d9e717a-1bed-4a81-8748-ef79970445f8',
		'G/F, Kin Hing Building, 172-180 Queen’s Road West, Sai Ying Pun, Hong Kong
香港西營盤皇后大道西172-180號建興樓地下',
		16,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'Exit A1, Sai Ying Pun MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FLg7kOM60DDP6RVOeEh7zcznwa6A3%2FprofileImages%2FLg7kOM60DDP6RVOeEh7zcznwa6A3.thumbnail.png?alt=media&token=926528c7-2db8-4a5e-89dc-01f3065ad47e'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		22,
		'rare coffee ',
		'22.36688,114.13459',
		'62384208',
		NULL,
		'rarecoffee.official',
		'RareRoastingRoom',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FxbXw6LMVFFSzLQETg2fQ6G3cwzt1%2FprofileImages%2FxbXw6LMVFFSzLQETg2fQ6G3cwzt1.logo_trans.png?alt=media&token=bdd3299e-1211-44ba-83af-3f1d842e90bd',
		'G/F, EDGE, 30 Kwai Wing Road, Kwai Chung',
		17,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'9-min walk from Exit A, Kwai Hing MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FxbXw6LMVFFSzLQETg2fQ6G3cwzt1%2FprofileImages%2FxbXw6LMVFFSzLQETg2fQ6G3cwzt1.thumbnail.png?alt=media&token=08e76051-af7e-4f9d-af05-cdf3bab6cfe8'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		23,
		'30MILESTONE 而立',
		'22.28034,114.18331',
		'61475326',
		NULL,
		'30milestone',
		'30milestone2021/',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FQKlVq5eVNMhteONxr6OdyR2mPAx1%2FprofileImages%2FQKlVq5eVNMhteONxr6OdyR2mPAx1.logo_trans.png?alt=media&token=6ce330ba-289d-4821-87ea-d74ce50d31ce',
		'Shop A&B, G/F, Radio City, 505 Hennessy Road, Causeway Bay, Hong Kong',
		10,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'1-min walk from Exit B, Causeway Bay MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FQKlVq5eVNMhteONxr6OdyR2mPAx1%2FprofileImages%2FQKlVq5eVNMhteONxr6OdyR2mPAx1.thumbnail.png?alt=media&token=3ecdce24-5d69-4614-8c18-4c7b72dedff1'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		24,
		'Starting Over Espresso ',
		'22.28148,114.15349',
		'92425433',
		NULL,
		'startingover.espresso',
		'Starting-Over-Espresso-101866471683303',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FR5YBSNOSLrMO1abnDPNBat5UAmf2%2FprofileImages%2FR5YBSNOSLrMO1abnDPNBat5UAmf2.logo_trans.png?alt=media&token=9f42c6c3-69e9-4030-89e3-0b03b4360aa7',
		'G/F, 17 Old Bailey Street, Central, Hong Kong',
		5,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'9-min walk from Exit C, Hong Kong MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FR5YBSNOSLrMO1abnDPNBat5UAmf2%2FprofileImages%2FR5YBSNOSLrMO1abnDPNBat5UAmf2.thumbnail.png?alt=media&token=b6a1f496-95ed-4ded-a2aa-7a50831b3ad2'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		25,
		' Contrast',
		'22.33918,114.15384',
		'23377220',
		NULL,
		'contrast_hk',
		'contrastsince2020/',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FG1WBrN0WupaOnU3T8cdOyKscibh1%2FprofileImages%2FG1WBrN0WupaOnU3T8cdOyKscibh1.logo_trans.png?alt=media&token=dad8366b-daa4-4efc-8d70-93feaea2edbb',
		'G/F, Easey Building, 512-518 Fuk Wing Street, Cheung Sha Wan, Kowloon, Hong Kong',
		18,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'6-min walk from Exit C2, Cheung Sha Wan MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FG1WBrN0WupaOnU3T8cdOyKscibh1%2FprofileImages%2FG1WBrN0WupaOnU3T8cdOyKscibh1.thumbnail.png?alt=media&token=2f5da819-91ec-4720-a339-80a9d4e10134'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		26,
		'Kaleido Coffee',
		'22.38637,113.98054',
		'98881422',
		NULL,
		'kaleidocoffeehk',
		'kaleidocoffeehk',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FFPSbaQ3zG7RldXWmEV00LbqZXMu1%2FprofileImages%2FFPSbaQ3zG7RldXWmEV00LbqZXMu1.logo_trans.png?alt=media&token=2e62db7f-1af1-4284-b0bd-ce45932f6ed6',
		'Shop 21, G/F, Rainbow Garden, 351 Castle Peak Road, Tuen Mun',
		19,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'保良局圓玄小學對面',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FFPSbaQ3zG7RldXWmEV00LbqZXMu1%2FprofileImages%2FFPSbaQ3zG7RldXWmEV00LbqZXMu1.thumbnail.png?alt=media&token=b552d3da-fae7-4dfb-b549-13292d3eb792'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		27,
		'Pedestrian Coffee',
		'22.27789,114.18463',
		'51283812',
		NULL,
		'pedestriancoffee.hk',
		'Pedestrian-Coffee-104328278620418/',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FG18hxi1vwaTUjz69KPCt1HtUiek1%2FprofileImages%2FG18hxi1vwaTUjz69KPCt1HtUiek1.logo_trans.png?alt=media&token=aa79275d-c89c-4fdb-ac5d-2c4285590b8e',
		'Shop G111-112 , 8 Hysan Avenue , Causeway Bay , 
Hong Kong',
		10,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'5-min walk from Exit A/ F1, Causeway Bay MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FG18hxi1vwaTUjz69KPCt1HtUiek1%2FprofileImages%2FG18hxi1vwaTUjz69KPCt1HtUiek1.thumbnail.png?alt=media&token=9dc801d7-8493-48da-bbf4-278308a9d63f'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		28,
		'Lobby Cafe by DS Studio',
		'22.31217,114.22513',
		'97092280',
		NULL,
		'lobbycafe.hk',
		'lobbycafehk ',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FN3YLqgiNh2PDPO5W7Wbs2CMKDfC3%2FprofileImages%2FN3YLqgiNh2PDPO5W7Wbs2CMKDfC3.logo_trans.png?alt=media&token=d4ad0618-8284-4bee-a540-a63b3afb07ce',
		'Shop L3-5, APM Millennium City, Kwun Tong, Kowloon, Hong Kong',
		20,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'Exit A2, Kwun Tong MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FN3YLqgiNh2PDPO5W7Wbs2CMKDfC3%2FprofileImages%2FN3YLqgiNh2PDPO5W7Wbs2CMKDfC3.thumbnail.png?alt=media&token=f6c55144-5d59-4693-9da8-31a7d14e0cdf'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		29,
		'OOPS Coffee & co',
		'22.38208,114.27315',
		NULL,
		NULL,
		'oopscoffee.co',
		'Oops-coffee-co-101596105243867/',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FGkFFX0qZrcZBPAahLR0zSiaHezM2%2FprofileImages%2FGkFFX0qZrcZBPAahLR0zSiaHezM2.logo_trans.png?alt=media&token=efc6afdc-aefe-4b7d-9a69-15679aed11e3',
		'Shop 11, Ko Fu Building, 58 Fuk Man Road, Sai Kung, N.T., Hong Kong',
		21,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'1-min walk from Sai Kung Minibus Terminal',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FGkFFX0qZrcZBPAahLR0zSiaHezM2%2FprofileImages%2FGkFFX0qZrcZBPAahLR0zSiaHezM2.thumbnail.png?alt=media&token=d514af53-37ca-42d0-89ed-f5bdd9d05c11'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		30,
		'Lorway Coffee & Bakery',
		'22.38131,113.97165',
		NULL,
		NULL,
		'lorway_coffee',
		NULL,
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FH9gFHhh0DUayuaj3Ce9VLa5BslZ2%2FprofileImages%2FH9gFHhh0DUayuaj3Ce9VLa5BslZ2.logo_trans.png?alt=media&token=28563bd1-cd3c-4502-8c9a-eaae31f14d7b',
		'Shop B3-A, Tuen Mun Central Square, 22 Hoi Wing Road, Tuen Mun, New Territories, Hong Kong',
		19,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'2-min walk from Tuen Mun Swimming Pool Tram Stop',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FH9gFHhh0DUayuaj3Ce9VLa5BslZ2%2FprofileImages%2FH9gFHhh0DUayuaj3Ce9VLa5BslZ2.thumbnail.png?alt=media&token=97f0193d-7f94-4996-9fc5-ba24ec7ed360'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		31,
		'Kachimushi - Sai Kung',
		'22.37973,114.27173',
		NULL,
		NULL,
		'kachimushihk',
		NULL,
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2F1WxgZs9AkFMua7GiSwbYUamUj2v2%2FprofileImages%2F1WxgZs9AkFMua7GiSwbYUamUj2v2.logo_trans.png?alt=media&token=3e8e886d-4e0f-4af3-b488-f5e578ba0066',
		'G/F, 35 See Cheung Street, Sai Kung, New Territories, Hong Kong',
		21,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'7-min walk from Sai Kung Minibus Terminal',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2F1WxgZs9AkFMua7GiSwbYUamUj2v2%2FprofileImages%2F1WxgZs9AkFMua7GiSwbYUamUj2v2.thumbnail.png?alt=media&token=8ab6ed6a-0ec8-43e4-95a8-10cde4fcc076'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		32,
		'Cafe au Lait 乃良咖啡',
		'22.38072,113.97079',
		'34809886',
		NULL,
		'cafe.aulait21',
		'cafe.aulaithk',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FROrpGkZ1V0OxZ9PoEDZ2NTwgZhw1%2FprofileImages%2FROrpGkZ1V0OxZ9PoEDZ2NTwgZhw1.logo_trans.png?alt=media&token=89bace5a-b486-4461-80c9-d3206eed7338',
		'Shop G27, G/F, Regency Bay, 23 Hoi Wong Road, Tuen Mun, New Territories, Hong Kong',
		19,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'Tuen Mun Swimming Pool Stop (Train 507/ 614/ 614P)',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FROrpGkZ1V0OxZ9PoEDZ2NTwgZhw1%2FprofileImages%2FROrpGkZ1V0OxZ9PoEDZ2NTwgZhw1.thumbnail.png?alt=media&token=446cc633-217c-4172-9d25-fb9fc7d7f894'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		33,
		'Sloth Cafe',
		'22.28865,114.1914',
		'5403 6119',
		NULL,
		'sloth.cafe.hk',
		'sloth.cafe.hk',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FDU8fV2SWSOYsmwt0mPyLTzyegdo1%2FprofileImages%2FDU8fV2SWSOYsmwt0mPyLTzyegdo1.logo_trans.png?alt=media&token=b6967462-4d0b-4a9d-80a1-fcc6c111e7c4',
		'Shop A, G/F, 18 King Wah Road, Fortress Hill, North Point, Hong Kong
香港北角炮台山京華道18號地下A舖',
		3,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'Exit A, Fortess Hill MTR Station// Entrance on King Wah Road',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FDU8fV2SWSOYsmwt0mPyLTzyegdo1%2FprofileImages%2FDU8fV2SWSOYsmwt0mPyLTzyegdo1.thumbnail.png?alt=media&token=0f6c9902-9cb4-4105-850f-96745db59d20'
	);
INSERT INTO "shop" (
		"id",
		"name",
		"latlng",
		"tel",
		"bean",
		"instagram",
		"facebook",
		"avatar",
		"address",
		"district_id",
		"created_at",
		"updated_at",
		"navigation_tip",
		"thumbnail"
	)
VALUES (
		34,
		'LITE',
		'22.28185,114.1556',
		'31699933',
		NULL,
		'bylite',
		'bylitehk',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FiXGorhtJadUHr3tJt8aOnSPAjQ43%2FprofileImages%2FiXGorhtJadUHr3tJt8aOnSPAjQ43.logo_trans.png?alt=media&token=e2480c11-160b-4ae6-ba23-d58b2a228e7e',
		'G/F, 25 Wellington Street, Central, Hong Kong
香港中環威靈頓街25號地下',
		5,
		'2023-01-16 15:21:17',
		'2023-01-18 08:33:50',
		'4-min walk from Exit D2, Central MTR Station',
		'https://firebasestorage.googleapis.com/v0/b/gafe-e9668.appspot.com/o/cafes%2FiXGorhtJadUHr3tJt8aOnSPAjQ43%2FprofileImages%2FiXGorhtJadUHr3tJt8aOnSPAjQ43.thumbnail.png?alt=media&token=33bbf97b-5d79-44fb-8244-2faf3fe75ed5'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		1,
		2,
		6,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		2,
		2,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		3,
		2,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		4,
		2,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		5,
		2,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		6,
		2,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		7,
		3,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		8,
		3,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		9,
		3,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		10,
		3,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		11,
		3,
		13,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		12,
		3,
		14,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		13,
		3,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		14,
		4,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		15,
		4,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		16,
		4,
		5,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		17,
		4,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		18,
		4,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		19,
		4,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		20,
		4,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		21,
		4,
		13,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		22,
		4,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		23,
		4,
		16,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		24,
		4,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		25,
		5,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		26,
		5,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		27,
		5,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		28,
		5,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		29,
		5,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		30,
		5,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		31,
		5,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		32,
		6,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		33,
		6,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		34,
		6,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		35,
		6,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		36,
		6,
		13,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		37,
		6,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		38,
		6,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		39,
		7,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		40,
		7,
		5,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		41,
		7,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		42,
		7,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		43,
		7,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		44,
		7,
		13,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		45,
		7,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		46,
		7,
		17,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		47,
		7,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		48,
		8,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		49,
		8,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		50,
		8,
		5,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		51,
		8,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		52,
		8,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		53,
		8,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		54,
		8,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		55,
		8,
		13,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		56,
		8,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		57,
		8,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		58,
		8,
		20,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		59,
		9,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		60,
		9,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		61,
		9,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		62,
		9,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		63,
		10,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		64,
		10,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		65,
		10,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		66,
		10,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		67,
		10,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		68,
		10,
		13,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		69,
		10,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		70,
		10,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		71,
		11,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		72,
		11,
		5,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		73,
		11,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		74,
		11,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		75,
		11,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		76,
		11,
		13,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		77,
		11,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		78,
		11,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		79,
		12,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		80,
		12,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		81,
		12,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		82,
		12,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		83,
		12,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		84,
		12,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		85,
		12,
		16,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		86,
		12,
		17,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		87,
		12,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		88,
		13,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		89,
		13,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		90,
		13,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		91,
		13,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		92,
		13,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		93,
		13,
		13,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		94,
		13,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		95,
		13,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		96,
		14,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		97,
		14,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		98,
		14,
		5,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		99,
		14,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		100,
		14,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		101,
		14,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		102,
		14,
		13,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		103,
		14,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		104,
		14,
		16,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		105,
		14,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		106,
		15,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		107,
		15,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		108,
		15,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		109,
		15,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		110,
		15,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		111,
		15,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		112,
		15,
		16,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		113,
		15,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		114,
		16,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		115,
		16,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		116,
		16,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		117,
		16,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		118,
		16,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		119,
		16,
		13,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		120,
		16,
		14,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		121,
		16,
		16,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		122,
		16,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		123,
		17,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		124,
		17,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		125,
		17,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		126,
		17,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		127,
		17,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		128,
		17,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		129,
		17,
		13,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		130,
		17,
		14,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		131,
		17,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		132,
		17,
		16,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		133,
		17,
		17,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		134,
		17,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		135,
		18,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		136,
		18,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		137,
		18,
		5,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		138,
		18,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		139,
		18,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		140,
		18,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		141,
		18,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		142,
		18,
		13,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		143,
		18,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		144,
		18,
		16,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		145,
		18,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		146,
		19,
		6,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		147,
		19,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		148,
		19,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		149,
		19,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		150,
		19,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		151,
		19,
		16,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		152,
		19,
		17,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		153,
		19,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		154,
		20,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		155,
		20,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		156,
		20,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		157,
		20,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		158,
		20,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		159,
		20,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		160,
		20,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		161,
		21,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		162,
		21,
		6,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		163,
		21,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		164,
		21,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		165,
		21,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		166,
		21,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		167,
		21,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		168,
		21,
		17,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		169,
		21,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		170,
		22,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		171,
		22,
		5,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		172,
		22,
		6,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		173,
		22,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		174,
		22,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		175,
		22,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		176,
		22,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		177,
		22,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		178,
		23,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		179,
		23,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		180,
		23,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		181,
		23,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		182,
		23,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		183,
		23,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		184,
		23,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		185,
		24,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		186,
		24,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		187,
		24,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		188,
		24,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		189,
		24,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		190,
		24,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		191,
		24,
		12,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		192,
		24,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		193,
		24,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		194,
		25,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		195,
		25,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		196,
		25,
		5,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		197,
		25,
		6,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		198,
		25,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		199,
		25,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		200,
		25,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		201,
		25,
		13,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		202,
		25,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		203,
		25,
		17,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		204,
		25,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		205,
		26,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		206,
		26,
		5,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		207,
		26,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		208,
		26,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		209,
		26,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		210,
		26,
		16,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		211,
		26,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		212,
		26,
		19,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		213,
		27,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		214,
		27,
		5,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		215,
		27,
		6,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		216,
		27,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		217,
		27,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		218,
		27,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		219,
		27,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		220,
		27,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		221,
		27,
		16,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		222,
		27,
		17,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		223,
		27,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		224,
		27,
		19,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		225,
		28,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		226,
		28,
		5,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		227,
		28,
		6,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		228,
		28,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		229,
		28,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		230,
		28,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		231,
		28,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		232,
		28,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		233,
		28,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		234,
		28,
		19,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		235,
		29,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		236,
		29,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		237,
		29,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		238,
		29,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		239,
		29,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		240,
		29,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		241,
		29,
		13,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		242,
		29,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		243,
		29,
		16,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		244,
		29,
		17,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		245,
		29,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		246,
		30,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		247,
		30,
		5,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		248,
		30,
		6,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		249,
		30,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		250,
		30,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		251,
		30,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		252,
		30,
		13,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		253,
		30,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		254,
		30,
		17,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		255,
		30,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		256,
		30,
		19,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		257,
		30,
		20,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		258,
		31,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		259,
		31,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		260,
		31,
		5,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		261,
		31,
		8,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		262,
		31,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		263,
		31,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		264,
		31,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		265,
		31,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		266,
		31,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		267,
		32,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		268,
		32,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		269,
		32,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		270,
		32,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		271,
		32,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		272,
		32,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		273,
		32,
		16,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		274,
		32,
		17,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		275,
		32,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		276,
		32,
		19,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		277,
		33,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		278,
		33,
		5,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		279,
		33,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		280,
		33,
		10,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		281,
		33,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		282,
		33,
		15,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		283,
		33,
		16,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		284,
		33,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		285,
		34,
		1,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		286,
		34,
		4,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		287,
		34,
		9,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		288,
		34,
		11,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		289,
		34,
		13,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		290,
		34,
		14,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "shop_feature" (
		"id",
		"shop_id",
		"feature_id",
		"created_at",
		"updated_at"
	)
VALUES (
		291,
		34,
		18,
		'2023-01-18 08:33:06',
		'2023-01-18 08:33:06'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		1,
		2,
		0,
		'09:00:00',
		'17:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		2,
		2,
		1,
		'08:00:00',
		'17:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		3,
		3,
		0,
		'09:00:00',
		'16:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		4,
		3,
		1,
		'08:00:00',
		'17:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		5,
		4,
		0,
		'08:30:00',
		'21:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		6,
		4,
		1,
		'08:30:00',
		'21:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		7,
		5,
		0,
		'09:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		8,
		5,
		1,
		'09:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		9,
		6,
		0,
		'11:30:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		10,
		6,
		1,
		'11:30:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		11,
		7,
		0,
		'08:30:00',
		'21:30:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		12,
		7,
		1,
		'08:30:00',
		'21:30:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		13,
		8,
		0,
		'11:00:00',
		'20:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		14,
		8,
		1,
		'10:00:00',
		'20:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		15,
		9,
		0,
		'12:00:00',
		'22:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		16,
		10,
		1,
		'10:00:00',
		'19:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		17,
		11,
		0,
		'11:30:00',
		'21:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		18,
		11,
		1,
		'11:30:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		19,
		12,
		0,
		'10:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		20,
		12,
		1,
		'10:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		21,
		13,
		0,
		'11:00:00',
		'19:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		22,
		13,
		1,
		'10:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		23,
		14,
		0,
		'09:00:00',
		'22:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		24,
		14,
		1,
		'09:00:00',
		'22:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		25,
		15,
		0,
		'09:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		26,
		15,
		1,
		'09:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		27,
		16,
		0,
		'08:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		28,
		16,
		1,
		'08:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		29,
		17,
		0,
		'07:30:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		30,
		17,
		1,
		'07:30:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		31,
		18,
		0,
		'08:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		32,
		18,
		1,
		'08:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		33,
		19,
		0,
		'10:00:00',
		'17:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		34,
		20,
		0,
		'10:00:00',
		'20:30:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		35,
		20,
		1,
		'08:00:00',
		'19:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		36,
		21,
		0,
		'10:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		37,
		21,
		1,
		'08:30:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		38,
		22,
		0,
		'12:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		39,
		22,
		1,
		'09:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		40,
		23,
		0,
		'12:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		41,
		23,
		1,
		'08:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		42,
		24,
		0,
		'09:00:00',
		'19:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		43,
		24,
		1,
		'10:00:00',
		'19:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		44,
		25,
		0,
		'09:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		45,
		25,
		1,
		'09:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		46,
		26,
		0,
		'08:00:00',
		'19:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		47,
		26,
		1,
		'08:00:00',
		'19:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		48,
		27,
		0,
		'10:30:00',
		'18:30:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		49,
		27,
		1,
		'08:30:00',
		'17:30:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		50,
		28,
		0,
		'11:00:00',
		'20:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		51,
		28,
		1,
		'11:00:00',
		'19:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		52,
		29,
		0,
		'10:30:00',
		'19:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		53,
		29,
		1,
		'10:30:00',
		'18:30:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		54,
		30,
		0,
		'08:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		55,
		30,
		1,
		'08:00:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		56,
		31,
		0,
		'09:00:00',
		'17:30:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		57,
		31,
		1,
		'09:00:00',
		'17:30:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		58,
		32,
		0,
		'10:00:00',
		'19:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		59,
		32,
		1,
		'10:00:00',
		'19:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		60,
		33,
		0,
		'10:30:00',
		'18:30:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		61,
		34,
		0,
		'07:30:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		62,
		34,
		1,
		'07:30:00',
		'18:00:00',
		'2023-01-16 15:36:16',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		63,
		2,
		2,
		'08:00:00',
		'17:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		64,
		2,
		3,
		'08:00:00',
		'17:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		65,
		2,
		4,
		'08:00:00',
		'17:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		66,
		2,
		5,
		'08:00:00',
		'17:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		67,
		2,
		6,
		'09:00:00',
		'17:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		68,
		3,
		2,
		'08:00:00',
		'17:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		69,
		3,
		3,
		'08:00:00',
		'17:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		70,
		3,
		4,
		'08:00:00',
		'17:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		71,
		3,
		5,
		'08:00:00',
		'17:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		72,
		3,
		6,
		'09:00:00',
		'16:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		73,
		4,
		2,
		'08:30:00',
		'21:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		74,
		4,
		3,
		'08:30:00',
		'21:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		75,
		4,
		4,
		'08:30:00',
		'21:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		76,
		4,
		5,
		'08:30:00',
		'21:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		77,
		4,
		6,
		'08:30:00',
		'21:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		78,
		5,
		2,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		79,
		5,
		3,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		80,
		5,
		4,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		81,
		5,
		5,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		82,
		5,
		6,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		83,
		6,
		2,
		'11:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		84,
		6,
		3,
		'11:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		85,
		6,
		4,
		'11:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		86,
		6,
		5,
		'11:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		87,
		6,
		6,
		'11:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		88,
		7,
		2,
		'08:30:00',
		'21:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		89,
		7,
		3,
		'08:30:00',
		'21:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		90,
		7,
		4,
		'08:30:00',
		'21:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		91,
		7,
		5,
		'08:30:00',
		'21:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		92,
		7,
		6,
		'08:30:00',
		'21:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		93,
		8,
		2,
		'10:00:00',
		'20:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		94,
		8,
		3,
		'10:00:00',
		'20:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		95,
		8,
		4,
		'10:00:00',
		'20:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		96,
		8,
		5,
		'10:00:00',
		'20:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		97,
		8,
		6,
		'11:00:00',
		'20:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		98,
		9,
		2,
		'12:00:00',
		'22:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		99,
		9,
		3,
		'12:00:00',
		'22:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		100,
		9,
		4,
		'12:00:00',
		'22:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		101,
		9,
		5,
		'12:00:00',
		'22:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		102,
		9,
		6,
		'12:00:00',
		'22:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		103,
		10,
		2,
		'10:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		104,
		10,
		3,
		'10:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		105,
		10,
		4,
		'10:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		106,
		10,
		5,
		'10:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		107,
		10,
		6,
		'10:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		108,
		11,
		2,
		'11:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		109,
		11,
		3,
		'11:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		110,
		11,
		4,
		'11:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		111,
		11,
		5,
		'11:30:00',
		'21:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		112,
		11,
		6,
		'11:30:00',
		'21:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		113,
		12,
		2,
		'10:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		114,
		12,
		3,
		'10:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		115,
		12,
		4,
		'10:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		116,
		12,
		5,
		'10:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		117,
		12,
		6,
		'10:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		118,
		13,
		2,
		'10:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		119,
		13,
		3,
		'10:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		120,
		13,
		4,
		'10:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		121,
		13,
		5,
		'10:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		122,
		13,
		6,
		'11:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		123,
		14,
		2,
		'09:00:00',
		'22:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		124,
		14,
		3,
		'09:00:00',
		'22:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		125,
		14,
		4,
		'09:00:00',
		'22:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		126,
		14,
		5,
		'09:00:00',
		'22:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		127,
		14,
		6,
		'09:00:00',
		'22:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		128,
		15,
		2,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		129,
		15,
		3,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		130,
		15,
		4,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		131,
		15,
		5,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		132,
		15,
		6,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		133,
		16,
		2,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		134,
		16,
		3,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		135,
		16,
		4,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		136,
		16,
		5,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		137,
		16,
		6,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		138,
		17,
		2,
		'07:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		139,
		17,
		3,
		'07:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		140,
		17,
		4,
		'07:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		141,
		17,
		5,
		'07:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		142,
		17,
		6,
		'07:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		143,
		18,
		2,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		144,
		18,
		3,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		145,
		18,
		4,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		146,
		18,
		5,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		147,
		18,
		6,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		148,
		19,
		2,
		'08:00:00',
		'17:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		149,
		19,
		3,
		'08:00:00',
		'17:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		150,
		19,
		4,
		'08:00:00',
		'17:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		151,
		19,
		5,
		'08:00:00',
		'17:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		152,
		19,
		6,
		'10:00:00',
		'17:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		153,
		20,
		2,
		'08:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		154,
		20,
		3,
		'08:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		155,
		20,
		4,
		'08:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		156,
		20,
		5,
		'08:00:00',
		'20:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		157,
		20,
		6,
		'10:00:00',
		'20:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		158,
		21,
		2,
		'08:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		159,
		21,
		3,
		'08:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		160,
		21,
		4,
		'08:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		161,
		21,
		5,
		'08:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		162,
		21,
		6,
		'10:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		163,
		22,
		2,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		164,
		22,
		4,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		165,
		22,
		5,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		166,
		22,
		6,
		'12:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		167,
		23,
		2,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		168,
		23,
		3,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		169,
		23,
		4,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		170,
		23,
		5,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		171,
		23,
		6,
		'10:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		172,
		24,
		2,
		'10:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		173,
		24,
		4,
		'10:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		174,
		24,
		5,
		'10:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		175,
		24,
		6,
		'09:00:00',
		'23:45:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		176,
		25,
		2,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		177,
		25,
		3,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		178,
		25,
		4,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		179,
		25,
		5,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		180,
		25,
		6,
		'09:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		181,
		26,
		2,
		'08:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		182,
		26,
		3,
		'08:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		183,
		26,
		4,
		'08:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		184,
		26,
		5,
		'08:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		185,
		26,
		6,
		'08:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		186,
		27,
		3,
		'08:30:00',
		'17:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		187,
		27,
		4,
		'08:30:00',
		'17:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		188,
		27,
		5,
		'08:30:00',
		'17:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		189,
		27,
		6,
		'10:30:00',
		'18:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		190,
		28,
		2,
		'11:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		191,
		28,
		3,
		'11:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		192,
		28,
		4,
		'11:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		193,
		28,
		5,
		'11:00:00',
		'20:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		194,
		28,
		6,
		'11:00:00',
		'20:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		195,
		29,
		2,
		'10:30:00',
		'18:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		196,
		29,
		3,
		'10:30:00',
		'18:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		197,
		29,
		4,
		'10:30:00',
		'18:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		198,
		29,
		5,
		'10:30:00',
		'18:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		199,
		29,
		6,
		'10:30:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		200,
		30,
		2,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		201,
		30,
		3,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		202,
		30,
		4,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		203,
		30,
		5,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		204,
		30,
		6,
		'08:00:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		205,
		31,
		2,
		'09:00:00',
		'17:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		206,
		31,
		3,
		'09:00:00',
		'17:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		207,
		31,
		4,
		'09:00:00',
		'17:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		208,
		31,
		5,
		'09:00:00',
		'17:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		209,
		31,
		6,
		'09:00:00',
		'17:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		210,
		32,
		2,
		'10:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		211,
		32,
		3,
		'10:00:00',
		'19:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		212,
		32,
		4,
		'10:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		213,
		32,
		5,
		'10:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		214,
		32,
		6,
		'10:00:00',
		'19:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		215,
		33,
		2,
		'10:30:00',
		'18:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		216,
		33,
		3,
		'10:30:00',
		'18:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		217,
		33,
		4,
		'10:30:00',
		'18:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		218,
		33,
		5,
		'10:30:00',
		'18:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		219,
		33,
		6,
		'10:30:00',
		'18:30:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		220,
		34,
		2,
		'07:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		221,
		34,
		3,
		'07:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		222,
		34,
		4,
		'07:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		223,
		34,
		5,
		'07:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
INSERT INTO "weekly_operation_period" (
		"id",
		"shop_id",
		"weekday",
		"start_time",
		"end_time",
		"created_at",
		"updated_at"
	)
VALUES (
		224,
		34,
		6,
		'07:30:00',
		'18:00:00',
		'2023-01-18 05:20:31',
		'2023-01-18 08:33:50'
	);
insert into shop_image (shop_id, image)
select id,
	thumbnail
from shop;