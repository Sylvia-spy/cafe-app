select "order".*
from order_item
    inner join menu_coffee_variant on menu_coffee_variant.id = order_item.menu_coffee_variant_id
    inner join cafe_menu on cafe_menu.id = menu_coffee_variant.menu_id
    inner join "order" on "order"."id" = order_item.order_id
where cafe_menu.shop_id = 38