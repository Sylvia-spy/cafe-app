import Knex from "knex";
import { env } from "./env";

const knexConfig = require("./knexfile");

const profile = knexConfig[env.NODE_ENV];

export const knex = Knex(profile);
