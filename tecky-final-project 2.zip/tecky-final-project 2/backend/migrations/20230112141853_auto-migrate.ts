import { Knex } from "knex";

export async function up(knex: Knex): Promise<void> {
  if (!(await knex.schema.hasTable("district"))) {
    await knex.schema.createTable("district", (table) => {
      table.increments("id");
      table.string("name", 20).nullable();
      table.timestamps(false, true);
    });
  }

  if (!(await knex.schema.hasTable("feature"))) {
    await knex.schema.createTable("feature", (table) => {
      table.increments("id");
      table.string("name", 60).notNullable();
      table.timestamps(false, true);
    });
  }

  if (!(await knex.schema.hasTable("shop"))) {
    await knex.schema.createTable("shop", (table) => {
      table.increments("id");
      table.string("name", 255).nullable();
      table.point("latlng").notNullable();
      table.string("tel", 20).nullable();
      table.string("bean", 255).nullable();
      table.string("instagram", 255).nullable();
      table.string("facebook", 255).nullable();
      table.string("avatar", 255).nullable();
      table.string("address", 255).nullable();
      table
        .integer("district_id")
        .unsigned()
        .notNullable()
        .references("district.id");
      table.timestamps(false, true);
    });
  }

  if (!(await knex.schema.hasTable("shop_feature"))) {
    await knex.schema.createTable("shop_feature", (table) => {
      table.increments("id");
      table.integer("shop_id").unsigned().notNullable().references("shop.id");
      table
        .integer("feature_id")
        .unsigned()
        .notNullable()
        .references("feature.id");
      table.timestamps(false, true);
    });
  }

  if (!(await knex.schema.hasTable("cafe_post"))) {
    await knex.schema.createTable("cafe_post", (table) => {
      table.increments("id");
      table.integer("shop_id").unsigned().notNullable().references("shop.id");
      table.string("image", 255).nullable();
      table.string("title", 255).nullable();
      table.string("content", 255).nullable();
      table.timestamp("created_at").notNullable();
    });
  }

  if (!(await knex.schema.hasTable("shop_images"))) {
    await knex.schema.createTable("shop_images", (table) => {
      table.increments("id");
      table.integer("shop_id").unsigned().notNullable().references("shop.id");
      table.string("image", 255).notNullable();
      table.timestamps(false, true);
    });
  }

  if (!(await knex.schema.hasTable("weekly_operation_period"))) {
    await knex.schema.createTable("weekly_operation_period", (table) => {
      table.increments("id");
      table.integer("shop_id").unsigned().notNullable().references("shop.id");
      table.integer("weekday").notNullable();
      table.time("start_time").notNullable();
      table.time("end_time").notNullable();
      table.timestamps(false, true);
    });
  }
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists("weekly_operation_period");
  await knex.schema.dropTableIfExists("shop_images");
  await knex.schema.dropTableIfExists("cafe_post");
  await knex.schema.dropTableIfExists("shop_feature");
  await knex.schema.dropTableIfExists("shop");
  await knex.schema.dropTableIfExists("feature");
  await knex.schema.dropTableIfExists("district");
}
