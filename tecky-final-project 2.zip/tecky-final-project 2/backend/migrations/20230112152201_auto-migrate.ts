import { Knex } from "knex";

export async function up(knex: Knex): Promise<void> {
  await knex.schema.renameTable("shop_images", "shop_image");
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.renameTable("shop_image", "shop_images");
}
