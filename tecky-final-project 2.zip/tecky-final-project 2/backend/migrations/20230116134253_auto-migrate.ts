import { Knex } from "knex";

export async function up(knex: Knex): Promise<void> {
  await knex.raw("alter table shop add column navigation_tip text null");

  if (!(await knex.schema.hasTable("user_login"))) {
    await knex.schema.createTable("user_login", (table) => {
      table.increments("id");
      table.string("user_name", 20).notNullable();
      table.string("phone", 20).notNullable();
      table.string("hashed_pw", 60).notNullable();
      table.string("gender", 10).notNullable();
      table.date("birth_date").notNullable();
      table.boolean("is_cafe_admin").notNullable();
      table.boolean("is_admin").notNullable();
      table.timestamps(false, true);
    });
  }

  if (!(await knex.schema.hasTable("cafe_admin"))) {
    await knex.schema.createTable("cafe_admin", (table) => {
      table.increments("id");
      table
        .integer("admin_id")
        .unsigned()
        .notNullable()
        .references("user_login.id");
      table.integer("shop_id").unsigned().notNullable().references("shop.id");
      table.timestamps(false, true);
    });
  }

  if (!(await knex.schema.hasTable("cafe_menu"))) {
    await knex.schema.createTable("cafe_menu", (table) => {
      table.increments("id");
      table.integer("shop_id").unsigned().notNullable().references("shop.id");
      table.string("coffee_name", 60).notNullable();
      table.string("coffee_category", 60).notNullable();
      table.timestamps(false, true);
    });
  }

  if (!(await knex.schema.hasTable("menu_coffee_variant"))) {
    await knex.schema.createTable("menu_coffee_variant", (table) => {
      table.increments("id");
      table
        .integer("menu_id")
        .unsigned()
        .notNullable()
        .references("cafe_menu.id");
      table.string("coffee_size", 10).notNullable();
      table.float("price").notNullable();
      table.boolean("ice").notNullable();
      table.boolean("hot").notNullable();
      table.timestamps(false, true);
    });
  }

  if (!(await knex.schema.hasTable("order"))) {
    await knex.schema.createTable("order", (table) => {
      table.increments("id");
      table
        .integer("user_id")
        .unsigned()
        .notNullable()
        .references("user_login.id");
      table.string("status", 20).notNullable();
      table.timestamps(false, true);
    });
  }

  if (!(await knex.schema.hasTable("order_item"))) {
    await knex.schema.createTable("order_item", (table) => {
      table.increments("id");
      table.integer("order_id").unsigned().notNullable().references("order.id");
      table
        .integer("menu_coffee_variant")
        .unsigned()
        .notNullable()
        .references("menu_coffee_variant.id");
      table.string("special_order", 60).notNullable();
      table.boolean("is_ice").notNullable();
      table.integer("count").notNullable();
      table.timestamps(false, true);
    });
  }

  if (!(await knex.schema.hasTable("transaction"))) {
    await knex.schema.createTable("transaction", (table) => {
      table.increments("id");
      table.string("shop_name", 255).notNullable();
      table.integer("user_id").notNullable();
      table.timestamps(false, true);
    });
  }

  if (!(await knex.schema.hasTable("transaction_item"))) {
    await knex.schema.createTable("transaction_item", (table) => {
      table.increments("id");
      table
        .integer("transaction_id")
        .unsigned()
        .notNullable()
        .references("transaction.id");
      table.string("coffee_name", 60).notNullable();
      table.string("coffee_category", 60).notNullable();
      table.string("coffee_size", 10).notNullable();
      table.float("price").notNullable();
      table.boolean("is_ice").notNullable();
      table.string("special_order", 60).notNullable();
      table.timestamps(false, true);
    });
  }

  if (!(await knex.schema.hasTable("search_log"))) {
    await knex.schema.createTable("search_log", (table) => {
      table.increments("id");
      table.integer("user_id").notNullable();
      table
        .integer("feature_id")
        .unsigned()
        .notNullable()
        .references("feature.id");
      table
        .integer("district_id")
        .unsigned()
        .notNullable()
        .references("district.id");
      table.timestamps(false, true);
    });
  }
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists("search_log");
  await knex.schema.dropTableIfExists("transaction_item");
  await knex.schema.dropTableIfExists("transaction");
  await knex.schema.dropTableIfExists("order_item");
  await knex.schema.dropTableIfExists("order");
  await knex.schema.dropTableIfExists("menu_coffee_variant");
  await knex.schema.dropTableIfExists("cafe_menu");
  await knex.schema.dropTableIfExists("cafe_admin");
  await knex.schema.dropTableIfExists("user_login");
  await knex.raw('alter table "shop" drop column "navigation_tip"');
}
