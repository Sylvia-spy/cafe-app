import { Knex } from "knex";

export async function up(knex: Knex): Promise<void> {
  {
    const rows = await knex.select("id", "code").from("district");
    await knex.raw("alter table district drop column code");
    await knex.raw("alter table district add column code varchar(20)");
    for (let row of rows) {
      await knex("district").update({ code: row.code }).where({ id: row.id });
    }
  }
  {
    const rows = await knex.select("id", "navigation_tip").from("shop");
    await knex.raw("alter table shop drop column navigation_tip");
    await knex.raw("alter table shop add column navigation_tip varchar(255)");
    for (let row of rows) {
      await knex("shop")
        .update({ navigation_tip: row.navigation_tip })
        .where({ id: row.id });
    }
  }
  await knex.raw(
    "alter table user_login add column blacklist_time time not null"
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.raw("alter table user_login drop column blacklist_time");
  {
    const rows = await knex.select("id", "navigation_tip").from("shop");
    await knex.raw("alter table shop drop column navigation_tip");
    await knex.raw("alter table shop add column navigation_tip text");
    for (let row of rows) {
      await knex("shop")
        .update({ navigation_tip: row.navigation_tip })
        .where({ id: row.id });
    }
  }
  {
    const rows = await knex.select("id", "code").from("district");
    await knex.raw("alter table district drop column code");
    await knex.raw("alter table district add column code text");
    for (let row of rows) {
      await knex("district").update({ code: row.code }).where({ id: row.id });
    }
  }
}
