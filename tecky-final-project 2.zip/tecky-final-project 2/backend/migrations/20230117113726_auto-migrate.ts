import { Knex } from "knex";

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable("user_login", (table) => {
    table.setNullable("blacklist_time");
  });
  await knex.raw(
    "alter table menu_coffee_variant add column coffee_image text null"
  );
  await knex.schema.alterTable("order_item", (table) => {
    table.setNullable("special_order");
  });
}

export async function down(knex: Knex): Promise<void> {
  // await knex.schema.alterTable("order_item", (table) => {
  //   table.dropNullable("special_order");
  // });

  await knex.raw("alter table menu_coffee_variant drop column coffee_image");

  // await knex.schema.alterTable("user_login", (table) => {
  //   table.dropNullable("blacklist_time");
  // });
}
