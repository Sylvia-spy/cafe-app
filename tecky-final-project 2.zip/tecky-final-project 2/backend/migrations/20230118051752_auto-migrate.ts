import { Knex } from "knex";

export async function up(knex: Knex): Promise<void> {
  await knex.raw("alter table shop add column thumbnail text null");
  await knex.schema.alterTable("shop_image", (table) => {
    table.setNullable("image");
  });
  {
    const rows = await knex
      .select("id", "coffee_image")
      .from("menu_coffee_variant");
    await knex.raw("alter table menu_coffee_variant drop column coffee_image");
    await knex.raw(
      "alter table menu_coffee_variant add column coffee_image varchar(255)"
    );
    for (let row of rows) {
      await knex("menu_coffee_variant")
        .update({ coffee_image: row.coffee_image })
        .where({ id: row.id });
    }
  }
}

export async function down(knex: Knex): Promise<void> {
  {
    const rows = await knex
      .select("id", "coffee_image")
      .from("menu_coffee_variant");
    await knex.raw("alter table menu_coffee_variant drop column coffee_image");
    await knex.raw(
      "alter table menu_coffee_variant add column coffee_image text"
    );
    for (let row of rows) {
      await knex("menu_coffee_variant")
        .update({ coffee_image: row.coffee_image })
        .where({ id: row.id });
    }
  }
  await knex.schema.alterTable("shop_image", (table) => {
    table.dropNullable("image");
  });
  await knex.raw("alter table shop drop column thumbnail");
}
