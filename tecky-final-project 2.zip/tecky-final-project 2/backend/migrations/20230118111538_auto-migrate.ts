import { Knex } from "knex";


export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable('shop', table => {
    table.string('thumbnail', 255).nullable().alter()
  })
  await knex.schema.alterTable('user_login', table => {
    table.string('email', 255).notNullable()
  })
  await knex.schema.alterTable('menu_coffee_variant', table => {
    table.float('price').notNullable().alter()
  })
  await knex.schema.alterTable('transaction', table => {
    table.string('check_status', 255).notNullable()
  })
  await knex.schema.alterTable('transaction_item', table => {
    table.float('price').notNullable().alter()
  })
  await knex.schema.alterTable('search_log', table => {
    table.dropColumn('district_id')
    table.dropColumn('feature_id')
    table.string('feature_name', 255).nullable()
    table.string('district_name', 255).nullable()
  })
}


export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable('search_log', table => {
    table.dropColumn('district_name')
    table.dropColumn('feature_name')
    table.integer('feature_id').unsigned().notNullable().references('feature.id')
    table.integer('district_id').unsigned().notNullable().references('district.id')
  })
  await knex.schema.alterTable('transaction_item', table => {
    table.specificType('price', 'real').notNullable().alter()
  })
  await knex.schema.alterTable('transaction', table => {
    table.dropColumn('check_status')
  })
  await knex.schema.alterTable('menu_coffee_variant', table => {
    table.specificType('price', 'real').notNullable().alter()
  })
  await knex.schema.alterTable('user_login', table => {
    table.dropColumn('email')
  })
  await knex.schema.alterTable('shop', table => {
    table.text('thumbnail').nullable().alter()
  })
}
