import { Knex } from "knex";


export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable('menu_coffee_variant', table => {
    table.float('price').notNullable().alter()
  })
  await knex.schema.alterTable('transaction', table => {
    table.dropColumn('check_status')
  })
  await knex.schema.alterTable('transaction_item', table => {
    table.float('price').notNullable().alter()
  })
  await knex.schema.alterTable('search_log', table => {
    table.string('check_status', 255).notNullable()
  })
}


export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable('search_log', table => {
    table.dropColumn('check_status')
  })
  await knex.schema.alterTable('transaction_item', table => {
    table.specificType('price', 'real').notNullable().alter()
  })
  await knex.schema.alterTable('transaction', table => {
    table.string('check_status', 255).notNullable()
  })
  await knex.schema.alterTable('menu_coffee_variant', table => {
    table.specificType('price', 'real').notNullable().alter()
  })
}
