import { Knex } from "knex";


export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable('menu_coffee_variant', table => {
    table.float('price').notNullable().alter()
  })
  await knex.schema.alterTable('transaction', table => {
    table.date('user_birth_date').notNullable()
    table.string('user_gender', 10).notNullable()
  })
  await knex.schema.alterTable('transaction_item', table => {
    table.float('price').notNullable().alter()
  })
  await knex.schema.alterTable('search_log', table => {
    table.string('shop_name', 255).nullable()
  })
}


export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable('search_log', table => {
    table.dropColumn('shop_name')
  })
  await knex.schema.alterTable('transaction_item', table => {
    table.specificType('price', 'real').notNullable().alter()
  })
  await knex.schema.alterTable('transaction', table => {
    table.dropColumn('user_gender')
    table.dropColumn('user_birth_date')
  })
  await knex.schema.alterTable('menu_coffee_variant', table => {
    table.specificType('price', 'real').notNullable().alter()
  })
}
