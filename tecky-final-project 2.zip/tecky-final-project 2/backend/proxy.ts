import { proxySchema } from "better-sqlite3-proxy";
import { db } from "./db";

export type District = {
  id?: number | null;
  name: string | null;
  code: string | null;
};

export type Feature = {
  id?: number | null;
  name: string;
};

export type Shop = {
  id?: number | null;
  name: string | null;
  latlng: any; // string // point
  tel: string | null;
  bean: string | null;
  instagram: string | null;
  facebook: string | null;
  avatar: string | null;
  address: string | null;
  district_id: number;
  district?: District;
  navigation_tip: string | null;
  thumbnail: string | null;
};

export type ShopFeature = {
  id?: number | null;
  shop_id: number;
  shop?: Shop;
  feature_id: number;
  feature?: Feature;
};

export type CafePost = {
  id?: number | null;
  shop_id: number;
  shop?: Shop;
  image: string | null;
  title: string | null;
  content: string | null;
};

export type ShopImage = {
  id?: number | null;
  shop_id: number;
  shop?: Shop;
  image: string | null;
};

export type WeeklyOperationPeriod = {
  id?: number | null;
  shop_id: number;
  shop?: Shop;
  weekday: number;
  start_time: string;
  end_time: string;
};

export type UserLogin = {
  id?: number | null;
  user_name: string;
  phone: string;
  hashed_pw: string;
  gender: string;
  birth_date: string;
  is_cafe_admin: boolean;
  is_admin: boolean;
  blacklist_time: string | null;
  email: string;
};

export type CafeAdmin = {
  id?: number | null;
  admin_id: number;
  admin?: UserLogin;
  shop_id: number;
  shop?: Shop;
};

export type CafeMenu = {
  id?: number | null;
  shop_id: number;
  shop?: Shop;
  coffee_name: string;
  coffee_category: string;
};

export type MenuCoffeeVariant = {
  id?: number | null;
  menu_id: number;
  menu?: CafeMenu;
  coffee_size: string;
  price: number;
  ice: boolean;
  hot: boolean;
  coffee_image: string | null;
};

export type Order = {
  id?: number | null;
  user_id: number;
  user?: UserLogin;
  status: string;
};

export type OrderItem = {
  id?: number | null;
  order_id: number;
  order?: Order;
  menu_coffee_variant_id: number;
  menu_coffee_variant?: MenuCoffeeVariant;
  special_order: string | null;
  is_ice: boolean;
  count: number;
};

export type Transaction = {
  id?: number | null;
  shop_name: string;
  user_id: number;
  user_birth_date: string;
  user_gender: string;
};

export type TransactionItem = {
  id?: number | null;
  transaction_id: number;
  transaction?: Transaction;
  coffee_name: string;
  coffee_category: string;
  coffee_size: string;
  price: number;
  is_ice: boolean;
  special_order: string;
};

export type SearchLog = {
  id?: number | null;
  user_id: number;
  feature_name: string | null;
  district_name: string | null;
  check_status: string;
  shop_name: string | null;
};

export type DBProxy = {
  district: District[];
  feature: Feature[];
  shop: Shop[];
  shop_feature: ShopFeature[];
  cafe_post: CafePost[];
  shop_image: ShopImage[];
  weekly_operation_period: WeeklyOperationPeriod[];
  user_login: UserLogin[];
  cafe_admin: CafeAdmin[];
  cafe_menu: CafeMenu[];
  menu_coffee_variant: MenuCoffeeVariant[];
  order: Order[];
  order_item: OrderItem[];
  transaction: Transaction[];
  transaction_item: TransactionItem[];
  search_log: SearchLog[];
};

export let proxy = proxySchema<DBProxy>({
  db,
  tableFields: {
    district: [],
    feature: [],
    shop: [
      /* foreign references */
      ["district", { field: "district_id", table: "district" }],
    ],
    shop_feature: [
      /* foreign references */
      ["shop", { field: "shop_id", table: "shop" }],
      ["feature", { field: "feature_id", table: "feature" }],
    ],
    cafe_post: [
      /* foreign references */
      ["shop", { field: "shop_id", table: "shop" }],
    ],
    shop_image: [
      /* foreign references */
      ["shop", { field: "shop_id", table: "shop" }],
    ],
    weekly_operation_period: [
      /* foreign references */
      ["shop", { field: "shop_id", table: "shop" }],
    ],
    user_login: [],
    cafe_admin: [
      /* foreign references */
      ["admin", { field: "admin_id", table: "user_login" }],
      ["shop", { field: "shop_id", table: "shop" }],
    ],
    cafe_menu: [
      /* foreign references */
      ["shop", { field: "shop_id", table: "shop" }],
    ],
    menu_coffee_variant: [
      /* foreign references */
      ["menu", { field: "menu_id", table: "cafe_menu" }],
    ],
    order: [
      /* foreign references */
      ["user", { field: "user_id", table: "user_login" }],
    ],
    order_item: [
      /* foreign references */
      ["order", { field: "order_id", table: "order" }],
      [
        "menu_coffee_variant",
        { field: "menu_coffee_variant_id", table: "menu_coffee_variant" },
      ],
    ],
    transaction: [],
    transaction_item: [
      /* foreign references */
      ["transaction", { field: "transaction_id", table: "transaction" }],
    ],
    search_log: [],
  },
});
