import express from "express";
import { UserController } from "../controllers/user.controller";
import { userService } from "../services";

const userController = new UserController(userService);

export const userRoutes = express.Router();

//.post(pathname, userController的咩function)
userRoutes.post("/login", userController.login);
userRoutes.post("/register", userController.register);
