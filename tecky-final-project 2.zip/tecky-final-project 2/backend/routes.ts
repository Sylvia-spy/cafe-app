//集合D routes, line 3
import express from "express";
import { userRoutes } from "./routers/user.route";

export const routes = express.Router();
routes.use("/users", userRoutes);
