set -e
npm run build
docker build -t server .
