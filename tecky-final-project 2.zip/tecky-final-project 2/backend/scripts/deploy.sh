set -e

./scripts/build.sh
cd ..

scp docker-compose.yml server:~/cafe/
rsync -SavLP backend/uploads server:~/cafe/backend
ssh server "mkdir -p ~/cafe/backend"

docker images | grep server

docker save server:latest | gzip - | ssh server "
  gunzip - | docker load
"

ssh server "
  cd cafe \
  && docker-compose up -d
"
