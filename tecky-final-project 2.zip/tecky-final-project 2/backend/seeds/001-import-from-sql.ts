import { readdirSync, readFileSync } from "fs";
import { Knex } from "knex";
import { join } from "path";
import { hashPassword } from "../hash";
import { pg } from "../pg";

export async function seed(knex: Knex): Promise<void> {
  let row = await knex.count("id as count").from("shop").first();
  let count = +row.count;
  if (count == 0) {
    await pg.connect();

    await pg.query("BEGIN;");

    let files = readdirSync("data");
    for (let file of files) {
      let match = file.match(/^\d{3}.*\.sql$/);
      if (match) {
        console.log("import from", file);
        let sql = readFileSync(join("data", file)).toString();
        await pg.query(sql);
      }
    }

    await pg.query("COMMIT;");

    // await knex.transaction(async (knex) => {
    //   let files = readdirSync("data");
    //   for (let file of files) {
    //     let match = file.match(/^\d{3}.*\.sql$/);
    //     if (match) {
    //       console.log("import from", file);
    //       let sql = readFileSync(join("data", file)).toString();
    //       await knex.raw(sql);
    //     }
    //   }
    // });
  }

  let seqs = [
    "cafe_admin_id_seq",
    "cafe_menu_id_seq",
    "cafe_post_id_seq",
    "district_id_seq",
    "feature_id_seq",
    "menu_coffee_variant_id_seq",
    "order_id_seq",
    "order_item_id_seq",
    "search_log_id_seq",
    "shop_feature_id_seq",
    "shop_id_seq",
    "shop_images_id_seq",
    "transaction_id_seq",
    "transaction_item_id_seq",
    "user_login_id_seq",
    "weekly_operation_period_id_seq",
  ];

  for (let seq of seqs) {
    let table = seq.replace("_id_seq", "");
    if (table == "shop_images") {
      table = "shop_image";
    }
    let row = await knex.max("id as max_id").from(table).first();
    let id = row.max_id;
    if (!id) continue;
    // console.log({ table, seq, id });
    await knex.raw(`SELECT setval(?, ?, true);`, [seq, id]);
  }

  let users = await knex.select("id", "hashed_pw").from("user_login");
  for (let user of users) {
    if (user.hashed_pw.length != 60) {
      console.log("hash password for user:", user.id);
      await knex("user_login")
        .update({ hashed_pw: await hashPassword(user.hashed_pw) })
        .where({ id: user.id });
    }
  }
}
