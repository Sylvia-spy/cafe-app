import { Knex } from "knex";
import { hashPassword } from "../hash";
import {
  District,
  Feature,
  ShopFeature,
  Shop,
  CafePost,
  ShopImage,
  WeeklyOperationPeriod,
  UserLogin,
  CafeMenu,
  MenuCoffeeVariant,
  Order,
  OrderItem,
} from "../proxy";

export async function seed(knex: Knex): Promise<void> {
  function genSeedTable<T extends {}>(table: string) {
    return async function (data: T) {
      let { latlng, ...filter } = data as any;
      // console.log("filter", table, filter);
      let row = await knex(table).where(filter).select("id").first();
      if (row) return row.id;
      console.log("insert", table, data);
      let [{ id }] = await knex(table).insert(data).returning("id");
      return id;
    };
  }
  // function genSeedTableBatch<T extends {}>(table: string) {
  //   let seedTable = genSeedTable(table);
  //   return async function (samples: T[]) {
  //     for (let sample of samples) {
  //       await seedTable(sample);
  //     }
  //   };
  // }
  let seedDistrict = genSeedTable<District>("district");
  let seedFeature = genSeedTable<Feature>("feature");
  let seedShopFeature = genSeedTable<ShopFeature>("shop_feature");
  let seedShop = genSeedTable<Shop>("shop");
  let seedCafePost = genSeedTable<CafePost>("cafe_post");
  let seedShopImage = genSeedTable<ShopImage>("shop_image");
  let seedWeeklyOperationPeriod = genSeedTable<WeeklyOperationPeriod>(
    "weekly_operation_period"
  );
  let days = {
    mon: 1,
    tue: 2,
    wed: 3,
    thu: 4,
    fri: 5,
    sat: 6,
    sun: 0,
  };
  type Day = keyof typeof days;
  let shopIdx = 0;
  async function seedShopData(
    sample: Shop & {
      posts: Omit<CafePost, "shop_id">[];
      features: string[];
      images: string[];
      cafe_operation_periods: Partial<Record<Day, string>>;
    }
  ) {
    shopIdx++;
    let { posts, images, cafe_operation_periods, features, ...shop } = sample;
    shop.avatar = `https://picsum.photos/seed/${shopIdx}/200/300`;
    let shop_id = await seedShop(shop);
    // let p = 0;
    for (let post of posts) {
      post.image = `https://picsum.photos/seed/${shopIdx}/200/300`;
      await seedCafePost({ shop_id, ...post });
    }
    for (let image of images) {
      image = `https://picsum.photos/seed/${shop_id}/200/300`;
      await seedShopImage({ shop_id, image });
    }
    for (let feature of features) {
      let feature_id = await seedFeature({ name: feature });
      await seedShopFeature({ shop_id, feature_id });
    }
    for (let day in cafe_operation_periods) {
      let [start_time, end_time] =
        cafe_operation_periods[day as Day]!.split(" - ");
      await seedWeeklyOperationPeriod({
        shop_id,
        weekday: days[day as Day],
        start_time,
        end_time,
      });
    }
    return shop_id;
  }

  let shops: { id: number }[] = [];

  shops.push({
    id: await seedShopData({
      name: "Black Sugar Coffee & Lifestyle",
      latlng: knex.raw("point(22.2984901, 114.1760787)"),
      tel: "28119906",
      bean: "CELLINI Espresso Ground Coffee",
      instagram: "https://www.instagram.com/blackcoffeehk/",
      facebook: "https://www.facebook.com/blacksugarcoffeehktst/",
      avatar: "https://picsum.photos/1/237/200/300",
      thumbnail: "https://picsum.photos/1/237/200/300",
      navigation_tip: null,
      district_id: await seedDistrict({ name: "Tsim Sha Tsui", code: null }),
      address: "Shop G34, G/F, Empire Centre, 68 Mody Road, Tsim Sha Tsui",
      features: [
        "bean_for_sale",
        "milk_choices",
        "tables_seats",
        "bright",
        "sockets",
        "outdoor",
        "wifi",
        "parking",
        "washroom",
        "CBD",
        "vibes",
        "pets_friendly",
        "BYOC",
        "pets_in_store",
        "meals",
        "sweets_bites",
        "vegetarian",
        "vegan",
      ],
      cafe_operation_periods: {
        mon: "08:00 - 20:00",
        tue: "08:00 - 20:00",
        wed: "08:00 - 20:00",
        thu: "08:00 - 20:00",
        fri: "08:00 - 20:00",
        sat: "09:00 - 20:00",
        sun: "09:00 - 20:00",
      },
      images: ["https://picsum.photos/7/237/200/300"],
      posts: [
        {
          image: "https://picsum.photos/4/237/200/300",
          title: "柴柴主題Cafe",
          content:
            "好多人為咗佢慕名而來 但柴犬店長唔係日日係到 想見佢嘅話記得留意佢地ig喇",
        },
      ],
    }),
  });
  shops.push({
    id: await seedShopData({
      name: "NOC Coffee Co.",
      latlng: knex.raw("point(22.2984898, 114.1694857)"),
      tel: "21229751",
      bean: "No. 18 House Blend",
      instagram: "https://www.instagram.com/noccoffeeco/",
      facebook: "https://www.facebook.com/NOC-COFFEE-CO-107107181768448/",
      avatar: "https://picsum.photos/2/237/200/300",
      thumbnail: "https://picsum.photos/1/237/200/300",
      navigation_tip: null,
      district_id: await seedDistrict({ name: "Hung Hom", code: null }),
      address: "Shop G42, G/F, Lily Mansions (Site 9), The Whampoa, Hung Hom",
      features: [
        "bean_for_sale",
        "tables_seats",
        "bright",
        "sockets",
        "outdoor",
        "CBD",
        "vibes",
        "BYOC",
        "meals",
        "sweets_bites",
        "vegetarian",
        "vegan",
      ],
      cafe_operation_periods: {
        mon: "12:00 - 20:00",
        tue: "12:00 - 20:00",
        thu: "12:00 - 20:00",
        fri: "12:00 - 20:00",
        sat: "12:00 - 18:00",
        sun: "12:00 - 18:00",
      },
      images: ["https://picsum.photos/8/237/200/300"],
      posts: [
        {
          image: "https://picsum.photos/5/237/200/300",
          title: "多次回訪嘅cafe 必試Waffle",
          content:
            "嚟呢間cafe一定要試個waffle 加左楓糖漿同Movenpick雪糕 好好食",
        },
      ],
    }),
  });
  shops.push({
    id: await seedShopData({
      name: "Starbucks Coffee",
      latlng: knex.raw("point(22.2779654, 114.1829437)"),
      tel: null,
      bean: "Starbucks Dark Espresso Roast",
      instagram: "https://www.instagram.com/starbuckshk/",
      facebook: "https://www.facebook.com/StarbucksHongKong/",
      avatar: "https://picsum.photos/3/237/200/300",
      thumbnail: "https://picsum.photos/1/237/200/300",
      navigation_tip: null,
      district_id: await seedDistrict({ name: "Causeway Bay", code: null }),
      address:
        "Shop 101-110, 1/F, Lee Garden Three, 1 Sunning Road, Causeway Bay",
      features: [
        "bean_for_sale",
        "milk_choices",
        "decaf",
        "tables_seats",
        "bright",
        "sockets",
        "outdoor",
        "wifi",
        "washroom",
        "CBD",
        "vibes",
        "BYOC",
        "meals",
        "sweets_bites",
      ],
      cafe_operation_periods: {
        tue: "10:00 - 18:00",
        wed: "10:00 - 18:00",
        thu: "10:00 - 18:00",
        fri: "10:00 - 18:00",
        sat: "10:00 - 22:00",
        sun: "10:00 - 22:00",
      },
      images: ["https://picsum.photos/9/237/200/300"],
      posts: [
        {
          image: "https://picsum.photos/6/237/200/300",
          title: "A good place for brunch",
          content: "鬧市中難得舒適的一角 咖啡好飲",
        },
      ],
    }),
  });
  shops.push({
    id: await seedShopData({
      name: "Coffee Art",
      latlng: knex.raw("point(22.3468425,114.1962601)"),
      tel: "54037995",
      bean: "Abigail Blend Coffee Beans",
      instagram: "https://www.instagram.com/coffeeart_924/",
      facebook: "https://www.facebook.com/CoffeeArt/",
      avatar: "https://picsum.photos/4/237/200/300",
      thumbnail: "https://picsum.photos/1/237/200/300",
      navigation_tip: null,
      district_id: await seedDistrict({ name: "Tseung Kwan O", code: null }),
      address: "Shop G95, G/F, MCP I, 8 Mau Yip Road, Tseung Kwan O",
      features: [
        "bean_for_sale",
        "milk_choices",
        "decaf",
        "awarded",
        "tables_seats",
        "bright",
        "sockets",
        "outdoor",
        "wifi",
        "parking",
        "washroom",
        "CBD",
        "vibes",
        "BYOC",
        "pets_friendly",
        "pets_in_store",
        "meals",
        "sweets_bites",
        "vegan",
        "vegetarian",
      ],
      cafe_operation_periods: {
        tue: "06:00 - 00:00",
        wed: "06:00 - 00:00",
        thu: "06:00 - 00:00",
        fri: "06:00 - 00:00",
        sat: "06:00 - 00:00",
        sun: "06:00 - 00:00",
      },
      images: ["https://picsum.photos/10/237/200/300"],
      posts: [
        {
          image: "https://picsum.photos/7/237/200/300",
          title: "A good place for brunch",
          content: "咖啡好飲",
        },
      ],
    }),
  });

  async function seedRow(table: string, sample: { id?: number | null }) {
    let row = await knex(table).where(sample).select("id").first();
    if (row) {
      sample.id = row.id;
    } else {
      let rows = await knex(table).insert(sample).returning("id");
      sample.id = rows[0].id;
    }
  }

  let users: UserLogin[] = [
    {
      user_name: "123",
      phone: "23456789",
      hashed_pw: await hashPassword("123"),
      gender: "male",
      birth_date: "1922-02-02",
      is_cafe_admin: true,
      is_admin: true,
      blacklist_time: null,
      email: "abc@abc.com",
    },
    {
      user_name: "dennis",
      phone: "23456789",
      hashed_pw: await hashPassword("dennis"),
      gender: "male",
      birth_date: "1922-02-02",
      is_cafe_admin: false,
      is_admin: false,
      blacklist_time: null,
      email: "dennis@dennis.com",
    },
    {
      user_name: "peter",
      phone: "23456789",
      hashed_pw: await hashPassword("peter"),
      gender: "male",
      birth_date: "1922-02-02",
      is_cafe_admin: true,
      is_admin: true,
      blacklist_time: null,
      email: "peter@peter.com",
    },
    {
      user_name: "sylvia",
      phone: "23456789",
      hashed_pw: await hashPassword("sylvia"),
      gender: "female",
      birth_date: "1922-02-02",
      is_cafe_admin: true,
      is_admin: true,
      blacklist_time: null,
      email: "sylvia@sylvia.com",
    },
  ];
  // -------------------Normal loop for user_login---------------------------------------------
  for (let user of users) {
    await seedRow("user_login", user);
  }

  for (let shop of shops) {
    let menus: CafeMenu[] = [
      {
        shop_id: shop.id!,
        coffee_name: "Double Espresso",
        coffee_category: "Black Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Americano",
        coffee_category: "Black Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Shakerato",
        coffee_category: "Black Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Espresso Soda",
        coffee_category: "Black Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Espresso Tonic",
        coffee_category: "Black Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Expresso Macchiato",
        coffee_category: "White Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Piccolo Latte",
        coffee_category: "White Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Caffe Latte",
        coffee_category: "White Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Cappuccino",
        coffee_category: "White Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Flat White",
        coffee_category: "White Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Dirty",
        coffee_category: "White Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Caffe Vienna",
        coffee_category: "Signature Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Dark Chocolate Mocha",
        coffee_category: "Signature Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Caramel Latte",
        coffee_category: "Signature Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Hazelnut Latte",
        coffee_category: "Signature Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Matcha Latte",
        coffee_category: "Signature Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Hojicha Latte",
        coffee_category: "Signature Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Rooibos Tea Latte",
        coffee_category: "Signature Coffee",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Valrhona Milk Chocolate",
        coffee_category: "Chocolate",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Chocolate Vienna",
        coffee_category: "Chocolate",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Caramel Chocolate",
        coffee_category: "Chocolate",
      },
      {
        shop_id: shop.id!,
        coffee_name: "Hazelnut Chocolate",
        coffee_category: "Chocolate",
      },
    ];
    let shop_variants: MenuCoffeeVariant[] = [];
    for (let menu of menus) {
      await seedRow("cafe_menu", menu);
      let variants: MenuCoffeeVariant[] = [
        {
          menu_id: menu.id!,
          coffee_size: "small",
          price: 40,
          ice: true,
          hot: false,
          coffee_image: "ice_coffee.png",
        },
        {
          menu_id: menu.id!,
          coffee_size: "medium",
          price: 50,
          ice: true,
          hot: false,
          coffee_image: "ice_coffee.png",
        },
        {
          menu_id: menu.id!,
          coffee_size: "big",
          price: 60,
          ice: true,
          hot: false,
          coffee_image: "ice_coffee.png",
        },
        {
          menu_id: menu.id!,
          coffee_size: "small",
          price: 35,
          ice: false,
          hot: true,
          coffee_image: "hot_coffee.png",
        },
        {
          menu_id: menu.id!,
          coffee_size: "medium",
          price: 45,
          ice: false,
          hot: true,
          coffee_image: "hot_coffee.png",
        },
        {
          menu_id: menu.id!,
          coffee_size: "big",
          price: 55,
          ice: false,
          hot: true,
          coffee_image: "hot_coffee.png",
        },
      ];
      for (let variant of variants) {
        await seedRow("menu_coffee_variant", variant);
        shop_variants.push(variant);
      }
    }
    // -------------------loop from users data > order & shop_variants > order_item---------------------------------------------

    for (let user of users) {
      let orders: Order[] = [
        {
          user_id: user.id!,
          status: "New",
        },
        {
          user_id: user.id!,
          status: "Pending",
        },
        {
          user_id: user.id!,
          status: "Finished",
        },
      ];

      for (let order of orders) {
        await seedRow("order", order);

        let sampleVariantId = () =>
          shop_variants.slice().sort((a, b) => Math.random() - 0.5)[0].id!;

        let orderItems: OrderItem[] = [
          {
            order_id: order.id!,
            menu_coffee_variant_id: sampleVariantId(),
            special_order: "多奶",
            is_ice: true,
            count: 3,
          },
          {
            order_id: order.id!,
            menu_coffee_variant_id: sampleVariantId(),
            special_order: null,
            is_ice: true,
            count: 1,
          },
          {
            order_id: order.id!,
            menu_coffee_variant_id: sampleVariantId(),

            special_order: "少奶",
            is_ice: true,
            count: 2,
          },
          {
            order_id: order.id!,
            menu_coffee_variant_id: sampleVariantId(),

            special_order: null,
            is_ice: false,
            count: 1,
          },
          {
            order_id: order.id!,
            menu_coffee_variant_id: sampleVariantId(),

            special_order: "笑容",
            is_ice: false,
            count: 1,
          },
          {
            order_id: order.id!,
            menu_coffee_variant_id: sampleVariantId(),

            special_order: "大大個笑容",
            is_ice: false,
            count: 1,
          },
        ];
        for (let item of orderItems) {
          await seedRow("order_item", item);
        }
      }
    }
  }
  for (let i = 0; i < users.length; i++) {
    await knex("cafe_admin").insert([
      { admin_id: users[i].id, shop_id: shops[i].id },
    ]);
  }
}
