import { AdminProfileService } from "./services/adminProfile.service";
import { AdminProfileController } from "./controllers/adminProfile.controller";
import { uploadDir } from "./uploads";
// import { UserService } from "./services/user.service";
import cors from "cors";
import express, { NextFunction, Request, Response } from "express";
// import expressSession from "express-session";
import { print } from "listening-on";

// import { cafeRoute } from "./router";
import { ShopService } from "./services/shop.service";
import { ShopController } from "./controllers/shop.controller";
import { knex } from "./knex";
import { PosService } from "./services/pos.service";
import { PosController } from "./controllers/pos.controller";
import { routes } from "./routes";
import { PostController } from "./controllers/post.controller";
import { postService, userService } from "./services";
import { HttpError } from "./http.error";
import { env } from "./env";
import { resolve } from "path";

const app = express();
const PORT = env.WEB_PORT;

app.use(
  cors({
    // origin: [process.env.REACT_DOMAIN!],
    // Credential: true,
  })
);

// app.use(
//   expressSession({
//     secret: process.env.EXPRESS_SESSION!,
//     saveUninitialized: true,
//     resave: false,
//   })
// );

app.use(express.static("public"));
app.use("/uploads", express.static(uploadDir));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  console.log(req.method, req.url);
  next();
});
// --------------------------Shop Service--------------------------------------

const shopService = new ShopService(knex);
const shopController = new ShopController(shopService);

app.use("/api", shopController.router);

app.use("/api", routes);

// ----------------------------------------------------------------

const posService = new PosService(knex, userService);
const posController = new PosController(posService);

app.use("/api", posController.router);

// --------------------------Admin Post Service--------------------------------------

const postController = new PostController(postService, userService);
app.use("/api", postController.router);

// --------------------------Admin Profile Service--------------------------------------
const adminProfileService = new AdminProfileService(knex);
const adminProfileController = new AdminProfileController(
  adminProfileService,
  userService
);

app.use("/api", adminProfileController.router);
// ----------------------------------------------------------------
// const jwt = require("jsonwebtoken");

// const posts = [
//   {
//     username: "Dennis",
//     title: "Post 1",
//   },
//   {
//     username: "lala",
//     title: "Post 2",
//   },
// ];
// app.get("/posts", (req, res) => {
//   res.json(posts);
// });

// app.get("./login", (req, res) => {
//   const username = req.body.username;
//   const user = { name: username };
//   const accessToken = jwt.sign(user, process.env.ACCESS_TOKEN_SECRET);
//   res.json({ accessToken: accessToken });
// });

//put at the end

app.use("/api", (req, res) => {
  // let filePath = path.join(__dirname, "public", "404.html");
  // console.log("404", req.url);
  // res.sendFile(path.join(filePath));
  res.status(404);
  res.json({ error: "route not matched", url: req.url, method: req.method });
});

app.use((req, res) => {
  if (req.method == "GET") {
    res.sendFile(resolve("public", "index.html"));
    return;
  }

  // let filePath = path.join(__dirname, "public", "404.html");
  // console.log("404", req.url);
  // res.sendFile(path.join(filePath));
  res.status(404);
  res.json({ error: "route not matched", url: req.url, method: req.method });
});

app.use((error: HttpError, req: Request, res: Response, next: NextFunction) => {
  console.log(error);
  res.status(error.statusCode || 500);
  res.json({
    error: String(error).replace("TypeError: ", "").replace("Error: ", ""),
  });
});

// ----------------------------------------------------------------

app.listen(PORT, () => {
  print(PORT);
});
