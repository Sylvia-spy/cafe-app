import { Knex } from "knex";
import { HttpError } from "../http.error";

export class AdminProfileService {
  constructor(public knex: Knex) {}

  shopTable() {
    return this.knex("shop");
  }

  //////////////////////////////////admin show profile//////////////////////////////////
  async getCafeProfile(shop_id: number) {
    let cafeProfile = await this.knex("shop")
      .select(
        "shop.id",
        "shop.name as shop_name",
        "shop_image.image as image",
        "shop.tel",
        "shop.instagram",
        "shop.facebook",
        "shop.address",
        "shop.avatar",
        "shop.latlng",
        "shop.thumbnail",
        "district.name as district_name"
      )
      .innerJoin("district", "district.id", "=", "shop.district_id")
      .innerJoin("shop_image", "shop_image.shop_id", "=", "shop.id")
      .where("shop.id", shop_id)
      .first();

    if (!cafeProfile) {
      throw new HttpError(404, "shop not found");
    }

    cafeProfile.features = await this.knex
      .from("feature")
      .select("feature.name", "shop_id as has")
      //method 1
      // .leftJoin(
      //   "shop_feature",
      //   this.knex.raw(
      //     `feature.id = shop_feature.feature_id and shop_id = ?`,
      //     cafeProfile.id
      //   )
      // );

      //method 2
      .leftJoin("shop_feature", "shop_feature.feature_id", "feature.id")
      .where("shop_feature.shop_id", "=", cafeProfile.id);

    cafeProfile.openingHours = await this.knex
      .select(
        "weekly_operation_period.weekday",
        "weekly_operation_period.start_time",
        "weekly_operation_period.end_time"
      )
      .from("weekly_operation_period")
      .where("shop_id", cafeProfile.id);

    return { cafeProfile };
  }

  //////////////////////////////////admin update basic information//////////////////////////////////
  async updateBasicInfo(
    shop_id: number,
    shop: {
      name: string;
      address: string;
      tel: string;
      instagram: string;
      facebook: string;
    }
  ) {
    await this.knex("shop").where({ id: shop_id }).update(shop);
    return {};
  }
  //////////////////////////////////admin update operation time//////////////////////////////////
  async updateOperationTime(
    shop_id: number,
    operationTimes: {
      weekday: number;
      start_time: string;
      end_time: string;
    }[]
  ) {
    for (let day of operationTimes) {
      await this.knex("weekly_operation_period")
        .where({
          shop_id: shop_id,
          weekday: day.weekday,
        })
        .update({
          start_time: day.start_time,
          end_time: day.end_time,
        });
    }
    return {};
  }

  //////////////////////////////////admin update features//////////////////////////////////
  async updateFeatures(shop_id: number, features: string[]) {
    await this.knex.transaction(async (knex) => {
      await knex("shop_feature").where({ shop_id }).delete();
      for (let name of features) {
        let row = await knex("feature").select("id").where({ name }).first();
        if (row) {
          await knex("shop_feature").insert({ shop_id, feature_id: row.id });
        }
      }
    });
    return {};
  }
}
