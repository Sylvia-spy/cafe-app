import { knex } from "../knex";
import { PostService } from "./post.service";
import { UserService } from "./user.service";

export const postService = new PostService(knex);
export const userService = new UserService(knex);
