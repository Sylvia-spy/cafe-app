import { Knex } from "knex";
import { HttpError } from "../http.error";
import { UserService } from "./user.service";

export class PosService {
  constructor(public knex: Knex, public userService: UserService) {}

  shopTable() {
    return this.knex("shop");
  }
  //------------------------GET CafeMenu----------------------------------------
  async getCafeMenu(id: string) {
    let shop = await this.shopTable()
      .select(
        "shop.id",
        "shop.name as shop_name",
        "shop.thumbnail",
        "shop.avatar",
        "shop.address"
      )
      .where({ "shop.id": id })
      .first();

    if (!shop) {
      throw new HttpError(404, "cant get coffee menu");
    }

    shop.menu = await this.knex
      .from("cafe_menu")
      .select(
        "cafe_menu.id",
        "cafe_menu.coffee_name",
        "cafe_menu.coffee_category"
      )
      .where("shop_id", shop.id);

    shop.coffee_variant = await this.knex

      .from("menu_coffee_variant")
      .select(
        "menu_coffee_variant.id",
        "menu_coffee_variant.menu_id",
        "menu_coffee_variant.coffee_size",
        "menu_coffee_variant.price",
        "menu_coffee_variant.ice",
        "menu_coffee_variant.hot",
        "menu_coffee_variant.coffee_image"
      )
      .innerJoin("cafe_menu", "menu_coffee_variant.menu_id", "cafe_menu.id")
      .where("shop_id", shop.id);

    //   let data = await this.knex.raw(
    //     `select coffee_name,coffee_category,coffee_size,price,ice,hot,coffee_image from menu_coffee_variant join cafe_menu on cafe_menu.id=menu_id join shop on cafe_menu.shop_id=shop.id where shop.id=?`,
    //     id
    //   );

    //   let result = data.rows;
    // console.log("menu info:", result);

    return { shop };
  }

  getOrderQuery() {
    return this.knex
      .from("order_item")
      .select(
        "order.id",
        "order.status",
        "order_item.id as item_id",
        "order_item.order_id",
        "order_item.menu_coffee_variant_id",
        "order_item.special_order",
        "order_item.is_ice",
        "order_item.count",
        "menu_coffee_variant.id as variant_id",
        "menu_coffee_variant.menu_id",
        "menu_coffee_variant.coffee_size",
        "menu_coffee_variant.price",
        "menu_coffee_variant.ice",
        "menu_coffee_variant.hot",
        "menu_coffee_variant.coffee_image",
        "cafe_menu.coffee_name",
        "cafe_menu.coffee_category",
        "cafe_menu.shop_id",
        "shop.id as cafe_id",
        "shop.name as cafe_name",
        "shop.address as cafe_address",
        "shop.avatar as cafe_avatar"
      )
      .join("order", "order_item.order_id", "order.id")
      .join(
        "menu_coffee_variant",
        "order_item.menu_coffee_variant_id",
        "menu_coffee_variant.id"
      )
      .join("cafe_menu", "menu_coffee_variant.menu_id", "cafe_menu.id")
      .join("shop", "cafe_menu.shop_id", "shop.id");
  }

  //------------------------GET Order----------------------------------------
  async getOrderByUser(user_id: number) {
    let user = await this.knex("user_login")
      .select(
        "user_login.id",
        "user_login.user_name",
        "user_login.phone",
        "user_login.birth_date",
        "user_login.email"
      )
      .where({ "user_login.id": user_id })
      .first();

    if (!user) {
      throw new HttpError(404, "cant get user info");
    }

    user.order = await this.getOrderQuery().where("user_id", user.id);
    return { user };
  }
  async getOrderByShop(user_id: number) {
    let shop_id = await this.userService.findShopByUserId(user_id);

    let user = await this.knex("user_login")
      .select(
        "user_login.id",
        "user_login.user_name",
        "user_login.phone",
        "user_login.birth_date",
        "user_login.email"
      )
      .where({ "user_login.id": user_id })
      .first();

    if (!user) {
      throw new HttpError(404, "cant get user info");
    }

    user.order = await this.getOrderQuery().where("shop.id", shop_id);
    return { user };
  }

  //------------------------ POST Order ----------------------------------------
  async postOrder(
    items: { variants_id: number; count: number }[],
    user_id: number | string
  ) {
    let [{ id: order_id }] = await this.knex("order")
      .insert({ user_id: user_id, status: "New" })
      .returning("id");

    for (let item of items) {
      await this.knex("order_item").insert({
        order_id,
        menu_coffee_variant_id: item.variants_id,
        special_order: null,
        is_ice: false,
        count: item.count,
      });
    }
    return { order_id };
  }
  //------------- UPDATE Order status to Reject -----------

  async updateOrderStatusToReject(order_id: number) {
    let status = await this.knex("order")
      .update({ status: "Reject" })
      .where({ id: order_id });
    return status;
  }
  //------------- UPDATE Order status to New -----------

  async updateOrderStatusToNew(order_id: number) {
    let status = await this.knex("order")
      .update({ status: "New" })
      .where({ id: order_id });
    return status;
  }
  //------------- UPDATE Order status to Pending -----------
  async updateOrderStatusToPending(order_id: number) {
    let status = await this.knex("order")
      .update({ status: "Pending" })
      .where({ id: order_id });
    return status;
  }
  //------------- UPDATE Order status to Finished -----------

  async updateOrderStatusToFinished(order_id: number) {
    let status = await this.knex("order")
      .update({ status: "Finished" })
      .where({ id: order_id });
    return status;
  }
  //------------- UPDATE Order status to received -----------

  async updateOrderStatusToReceived(order_id: number) {
    let status = await this.knex("order")
      .update({ status: "Received" })
      .where({ id: order_id });
    return status;
  }
}
