import { Knex } from "knex";
import { HttpError } from "../http.error";

export class PostService {
  constructor(private knex: Knex) {}

  postTable() {
    return this.knex("cafe_post");
  }

  //////////////////////////////////admin add new post//////////////////////////////////
  async addNewPost(
    user_id: number,
    post: {
      shop_id: number;
      image: string;
      title: string;
      content: string;
    }
  ) {
    let row = await this.knex("cafe_admin")
      .where({
        admin_id: user_id,
        shop_id: post.shop_id,
      })
      .first();
    if (!row) throw new HttpError(403, "you are not the shop admin");

    let [{ id }] = await this.postTable().insert(post).returning("id");

    return { id };
  }

  //////////////////////////////////admin show all post//////////////////////////////////
  async showAllPost(shop_id: number) {
    let allPost = await this.postTable()
      .select(
        "cafe_post.id",
        "cafe_post.shop_id",
        "cafe_post.image",
        "cafe_post.title",
        "cafe_post.content"
      )
      .where({ shop_id });
    return { allPost };
  }

  //////////////////////////////////admin delete post//////////////////////////////////
  async deletePost(input: { user_id: number; post_id: number }) {
    let row = await this.knex("cafe_post")
      .innerJoin("shop", "shop.id", "cafe_post.shop_id")
      .innerJoin("cafe_admin", "cafe_admin.shop_id", "shop.id")
      .where({
        "cafe_admin.admin_id": input.user_id,
        "cafe_post.id": input.post_id,
      })
      .first();
    // console.log(input);
    if (!row) throw new HttpError(403, "you are not the shop admin");

    await this.postTable().where({ id: input.post_id }).delete();
    return {};
  }
}
