//get method set up (Step 1: edit shop.service.ts)

import { Knex } from "knex";
import { HttpError } from "../http.error";

export class ShopService {
  constructor(public knex: Knex) {}

  //function 可減少打錯table name
  shopTable() {
    return this.knex("shop");
  }

  //home page: shop post
  async getCafePost() {
    let cafePost = await this.shopTable()
      .select(
        "shop.id as shop_id",
        "cafe_post.id as post_id",
        "shop.name as shop_name",
        "cafe_post.image as post_image",
        "cafe_post.title",
        "cafe_post.content"
      )
      .join("cafe_post", "cafe_post.shop_id", "=", "shop.id")
      .orderBy("shop.id", "desc")
      .limit(10);
    return { cafePost };
  }

  //home page: new shop array (10 only)
  async getNewShop() {
    let newShops = await this.shopTable()
      .select(
        "shop.id",
        "shop.name as shop_name",
        "shop.avatar",
        "district.name as district_name"
      )
      .join("district", "district.id", "=", "shop.district_id")
      .orderBy("shop.id", "desc")
      .limit(10);
    return { newShops };
  }

  //all cafe info page: shop list
  async getShopList(features: string[]) {
    let query = this.shopTable()
      .select(
        "shop.id",
        "shop.name as shop_name",
        "shop_image.image as image",
        "district.name as district_name"
      )
      //innerJoin = 一定有呢樣野先show; leftJoin = 唔洗有呢樣野都會show
      .leftJoin("shop_image", "shop_image.shop_id", "=", "shop.id")
      .innerJoin("district", "district.id", "=", "shop.district_id");

    for (let feature of features) {
      query = query.whereIn(
        "shop.id",
        this.knex
          .from("shop_feature")
          .select("shop_id")
          .innerJoin("feature", "feature.id", "feature_id")
          .where("feature.name", feature)
      );
    }

    console.log("query.toSQL()", query.toSQL());

    let shops = await query;

    for (let shop of shops) {
      shop.openingHours = await this.knex
        .select(
          "weekly_operation_period.weekday",
          "weekly_operation_period.start_time",
          "weekly_operation_period.end_time"
        )
        .from("weekly_operation_period")
        .where("shop_id", shop.id);
    }

    return { shops };
  }

  //all cafe info page: shop list + id?
  async getShopDetail(id: string) {
    // console.log(id);

    let shop = await this.knex("shop")
      .select(
        "shop.id",
        "shop.name as shop_name",
        "shop_image.image as image",

        "shop.tel",
        "shop.instagram",
        "shop.facebook",
        "shop.address",
        "shop.avatar",
        "shop.latlng",
        // "shop_image.image",
        "shop.thumbnail",
        "district.name as district_name"
      )
      .leftJoin("shop_image", "shop_image.shop_id", "=", "shop.id")
      .innerJoin("district", "district.id", "=", "shop.district_id")

      // .leftJoin("shop_image", "shop_image.shop_id", "=", "shop.id")
      .where({ "shop.id": id })
      .first();

    if (!shop) {
      throw new HttpError(404, "shop not found");
    }

    shop.features = await this.knex
      .from("feature")
      .select("feature.name", "shop_id as has")
      .leftJoin(
        "shop_feature",
        this.knex.raw(
          `feature.id = shop_feature.feature_id and shop_id = ?`,
          id
        )
      );
    shop.openingHours = await this.knex
      .select(
        "weekly_operation_period.weekday",
        "weekly_operation_period.start_time",
        "weekly_operation_period.end_time"
      )
      .from("weekly_operation_period")
      .where("shop_id", shop.id);
    return { shop };
  }

  //map page: get shop address and latlng
  async getCafeLatLng() {
    let cafeAddress = await this.shopTable().select(
      "shop.id as shop_id",
      "shop.name as shop_name",
      "shop.latlng",
      "shop.address"
    );
    return { cafeAddress };
  }
}
