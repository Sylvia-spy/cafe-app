//service做internal checking
import { Knex } from "knex";
import { comparePassword, hashPassword } from "../hash";
import { HttpError } from "../http.error";
import { encodeJWT, JWTPayload } from "../jwt";

export class UserService {
  constructor(private knex: Knex) {}

  //function 可減少打錯table name, 下面係攞番knex 的table = user_login
  userTable() {
    return this.knex("user_login");
  }

  //////////////////////////////////login part: step 2//////////////////////////////////
  async login(input: { user_name: string; password: string }) {
    let user = await this.userTable()
      .select("id", "hashed_pw", "is_admin", "is_cafe_admin")
      //用.where, 第一個係對番db, 第二個係對番個input
      .where("user_name", "=", input.user_name)
      //用.first比出嚟嘅野係object, 唔係array
      .first();

    //上面定義完user, 下面就睇db有無資料, 無就throw error
    //service係攞唔到response, 所以error handling要用throw new HttpError(404, "user not found")
    //而controller負責做res, req, 所以res.status(404).json({msg: "missing username/pw"})呢個寫法係controller先用到
    if (!user) throw new HttpError(404, "user not found");

    //拆個comparePassword出嚟先, 如果放埋落下面if做會好亂
    let is_matched = await comparePassword({
      //下面係user打嘅pw
      password: input.password,
      //下面係db的hashed_pw, 因為上面比緊object, 咁呢個就直接user.hashed_pw攞到個value
      password_hash: user.hashed_pw,
    });

    if (!is_matched) {
      throw new HttpError(401, "wrong username or password");
    }

    //有user而密碼都岩啦, 呢個時候砌jwt
    const payload: JWTPayload = {
      id: user.id,
      username: user.user_name,
      is_admin: user.is_admin,
      is_cafe_admin: user.is_cafe_admin,
    };

    //加密jwt
    const token = encodeJWT(payload);

    //return比controller就用object括起, 方便controller拆
    return { token };
  }

  //////////////////////////////////register part: step 2//////////////////////////////////
  async register(input: {
    user_name: string;
    phone: number;
    gender: string;
    birth_date: string;
    hashed_pw: string;
    email: string;
  }) {
    let [{ id }] = await this.userTable()
      .insert({
        //db名: input名
        user_name: input.user_name,
        phone: input.phone,
        gender: input.gender,
        birth_date: input.birth_date,
        hashed_pw: await hashPassword(input.hashed_pw),
        email: input.email,
        is_admin: false,
        is_cafe_admin: false,
      })
      .returning("id");

    //controller check哂資料齊唔齊, 呢個時候砌jwt
    const payload: JWTPayload = {
      id,
      is_admin: false,
      username: input.user_name,
      is_cafe_admin: false,
    };

    //加密jwt
    const token = encodeJWT(payload);

    //return比controller就用object括起, 方便controller拆
    return { token };
  }

  //////////////////////////////////profile db攞野 part: step 2//////////////////////////////////
  async getProfile(id: number) {
    let profile = await this.userTable()
      .select("is_admin", "user_name", "phone")
      .where({ id })
      .first();
    if (!profile) throw new HttpError(404, "user not found");
    return { profile };
  }

  async findShopByUserId(admin_id: number) {
    let row = await this.knex("cafe_admin")
      .where({ admin_id })
      .select("shop_id")
      .first();
    if (!row) throw new HttpError(404, "this user is not a shop admin");
    return row.shop_id as number;
  }
}
