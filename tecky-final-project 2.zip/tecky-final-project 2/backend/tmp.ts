// let features = [
//   {
//     id: 1,
//     shop_id: 1,
//     bean_for_sale: true,
//     milk_choices: true,
//     decaf: false,
//     awarded: false,
//   },
//   {
//     id: 2,
//     shop_id: 2,
//     bean_for_sale: true,
//     milk_choices: false,
//     decaf: false,
//     awarded: false,
//   },
//   {
//     id: 3,
//     shop_id: 3,
//     bean_for_sale: true,
//     milk_choices: true,
//     decaf: true,
//     awarded: false,
//   },
//   {
//     id: 1,
//     shop_id: 1,
//     tables_seats: true,
//     bright: true,
//     sockets: true,
//     outdoor: true,
//     wifi: true,
//     parking: true,
//     washroom: true,
//   },
//   {
//     id: 2,
//     shop_id: 2,
//     tables_seats: true,
//     bright: true,
//     sockets: true,
//     outdoor: true,
//     wifi: false,
//     parking: false,
//     washroom: false,
//   },
//   {
//     id: 3,
//     shop_id: 3,
//     tables_seats: true,
//     bright: true,
//     sockets: true,
//     outdoor: true,
//     wifi: true,
//     parking: false,
//     washroom: true,
//   },
//   {
//     id: 1,
//     shop_id: 1,
//     CBD: true,
//     vibes: true,
//     pets_friendly: true,
//     BYOC: true,
//     pets_in_store: true,
//   },
//   {
//     id: 2,
//     shop_id: 2,
//     CBD: true,
//     vibes: true,
//     pets_friendly: false,
//     BYOC: true,
//     pets_in_store: false,
//   },
//   {
//     id: 3,
//     shop_id: 3,
//     CBD: true,
//     vibes: true,
//     pets_friendly: false,
//     BYOC: true,
//     pets_in_store: false,
//   },
//   {
//     id: 1,
//     shop_id: 1,
//     meals: true,
//     sweets_bites: true,
//     vegetarian: true,
//     vegan: true,
//   },
//   {
//     id: 2,
//     shop_id: 2,
//     meals: true,
//     sweets_bites: true,
//     vegetarian: true,
//     vegan: true,
//   },
//   {
//     id: 3,
//     shop_id: 3,
//     meals: true,
//     sweets_bites: true,
//     vegetarian: false,
//     vegan: false,
//   },
// ];
// let shops: string[][] = [];
// for (let sample of features) {
//   let { id, shop_id, ...features } = sample;
//   for (let feature in features) {
//     // @ts-ignore
//     let has = features[feature];
//     if (!has) continue;
//     let shop = shops[shop_id];
//     if (!shop) {
//       shop = [];
//       shops[shop_id] = shop;
//     }
//     shop.push(feature);
//   }
// }
// console.log(shops);
