import formidable from "formidable";
import fs from "fs";

export const uploadDir = "uploads";
fs.mkdirSync(uploadDir, { recursive: true });

let counter = 0;

export const form = formidable({
  uploadDir,
  maxFiles: 1,
  maxFileSize: 200 * 1024 ** 2, // the default limit is 200KB
  // keepExtensions: true,
  filename(name, ext, part, form) {
    // console.log({ name, ext });
    // console.log(part);
    let extname = part.mimetype?.replace("image/", "");
    let timestamp = Date.now();
    counter++;
    return `${timestamp}-${counter}.${extname}`;
  },
  filter: (part) => {
    // console.log(part);
    return part.mimetype?.startsWith("image/") || false;
  },
});
