set -e

npm run build
ssh server "mkdir -p ~/cafe/frontend"
rsync -SavLP build server:~/cafe/frontend
