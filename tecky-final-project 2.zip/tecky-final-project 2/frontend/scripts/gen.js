let fs = require("fs");
let code = "";
let names = [];
fs.readdirSync("src/logo").forEach((filename) => {
  if (filename.endsWith(".ts")) return;
  if (filename.endsWith(".tsx")) return;
  if (filename.endsWith(".scss")) return;
  let name = filename.replace(/-/g, "_").match(/\w+/)[0];
  code += `import ${name} from './${filename}'
`;
  names.push(name);
});
code += `
export let icons = {${names}}`;
fs.writeFileSync("src/logo/index.ts", code);
