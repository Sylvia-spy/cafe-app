import { Redirect, Route } from "react-router-dom";
import {
  IonApp,
  IonButton,
  IonButtons,
  IonIcon,
  IonLabel,
  IonModal,
  IonRouterOutlet,
  IonTabBar,
  IonTabButton,
  IonTabs,
  IonToolbar,
  setupIonicReact,
} from "@ionic/react";
import { IonReactRouter } from "@ionic/react-router";
import {
  cafe,
  home,
  navigate,
  cartOutline,
  personCircleOutline,
  bookmarksOutline,
  bulbOutline,
} from "ionicons/icons";
import Home from "./pages/Home";
import Profile from "./pages/Profile";
import AllCafeInfo from "./pages/AllCafeInfo";

/* Core CSS required for Ionic components to work properly */
import "@ionic/react/css/core.css";

/* Basic CSS for apps built with Ionic */
import "@ionic/react/css/normalize.css";
import "@ionic/react/css/structure.css";
import "@ionic/react/css/typography.css";

/* Optional CSS utils that can be commented out */
import "@ionic/react/css/padding.css";
import "@ionic/react/css/float-elements.css";
import "@ionic/react/css/text-alignment.css";
import "@ionic/react/css/text-transformation.css";
import "@ionic/react/css/flex-utils.css";
import "@ionic/react/css/display.css";

/* Theme variables */
import "./theme/variables.css";
import MapPage from "./pages/MapPage";
import CafeDetail from "./pages/CafeDetail";
import { routes } from "./routes";
import Login, { LoginContent } from "./pages/Login";
import UpdateCafeInfo from "./pages/UpdateCafeInfo";
import POSNewOrder from "./pages/POSNewOrder";
import CafePostManage from "./pages/UpdatePost";
import MenuList from "./pages/MenuList";
import ShoppingCart from "./pages/ShoppingCart";
import MyOrder from "./pages/MyOrder";
import Register, { RegisterContent } from "./pages/Register";
import useToken, { useLoginUser } from "./hooks/useToken";
import useLoginModal from "./hooks/useLoginModal";
// import { useState } from "react";
import styles from "./pages/Register.module.scss";
import appstyles from "./App.module.scss";

setupIonicReact();

function UserRoutes() {
  //check 有無login
  // const token = useSelector((state: IRootState) => state.user.token);
  const token = useToken();

  const loginModal = useLoginModal();
  const { showLoginAlert } = loginModal;

  return (
    <>
      <IonTabs>
        <IonRouterOutlet>
          <Route exact path="/">
            <Redirect to="/home" />
          </Route>
          <Route exact path={routes.home}>
            <Home />
          </Route>
          <Route exact path={routes.cafeList}>
            <AllCafeInfo />
          </Route>
          <Route exact path={routes.cafeDetail(":id")}>
            <CafeDetail />
          </Route>
          <Route exact path={routes.mapPage}>
            <MapPage />
          </Route>
          <Route exact path={routes.profile}>
            <Profile />
          </Route>
          <Route exact path={routes.login}>
            <Login />
          </Route>
          <Route exact path={routes.register}>
            <Register />
          </Route>
          <Route exact path={routes.menuList(":id")}>
            <MenuList />
          </Route>
          <Route exact path={routes.MyOrder}>
            <MyOrder />
          </Route>
          <Route exact path={routes.ShoppingCart}>
            <ShoppingCart />
          </Route>
        </IonRouterOutlet>

        <IonTabBar slot="bottom" className={appstyles.tab_bar}>
          <IonTabButton tab="tab1" href="/home" className={appstyles.iontab}>
            <IonIcon icon={home} />
            <IonLabel>Home</IonLabel>
          </IonTabButton>
          <IonTabButton
            tab="tab2"
            href="/allCafeInfo"
            className={appstyles.iontab}
          >
            <IonIcon icon={cafe} />
            <IonLabel>Cafe</IonLabel>
          </IonTabButton>
          <IonTabButton tab="Map" href="/map" className={appstyles.iontab}>
            <IonIcon icon={navigate} />
            <IonLabel>Map</IonLabel>
          </IonTabButton>
          <IonTabButton
            className={appstyles.iontab}
            tab="MyOrder"
            onClick={showLoginAlert}
            href={token ? "/MyOrder" : undefined}
          >
            <IonIcon icon={cartOutline} />
            <IonLabel>MyOrder</IonLabel>
          </IonTabButton>
          {/* tab作用係click個時console 反應到 */}
          {/* href係undefined會禁唔到呢頁 */}
          {/* <IonTabButton
            tab="Setting"
            onClick={showLoginAlert}
            href={token ? "/admin/profile" : undefined}
          >
            <IonIcon icon={personCircle} />
            <IonLabel>Profile</IonLabel>
          </IonTabButton> */}
        </IonTabBar>
      </IonTabs>
    </>
  );
}

const AdminRoutes: React.FC = () => (
  // --------------------- logout -------------------------------------------
  // const { setToken } = useTokenState();
  // const [checkStatus, setCheckStatus] = useState();

  // function logoutClear() {
  //   console.log("logout ?");
  //   const status = setCheckStatus(checkStatus);
  //   setToken("");
  // }
  <>
    <IonTabs>
      <IonRouterOutlet>
        <Route exact path="/">
          <Redirect to={routes.updateCafeInfo} />
        </Route>
        <Route exact path={routes.updateCafeInfo}>
          <UpdateCafeInfo />
        </Route>
        <Route exact path={routes.POSNewOrder}>
          <POSNewOrder />
        </Route>
        <Route exact path={routes.updatePost}>
          <CafePostManage />
        </Route>
      </IonRouterOutlet>

      <IonTabBar slot="bottom" className={appstyles.tab_bar}>
        <IonTabButton
          tab="POSNewOrder"
          href={routes.POSNewOrder}
          className={appstyles.iontab}
        >
          <IonIcon icon={bulbOutline} />
          <IonLabel>Order</IonLabel>
        </IonTabButton>
        <IonTabButton
          tab="updatePost"
          href={routes.updatePost}
          className={appstyles.iontab}
        >
          <IonIcon icon={bookmarksOutline} />
          <IonLabel>Post</IonLabel>
        </IonTabButton>
        <IonTabButton
          tab="Cafe_Profile"
          href={routes.updateCafeInfo}
          className={appstyles.iontab}
        >
          <IonIcon icon={personCircleOutline} />
          <IonLabel>Cafe Profile</IonLabel>
        </IonTabButton>
        {/* <IonTabButton tab="logout"  onClick={logoutClear} href={"/"}>
            <IonIcon icon={personCircleOutline} />
            <IonLabel>Logout</IonLabel>
          </IonTabButton> */}
      </IonTabBar>
    </IonTabs>
  </>
);

const App = () => {
  const loginModal = useLoginModal();
  const { shouldShowLoginModal, hideLoginModal } = loginModal;

  const user = useLoginUser();
  // const user = useSelector((state: IRootState) => state.user.user);

  // const user = useLoginUser();

  let is_admin = user?.is_cafe_admin;

  return (
    <IonApp>
      <IonReactRouter>
        {is_admin ? <AdminRoutes /> : <UserRoutes />}

        {/* userApp 頁頁都有機會用到loginModal */}
        <IonModal isOpen={shouldShowLoginModal} onDidDismiss={hideLoginModal}>
          <IonToolbar className={styles.toolbar}>
            <IonButtons slot="end">
              <IonButton onClick={hideLoginModal}>Back</IonButton>
            </IonButtons>
          </IonToolbar>
          {loginModal.tab == "Login" ? <LoginContent /> : <RegisterContent />}
        </IonModal>
      </IonReactRouter>
    </IonApp>
  );
};

export default App;
