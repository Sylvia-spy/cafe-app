//setting for the original API

export const server_origin =
  window.location.origin == "http://localhost:3000"
    ? "http://localhost:8080"
    : "https://cafe.sylsyl.online";
// "http://192.168.80.74:8080";

export const api_origin = server_origin + "/api";

//admin:
//eg. export const api_origin = "http://localhost:8080/admin";

export function toImageUrl(path: string) {
  if (
    path.startsWith("data:") ||
    path.startsWith("/") ||
    path.startsWith("https://")
  ) {
    return path;
  }
  return server_origin + "/uploads/" + path;
}
