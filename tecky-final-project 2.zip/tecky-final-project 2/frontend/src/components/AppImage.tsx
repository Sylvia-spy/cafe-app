import { toImageUrl } from "../api";
import { icons } from "../logo";

export default function AppImage(props: {
  src: string | null;
  className?: string;
  style?: object;
}) {
  let src = toImageUrl(props.src || icons.cofbee);
  return (
    <img
      style={props.style}
      src={src}
      className={props.className}
      onError={(e) => {
        let img = e.currentTarget as HTMLImageElement;
        img.src = icons.cofbee;
        img.dataset.src = src;
      }}
    />
  );
}
