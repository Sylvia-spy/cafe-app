import styles from "./CafeIgPost.module.scss";

import {
  IonCard,
  IonCardTitle,
  IonCardSubtitle,
  IonCardHeader,
  IonCardContent,
  IonIcon,
} from "@ionic/react";
import useGet from "../hooks/useGet";
import { Link } from "react-router-dom";
import { routes } from "../routes";
import { icons } from "../logo";
import { toImageUrl } from "../api";
import AppImage from "./AppImage";

interface newPost {
  shop_id: number;
  post_id: number;
  shop_name: string;
  post_image: string;
  title: string;
  content: string;
}

type GetNewPostPayload = {
  error?: string;
  cafePost?: newPost[];
};

export default function CafeIgPost() {
  const newIGPost = useGet<GetNewPostPayload>({
    name: "newPost",
    pathname: "/home/recent/posts",
    defaultValue: {},
  });
  return (
    <>
      {newIGPost.render((json) => (
        <div>
          <h3 className={styles.heading}> New Post</h3>
          <div>
            {json.cafePost?.map((post) => (
              <div key={post.post_id}>
                <Link
                  to={routes.cafeDetail(post.shop_id)}
                  style={{ textDecoration: "none" }}
                >
                  <IonCard className={styles.background_theme}>
                    <IonCardHeader className={styles.color_and_font}>
                      <IonCardTitle className={styles.shop_name}>
                        {post.shop_name}
                      </IonCardTitle>
                      <AppImage
                        src={post.post_image}
                        className={styles.postImage}
                      />
                      <IonCardSubtitle className={styles.spacebetween}>
                        <div>{post.title}</div>

                        {/* <IonIcon icon={heartOutline} className={styles.icon} /> */}
                      </IonCardSubtitle>
                    </IonCardHeader>
                    <IonCardContent className={styles.color_and_font}>
                      {post.content}
                    </IonCardContent>
                  </IonCard>
                </Link>
              </div>
            ))}
          </div>
        </div>
      ))}
    </>
  );
}
