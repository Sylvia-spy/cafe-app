import styles from "./CafeListSwiper.module.scss";
import { IonAvatar, IonIcon } from "@ionic/react";
import { locationSharp } from "ionicons/icons";
import { Link } from "react-router-dom";
import { routes } from "../routes";
import useGet from "../hooks/useGet";
import { icons } from "../logo";
import AppImage from "./AppImage";

interface newCafe {
  id: number;
  shop_name: string;
  avatar: string;
  district_name: string;
}

type GetNewShopPayload = {
  error?: string;
  newShops?: newCafe[];
};

export default function CafeListSwiper() {
  const newShopArray = useGet<GetNewShopPayload>({
    name: "newShops",
    pathname: "/home/recent/shops",
    defaultValue: {},
  });
  return (
    <>
      {newShopArray.render((json) => (
        <div style={{ padding: "0 16px", fontFamily: "Optima, sans-serif" }}>
          <h3 className={styles.heading}> Discover New Cafe:</h3>
          <div className={styles.swiper_container_parent}>
            <div className={styles.swiper_container_child}>
              {json.newShops?.map((cafe) => (
                <div className={styles.cafeContainer} key={cafe.id}>
                  <Link
                    to={routes.cafeDetail(cafe.id)}
                    style={{ textDecoration: "none" }}
                  >
                    <div className={styles.center_next_div}>
                      <IonAvatar className={styles.avatar}>
                        <AppImage src={cafe.avatar} />
                      </IonAvatar>
                    </div>

                    <div className={styles.nameContainer}>
                      <div className={styles.name}>{cafe.shop_name}</div>
                    </div>

                    <div className={styles.district}>
                      <IonIcon
                        icon={locationSharp}
                        className={styles.district_icon}
                      />
                      <div>{cafe.district_name}</div>
                    </div>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </div>
      ))}
    </>
  );
}
