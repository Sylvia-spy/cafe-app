import { IonButton, useIonAlert } from "@ionic/react";
import { useState } from "react";

const LoginAlert: React.FC = () => {
  const [loginAlert] = useIonAlert();
  const [confirmLogin, setConfirmLogin] = useState("");
  const [cancelLogin, setCancelLogin] = useState("");
  // const [clickedBlank, setClickedBlank] = useState("");

  return (
    <>
      <IonButton
        onClick={() =>
          loginAlert({
            header: "需要登入",
            subHeader: "在檢視個人資料前，請先登入。",
            buttons: [
              {
                text: "立即登入",
                role: "confirm",
                // handler: () => login(),
              },
              {
                text: "取消",
                role: "cancel",
              },
            ],
          })
        }
      >
        Click Me
      </IonButton>
      <p>{confirmLogin}</p>
      <p>{cancelLogin}</p>
      {/* <IonModal isOpen={openLogin}></IonModal> */}
    </>
  );
};

export default LoginAlert;
