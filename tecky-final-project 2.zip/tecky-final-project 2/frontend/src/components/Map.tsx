import {
  IonFab,
  IonFabButton,
  IonFabList,
  IonIcon,
  useIonRouter,
} from "@ionic/react";
//add leaflet css
import "leaflet/dist/leaflet.css";
//add L icon
import L, { icon } from "leaflet";
//add image
import markerIcon from "leaflet/dist/images/marker-icon.png";
//position = LatLngExpression
import { LatLngExpression } from "leaflet";
import { useLayoutEffect, useState, useEffect } from "react";
import useGet from "../hooks/useGet";
import mapButtonStyles from "../components/MapButton.module.scss";
import {
  refresh,
  chevronUpCircle,
  locateOutline,
  cafeOutline,
} from "ionicons/icons";
import { routes } from "../routes";

interface cafeAddress {
  shop_id: number;
  shop_name: string;
  latlng: {
    x: number;
    y: number;
  };
  address: string;
}

type GetCafeAddressPayload = {
  error?: string;
  cafeAddress?: cafeAddress[];
};

const Map = (props: { height?: string; mapContainerClass?: string }) => {
  //set center, get GPS
  const [center, setCenter] = useState<LatLngExpression>();
  useEffect(() => {
    //navigator.geolocation係browser內置嘅function
    navigator.geolocation.getCurrentPosition((e) => {
      // console.log(e);
      //攞番getCurrentPosition嘅coords嘅latlng
      let pos: LatLngExpression = [e.coords.latitude, e.coords.longitude];
      setCenter(pos);
    });
  }, []);

  //一開始會唔顯示 map
  const [showMap, setShowMap] = useState(false);
  const [mapContainer, setMapContainer] = useState<HTMLDivElement | null>();
  const [map, setMap] = useState<L.Map>();

  const router = useIonRouter();

  const cafeMap = useGet<GetCafeAddressPayload>({
    name: "cafe map",
    pathname: "/map",
    defaultValue: {},
  });

  function moveToCenter() {
    if (center) {
      map?.setView(center);
      setTimeout(() => {
        map?.setZoom(18);
      }, 500);
      return;
    }
    //攞現在GPS
    navigator.geolocation.getCurrentPosition((e) => {
      // console.log(e);
      //攞番getCurrentPosition嘅coords嘅latlng
      let pos: LatLngExpression = [e.coords.latitude, e.coords.longitude];
      //.setView＝攞番中心點
      map?.setView(pos);
      setTimeout(() => {
        map?.setZoom(18);
      }, 500);
    });
  }

  //show db cafe marker
  useEffect(() => {
    if (!map) return;
    // console.log(cafeMap.state.payload.cafeAddress);

    //攞番center
    let pos = map.getCenter();
    // console.log(pos);

    //睇payload有無cafeAddress, 有就loop個cafe
    //forEach用嚟for loop，唔會儲低個結果
    cafeMap.state.payload.cafeAddress?.forEach((cafe) => {
      //要＋[cafe.latlng.x, cafe.latlng.y]攞番個shop latlng
      let marker = L.marker([cafe.latlng.x, cafe.latlng.y], {
        icon: icon({ iconUrl: markerIcon }),
      });
      marker.addTo(map);

      // //+ 番onClick 轉頁, router.push要透過const router = useIonRouter();用
      marker.addEventListener("click", () => {
        router.push("/shops/" + cafe.shop_id);
      });
    });
    map.setView(pos);
  }, [map, cafeMap.state.payload.cafeAddress]);

  //set time out 去 load map
  useLayoutEffect(() => {
    //有 mapContainer 就行 setTimeout, 就把 setShowMap 變 true
    if (mapContainer) {
      setTimeout(() => {
        setShowMap(true);
      }, 0);
    }
  }, [mapContainer]);

  useEffect(() => {
    if (mapContainer && showMap && center) {
      var map = L.map(mapContainer);
      setMap(map);
      map.setZoom(18);
      //.setView＝攞番中心點
      map.setView(center);

      L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution:
          '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      }).addTo(map);
    }
  }, [mapContainer, showMap, center]);

  return (
    <>
      <div ref={(e) => setMapContainer(e)} style={{ height: props.height }}>
        <IonFab
          slot="fixed"
          vertical="top"
          horizontal="end"
          className="fab_button"
        >
          <IonFabButton
            onClick={() => window.location.reload()}
            size="small"
            className={mapButtonStyles.fab}
          >
            <IonIcon icon={refresh}></IonIcon>
          </IonFabButton>
        </IonFab>

        <IonFab
          slot="fixed"
          vertical="bottom"
          horizontal="end"
          className="fab_button"
        >
          <IonFabButton size="small" className={mapButtonStyles.fab}>
            <IonIcon icon={chevronUpCircle}></IonIcon>
          </IonFabButton>
          <IonFabList side="top">
            <IonFabButton size="small" onClick={moveToCenter}>
              <IonIcon icon={locateOutline}></IonIcon>
            </IonFabButton>
            <IonFabButton size="small" routerLink={routes.cafeList}>
              <IonIcon icon={cafeOutline}></IonIcon>
            </IonFabButton>
          </IonFabList>
        </IonFab>
      </div>
    </>
  );
};

export default Map;
