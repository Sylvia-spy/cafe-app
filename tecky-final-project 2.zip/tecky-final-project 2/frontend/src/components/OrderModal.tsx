import { useState } from "react";
import styles from "./OrderModal.module.scss";
import {
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonButton,
  IonSegment,
  IonSegmentButton,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  useIonToast,
  IonIcon,
  IonLabel,
} from "@ionic/react";
import { useDispatch } from "react-redux";
import { addShoppingCartItem } from "../store/shoppingCartSlice";
import { arrowBackOutline } from "ionicons/icons";
import AppImage from "./AppImage";
import { uuidGen } from "../store/uuidUtilis";

type Coffee = {
  id: number;
  coffee_name: string;
  variants: Variant[];
};

type Variant = {
  id: number;
  coffee_size: string;
  price: number;
  ice: boolean;
  hot: boolean;
  coffee_image: string;
};

const SizeName: Record<string, string> = {
  small: "Tall",
  medium: "Grande",
  big: "Venti",
};

function toTemperature(variant: Variant): string {
  return variant.ice ? "Ice" : variant.hot ? "Hot" : "Normal";
}

export default function OrderModal(props: {
  selectedCoffee: Coffee;
  dismiss: () => void;
}) {
  const { selectedCoffee } = props;
  const [selectedVariant, setSelectedVariant] = useState(
    selectedCoffee.variants[0]
  );

  // -------------------------- + - function-------------------------------------
  const [itemCount, setItemCount] = useState(1);

  const addCount = () => {
    setItemCount(itemCount + 1);
  };

  const reduceCount = () => {
    if (itemCount <= 1) return;
    setItemCount(itemCount - 1);
  };

  // -------------------------- Toast logic + Confirm Button------------------------------------
  const [presentToast] = useIonToast();
  let dispatch = useDispatch();

  const confirmButton = () => {
    dispatch(
      addShoppingCartItem({
        coffee: selectedCoffee,
        variant: selectedVariant,
        count: itemCount,
        uuid: uuidGen(),
      })
    );
    presentToast({
      message: "收到～您可以係《購物車》頁面再次確認呀～",
      duration: 3000,
      color: "success",
      buttons: [{ text: "OK", role: "cancel" }],
    });
    props.dismiss();
  };

  return (
    <>
      <IonHeader>
        <IonToolbar>
          <IonButton slot="start" fill="clear" onClick={props.dismiss}>
            <IonIcon
              icon={arrowBackOutline}
              className={styles.toolbar_back_btn}
            ></IonIcon>
          </IonButton>
          <IonTitle>
            <div className={styles.toolbar_name}>
              {selectedCoffee?.coffee_name}
            </div>
          </IonTitle>
          <IonButton slot="end" fill="clear" onClick={props.dismiss}>
            <IonIcon
              icon={arrowBackOutline}
              className={styles.toolbar_hidden}
            ></IonIcon>
          </IonButton>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <div className={styles.font_theme}>
          <div className={styles.center}>
            <AppImage
              className={styles.modal_image}
              src={selectedCoffee?.variants[0].coffee_image}
            />
          </div>
          <IonCardHeader>
            <IonCardTitle className={styles.modal_coffee_name}>
              {selectedCoffee.coffee_name} (${selectedVariant.price})
            </IonCardTitle>
          </IonCardHeader>
          <IonCardContent>
            <IonSegment
              className={styles.modal_segment}
              value={selectedVariant.id + ""}
              onIonChange={(e) =>
                setSelectedVariant(
                  selectedCoffee.variants.find(
                    (variant) => variant.id == +e.detail.value!
                  ) || selectedVariant
                )
              }
            >
              {(() => {
                let variants = selectedCoffee.variants
                  .filter(
                    (variant) =>
                      variant.ice == selectedVariant.ice &&
                      variant.hot == selectedVariant.hot
                  )
                  .sort((a, b) => a.price - b.price);
                let basePrice = variants[0].price;
                return variants.map((variant) => {
                  let text = SizeName[variant.coffee_size];
                  let diff = variant.price - basePrice;
                  if (diff > 0) {
                    text += ` (+$${diff})`;
                  }
                  return (
                    <IonSegmentButton
                      value={variant.id + ""}
                      key={variant.id}
                      className={styles.modal_segment_button}
                    >
                      <IonLabel className={styles.modal_segment_label}>
                        {text}
                      </IonLabel>
                    </IonSegmentButton>
                  );
                });
              })()}
            </IonSegment>
            <br />
            <IonSegment
              className={styles.modal_segment}
              value={selectedVariant.id + ""}
              onIonChange={(e) =>
                setSelectedVariant(
                  selectedCoffee.variants.find(
                    (variant) => variant.id == +e.detail.value!
                  ) || selectedVariant
                )
              }
            >
              {(() => {
                let variants = selectedCoffee.variants
                  .filter(
                    (variant) =>
                      variant.coffee_size == selectedVariant.coffee_size
                  )
                  .sort((a, b) => a.price - b.price);
                let basePrice = variants[0].price;
                return variants.map((variant) => {
                  let text = toTemperature(variant);
                  let diff = variant.price - basePrice;
                  if (diff > 0) {
                    text += ` (+$${diff})`;
                  }
                  return (
                    <IonSegmentButton
                      value={variant.id + ""}
                      key={variant.id}
                      className={styles.modal_segment_button}
                    >
                      <IonLabel className={styles.modal_segment_label}>
                        {text}
                      </IonLabel>
                    </IonSegmentButton>
                  );
                });
              })()}
            </IonSegment>
          </IonCardContent>
          <div className={styles.bottomBar}>
            <div className={styles.plus}>
              <div>
                <button onClick={() => reduceCount()}> －</button>
              </div>
              <div>{itemCount}</div>
              <div>
                <button onClick={() => addCount()}> ＋</button>
              </div>
            </div>
            <button className={styles.confirm} onClick={() => confirmButton()}>
              Confirm
            </button>
          </div>
        </div>
      </IonContent>
    </>
  );
}
