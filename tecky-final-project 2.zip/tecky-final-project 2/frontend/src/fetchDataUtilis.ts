import { api_origin } from "./api";

export async function fetchServerData(apiPath: string) {
  // GET
  let res = await fetch(api_origin + apiPath);
  let data = await res.json();

  return data;
}

// "/api/todo/postItem", 唔係form
export async function fetchServerDataNonGet(
  apiPath: string,
  method: "PUT" | "POST" | "PATCH" | "DELETE",
  data: any
) {
  const res = await fetch(api_origin + apiPath, {
    method: method,
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(data),
  });

  let json = await res.json();

  return json;
}

// "/api/todo/postItem", 係form
export async function fetchServerDataForm(
  apiPath: string,
  method: "PUT" | "POST" | "PATCH" | "DELETE",
  data: FormData
) {
  const res = await fetch(api_origin + apiPath, {
    method: method,
    body: data,
  });

  let resData = await res.json();
  return resData;
}
