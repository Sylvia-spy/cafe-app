export function d2(x: number) {
  return x < 10 ? "0" + x : x;
}
