import { api_origin } from "./../api";
import { useIonToast } from "@ionic/react";
// import useToken from "./useToken";
import { useSelector } from "react-redux";
import { IRootState } from "../store/store";
import useToken from "./useToken";

export function useAPI() {
  const [presentToast] = useIonToast();
  const token = useToken();
  // const token = useSelector((state: IRootState) => state.user.token);

  async function callFetch(
    apiPath: string,
    method: "PUT" | "POST" | "PATCH" | "DELETE",
    data: any
  ) {
    const res = await fetch(api_origin + apiPath, {
      method: method,
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
      body: JSON.stringify(data),
    });

    let json = await res.json();

    if (json.error) {
      showError(json.error);
    }

    return json;
  }

  async function upload(
    apiPath: string,
    method: "PUT" | "POST" | "PATCH" | "DELETE",
    body: FormData
  ) {
    const res = await fetch(api_origin + apiPath, {
      method: method,
      headers: {
        Authorization: "Bearer " + token,
      },
      body,
    });

    let json = await res.json();

    if (json.error) {
      showError(json.error);
    }

    return json;
  }

  function showError(message: string) {
    presentToast({
      message,
      duration: 3700,
      color: "danger",
      buttons: [{ text: "Dismiss", role: "cancel" }],
    });
  }

  return { fetch: callFetch, upload, showError };
}
