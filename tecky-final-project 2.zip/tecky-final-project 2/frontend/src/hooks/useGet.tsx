import { IonButton, IonIcon, IonProgressBar } from "@ionic/react";
import { refresh } from "ionicons/icons";
import { useEffect, useState } from "react";
// import { useSelector } from "react-redux";
import { api_origin } from "../api";
// import { IRootState } from "../store/store";
import useToken from "./useToken";
// import useToken from "./useToken";

export default function useGet<T extends { error?: string }>(options: {
  name: string;
  pathname: string;
  params?: URLSearchParams;
  defaultValue: T;
}) {
  const token = useToken();
  // const token = useSelector((state: IRootState) => state.user.token);
  const [counter, setCounter] = useState(1);

  const [state, setState] = useState({
    loading: true,
    payload: options.defaultValue,
  });

  let url = api_origin + options.pathname;
  if (options.params) {
    url += "?" + options.params;
  }
  useEffect(() => {
    setState((state) => ({ ...state, loading: true }));
    fetch(url, {
      headers: {
        Authorization: "Bearer " + token,
      },
    })
      .then((res) => res.json())
      .catch((err) => ({ error: String(err) }))
      .then((json) => setState({ loading: false, payload: json }));
  }, [url, token, counter]);

  function render(renderFn: (json: T) => any) {
    if (state.loading) {
      return (
        <div className="ion-text-center">
          <p>Loading {options.name}...</p>
          <IonProgressBar></IonProgressBar>
        </div>
      );
    }

    if (state.payload.error) {
      return (
        <div className="ion-text-center">
          <p>
            Fail to load {options.name}: {state.payload.error}...
          </p>
          <IonButton onClick={reload}>
            <IonIcon icon={refresh} slot="icon-only"></IonIcon>
          </IonButton>
        </div>
      );
    }
    return renderFn(state.payload);
  }

  function reload() {
    setCounter(counter + 1);
  }

  return { state, setState, render, reload };
}
