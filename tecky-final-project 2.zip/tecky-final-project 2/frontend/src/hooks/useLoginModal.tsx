import { useIonAlert } from "@ionic/react";

//this is library, 作用同redux一樣
import useStorageState, { createMemoryStorage } from "react-use-storage-state";
import useToken from "./useToken";

//唔明
let store = createMemoryStorage();

export default function useLoginModal() {
  //用法好似state
  const [shouldShowLoginModal, setShouldShowLoginModal] = useStorageState(
    "loginModal",
    false,
    store
  );

  const [tab, setTab] = useStorageState("tab", "Login", store);

  //check 有無login
  const token = useToken();

  //ionic alert 用法
  const [presentAlert] = useIonAlert();

  function showLoginAlert() {
    if (token) {
      return;
    }
    presentAlert({
      header: "Login Required",
      subHeader: "Please login before viewing profile",
      buttons: [
        {
          text: "Login now",
          role: "confirm",
          handler: () => setShouldShowLoginModal(true),
        },
        {
          text: "Cancel",
          role: "cancel",
        },
      ],
    });
  }

  function hideLoginModal() {
    setShouldShowLoginModal(false);
  }

  return {
    shouldShowLoginModal: shouldShowLoginModal && !token,
    showLoginAlert,
    hideLoginModal,
    setShouldShowLoginModal,
    tab,
    setTab,
  };
}
