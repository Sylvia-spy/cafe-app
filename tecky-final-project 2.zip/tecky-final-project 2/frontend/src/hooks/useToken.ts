//呢個file係check有無token, 因有token=有login
import jwtDecode from "jwt-decode";
// import { useSelector } from "react-redux";
import useStorageState from "react-use-storage-state";
// import { IRootState } from "../store/store";
import { JWTPayload } from "../store/userSlice";

export default function useToken() {
  // return useSelector((state: IRootState) => state.user.token);

  return useTokenState().token;
}

export function useTokenState() {
  // return useSelector((state: IRootState) => state.user.token);
  const [token, setToken] = useStorageState("token", "");
  return { token, setToken };
}

export function useLoginUser() {
  let token = useToken();
  return token ? jwtDecode<JWTPayload>(token) : undefined;
}
