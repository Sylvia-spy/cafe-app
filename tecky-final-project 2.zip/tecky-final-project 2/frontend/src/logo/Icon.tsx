import AppImage from "../components/AppImage";
import styles from "./Icon.module.scss";

export default function Icon(props: { icon: string }) {
  return <AppImage src={props.icon} className={styles.icon} />;
}
