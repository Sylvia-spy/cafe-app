import armchair from "./armchair.png";
import award from "./award.png";
import brightness from "./brightness.png";
import cbd from "./cbd.png";
import chairs from "./chairs.png";
import coffee_beans from "./coffee-beans.png";
import cofbee from "./cofbee.png";
import decaf from "./decaf.png";
import food from "./food.png";
import joy from "./joy.png";
import milk from "./milk.png";
import parking_area from "./parking-area.png";
import petfriendly from "./petfriendly.png";
import petwithin from "./petwithin.png";
import snake from "./snake.png";
import socket from "./socket.png";
import solocup from "./solocup.png";
import toilet from "./toilet.png";
import vegan from "./vegan.png";
import vegeterian from "./vegeterian.png";
import wifi from "./wifi.png";

export let icons = {
  armchair,
  award,
  brightness,
  cbd,
  chairs,
  cofbee,
  coffee_beans,
  decaf,
  food,
  joy,
  milk,
  parking_area,
  petfriendly,
  petwithin,
  snake,
  socket,
  solocup,
  toilet,
  vegan,
  vegeterian,
  wifi,
};
