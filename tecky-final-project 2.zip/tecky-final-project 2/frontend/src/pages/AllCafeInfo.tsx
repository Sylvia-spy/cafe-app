import {
  IonBackButton,
  IonButton,
  IonButtons,
  IonCheckbox,
  IonContent,
  IonHeader,
  IonIcon,
  IonItem,
  IonLabel,
  IonList,
  IonListHeader,
  IonMenu,
  IonMenuButton,
  IonMenuToggle,
  IonPage,
  IonSearchbar,
  IonThumbnail,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import {
  arrowBackCircleSharp,
  arrowBackOutline,
  locationSharp,
} from "ionicons/icons";
import { useState } from "react";
import styles from "./AllCafeInfo.module.scss";
import { routes } from "../routes";
import useGet from "../hooks/useGet";
import { d2 } from "../format";
import { features } from "./features";
import { icons } from "../logo";
import AppImage from "../components/AppImage";

type ShopCard = {
  id: number;
  shop_name: string;
  image: string;
  district_name: string;
  openingHours: OpeningHour[];
};

export type OpeningHour = {
  weekday: number;
  start_time: string;
  end_time: string;
};

export type GetShopsPayload = {
  error?: string;
  shops?: ShopCard[];
};

const AllCafeInfo: React.FC = () => {
  const [filters, setFilters] = useState<string[]>([]);

  let params = new URLSearchParams();
  for (let filter of filters) {
    //會自動push落URL到
    params.append("feature", filter);
  }

  const shopArray = useGet<GetShopsPayload>({
    name: "shops",
    pathname: "/shops",
    params,
    defaultValue: {},
  });

  const now = new Date();
  // Sunday - Saturday : 0 - 6
  const weekDay = now.getDay();
  const nowTime = d2(now.getHours()) + ":" + d2(now.getMinutes());

  const [searchAddress, setSearchAddress] = useState("");
  const [searchName, setSearchName] = useState("");

  // search bar 做filter, toLowerCase 令searching 唔洗就大細楷
  const displayShops = shopArray.state.payload.shops?.filter(
    (shop) =>
      shop.district_name.toLowerCase().includes(searchAddress.toLowerCase()) &&
      shop.shop_name.toLowerCase().includes(searchName.toLowerCase())
  );

  return (
    <>
      {/* 個menu一開始係hidden */}
      <IonMenu contentId="all-cafe-info">
        <IonHeader>
          <IonToolbar mode="md">
            <IonButtons slot="start">
              <IonMenuToggle>
                <IonButton>
                  <IonIcon icon={arrowBackOutline}></IonIcon>
                </IonButton>
              </IonMenuToggle>
            </IonButtons>
            <IonTitle className={styles.font_theme}>Advanced Search</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonContent>
          <IonList>
            {features.map((category, idx) => (
              <div key={idx}>
                <IonListHeader className={styles.font_theme}>
                  {category.category}
                </IonListHeader>
                {category.data.map((feature, idx) => (
                  <IonItem key={idx} className={styles.font_theme}>
                    <IonCheckbox
                      className={styles.checkbox}
                      slot="start"
                      checked={filters.includes(feature.feature_name)}
                      onIonChange={(e) => {
                        if (e.detail.checked) {
                          setFilters([...filters, feature.feature_name]);
                        } else {
                          setFilters(
                            filters.filter(
                              (name) => name != feature.feature_name
                            )
                          );
                        }
                      }}
                    ></IonCheckbox>
                    <IonLabel className={styles.font_theme}>
                      <div className={styles.font_theme}>{feature.title}</div>
                    </IonLabel>
                  </IonItem>
                ))}
              </div>
            ))}
          </IonList>
        </IonContent>
      </IonMenu>

      <IonPage id="all-cafe-info">
        <IonHeader>
          <IonToolbar>
            <IonButtons slot="end">
              <IonMenuButton style={{ color: "#594545" }}></IonMenuButton>
            </IonButtons>
            <IonTitle className={styles.font_theme}>Advanced Search</IonTitle>
          </IonToolbar>
        </IonHeader>

        <IonContent className="ion-padding" fullscreen>
          <IonSearchbar
            className={styles.font_theme}
            animated={true}
            placeholder="District"
            type="text"
            value={searchAddress}
            //有input 就行 setSearchAddress
            onIonChange={(e) => setSearchAddress(e.detail.value as string)}
          ></IonSearchbar>
          <IonSearchbar
            className={styles.font_theme}
            animated={true}
            placeholder="Shop Name"
            type="text"
            value={searchName}
            //有input 就行 setSearchName
            onIonChange={(e) => setSearchName(e.detail.value as string)}
          ></IonSearchbar>

          {/* map一下個shops拆個array, let新variable 係shop object到check db的weekday == 今日的weekday*/}

          {shopArray.render((json) =>
            displayShops?.map((shop) => {
              let openingHour = shop.openingHours.find(
                (x) => x.weekday === weekDay
              );

              // console.log(shop);

              return (
                <IonItem
                  key={shop.id}
                  className={styles.cafelist}
                  routerLink={routes.cafeDetail(shop.id)}
                >
                  <IonThumbnail slot="start">
                    <AppImage src={shop.image} className={styles.avatar} />
                  </IonThumbnail>
                  <span className={styles.container}>
                    <div className={styles.shop_name_Container}>
                      <div>
                        <div className={styles.before_shop_name}>
                          <div className={styles.shop_name}>
                            {shop.shop_name}
                          </div>
                        </div>
                        <div className={styles.districtName}>
                          <IonIcon icon={locationSharp} />
                          <span> {shop.district_name}</span>
                        </div>
                      </div>
                    </div>

                    <div className={styles.openHour}>
                      {
                        // 上面check完, 有就return下面啲野, 無就show 今天休息
                        openingHour ? (
                          <>
                            <div key={shop.id}>
                              {openingHour.start_time <= nowTime &&
                              (nowTime <= openingHour.end_time ||
                                openingHour.end_time == "00:00:00") ? (
                                <div className={styles.success}>
                                  <span className={styles.closedAt}>
                                    Closed at:
                                  </span>
                                  <br />
                                  {openingHour.end_time.slice(0, 5)}
                                </div>
                              ) : (
                                <div className={styles.rest}>已休息</div>
                              )}
                            </div>
                          </>
                        ) : (
                          <>
                            <span className={styles.rest}>今天休息</span>
                          </>
                        )
                      }
                    </div>
                  </span>
                </IonItem>
              );
            })
          )}
        </IonContent>
      </IonPage>
    </>
  );
};

export default AllCafeInfo;
