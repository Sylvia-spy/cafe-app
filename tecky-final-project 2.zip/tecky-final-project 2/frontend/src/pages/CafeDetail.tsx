import React from "react";
import {
  IonBackButton,
  IonButton,
  IonButtons,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonContent,
  IonHeader,
  IonIcon,
  IonPage,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import { OpeningHour } from "./AllCafeInfo";
import {
  callOutline,
  exitOutline,
  locationOutline,
  logoFacebook,
  logoGoogle,
  logoInstagram,
} from "ionicons/icons";

import Icon from "../logo/Icon";
import { useParams } from "react-router";
import useGet from "../hooks/useGet";
// import { d2 } from "../format";
import { Point } from "leaflet";
import { features } from "./features";
import styles from "./CafeDetail.module.scss";
import { routes } from "../routes";
import { icons } from "../logo";
import AppImage from "../components/AppImage";

type CafeDetail = {
  id: number;
  shop_name: string;
  image: string | null;
  tel?: number;
  latLng?: Point[];
  instagram?: string;
  facebook?: string;
  address: string;
  district_name?: string;
  exit?: string;
  avatar: string;
  thumbnail: string;
  features: {
    name: string;
    has: number | null;
  }[];
  openingHours: OpeningHour[];
};

type GetShopDetailsPayload = { error?: string; shop?: CafeDetail };

const ShopDetailsPage: React.FC = () => {
  let params = useParams<{ id: string }>();

  const shopData = useGet<GetShopDetailsPayload>({
    name: "shop",
    pathname: "/shops/" + params.id,
    defaultValue: {},
  });

  const now = new Date();
  // const weekDay = now.getDay();
  // const nowTime = d2(now.getHours()) + ":" + d2(now.getMinutes());

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar className={styles.font_theme}>
          <IonButtons slot="start">
            <IonBackButton defaultHref="/" className={styles.font_theme} />
          </IonButtons>
          {shopData.render((json) => {
            return <IonTitle key={params.id}>{json.shop?.shop_name}</IonTitle>;
          })}
        </IonToolbar>
      </IonHeader>
      {/* --------------------- 正式內容 ------------------- */}
      <IonContent fullscreen>
        {shopData.render((json) => {
          let shop = json.shop;
          if (!shop) return <p>shop not found</p>;
          return (
            <div key={params.id}>
              <div>
                <AppImage className={styles.image} src={shop.image} />
                <AppImage className={styles.avatar} src={shop.avatar} />
                <div className={styles.nameArea}>
                  <div className={styles.name}>{shop.shop_name}</div>
                </div>
              </div>
              <div className={styles.underImageContainer}>
                {/* <h3>地址：</h3> */}
                <button className={styles.addressContainer}>
                  <IonIcon icon={locationOutline} className={styles.icon} />

                  <div className={styles.address}>{shop.address}</div>

                  <IonIcon icon={exitOutline} className={styles.icon} />

                  <div className={styles.address}>{shop.district_name}</div>
                </button>
                {/* ---------------每日開放時間?-------------- */}
                <div className={styles.openingHours}>
                  {[0, 1, 2, 3, 4, 5, 6].map((weekDay) => (
                    //"日一二三四五六"[weekDay] 會對番 [0, 1, 2, 3, 4, 5, 6]
                    <div className={styles.openingHour} key={weekDay}>
                      {
                        [
                          "Sunday",
                          "Monday",
                          "Tuesday",
                          "Wednesday",
                          "Thursday",
                          "Friday",
                          "Saturday",
                        ][weekDay]
                      }
                      :{"  "}
                      {(function () {
                        let openingHour = shop?.openingHours.find(
                          (openingHour) => openingHour.weekday == weekDay
                        );
                        if (!openingHour) {
                          return <span className={styles.rest}>Closed</span>;
                        }
                        return (
                          openingHour.start_time.slice(0, 5) +
                          " - " +
                          openingHour.end_time.slice(0, 5)
                        );
                      })()}
                    </div>
                  ))}
                </div>
                {/* ----------------- Button for   "Let's Order Coffee" ----------------------------- */}

                <IonButton
                  fill="clear"
                  className={styles.落單}
                  routerLink={routes.menuList(shop.id)}
                >
                  Order Coffee Here
                </IonButton>

                {/* ----------------------- Google Map，IG, facebook button -------------------------------------- */}
                <div className={styles.buttons}>
                  <IonButtons>
                    <IonButton
                      href={
                        "https://www.google.com.hk/maps/search/" +
                        shop.shop_name
                      }
                      target="_blank"
                      className={styles.button}
                    >
                      <IonIcon slot="icon-only" icon={logoGoogle} />
                    </IonButton>
                  </IonButtons>

                  <IonButtons>
                    <IonButton
                      hidden={!shop.tel}
                      href={"tel:" + shop.tel}
                      target="_blank"
                      className={styles.button}
                    >
                      <IonIcon slot="icon-only" icon={callOutline} />
                    </IonButton>
                  </IonButtons>

                  <IonButtons>
                    <IonButton
                      hidden={!shop.instagram}
                      href={shop.instagram}
                      target="_blank"
                      className={styles.button}
                    >
                      <IonIcon slot="icon-only" icon={logoInstagram} />
                    </IonButton>
                  </IonButtons>

                  <IonButtons>
                    <IonButton
                      hidden={!shop.facebook}
                      href={shop.facebook}
                      target="_blank"
                      className={styles.button}
                    >
                      <IonIcon slot="icon-only" icon={logoFacebook} />
                    </IonButton>
                  </IonButtons>
                </div>
                {/* ----------------------- Signature ---------------------------------------- */}
                <div className={styles.font_theme}>
                  {features.map((v, idx) => (
                    <div key={idx}>
                      <h4> {v.category} </h4>
                      <div className={styles.signature}>
                        {v.data.map((k, idx) => (
                          <div
                            key={idx}
                            className={
                              //db: shop 有無 feature.name => 對上面signatureArr的feature_name
                              shop?.features.find(
                                (DBfeature) => DBfeature.name == k.feature_name
                              )?.has
                                ? styles.each_signature
                                : styles.no_signature
                            }
                          >
                            <Icon icon={k.icon}></Icon>
                            <div className={styles.signature_content}>
                              {k.title}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
                {/* ----------------------- content-admin??--------------------------------------- */}
                <IonCard className={styles.font_theme}>
                  <IonCardHeader>
                    <IonCardSubtitle>
                      以上由CofBee團隊為店鋪管理
                    </IonCardSubtitle>
                  </IonCardHeader>
                  <IonCardContent>
                    我們可以幫您管理店鋪資訊～ <br />
                    聯絡我地了解更多啦～
                  </IonCardContent>
                </IonCard>
              </div>
            </div>
          );
        })}
        <></>
      </IonContent>
    </IonPage>
  );
};

export default ShopDetailsPage;
