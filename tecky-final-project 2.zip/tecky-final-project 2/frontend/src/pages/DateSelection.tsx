//no used, can delete

import { IonDatetime } from "@ionic/react";
function DateSelection() {
  return <IonDatetime presentation="date"></IonDatetime>;
}
export default DateSelection;
