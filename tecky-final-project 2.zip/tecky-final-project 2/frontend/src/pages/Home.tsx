import {
  IonButton,
  IonCard,
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import CafeListSwiper from "../components/CafeListSwiper";
import Map from "../components/Map";
import CafeIgPost from "../components/CafeIgPost";
import cafeListStyles from "../components/CafeListSwiper.module.scss";
import useLoginModal from "../hooks/useLoginModal";
import { useTokenState } from "../hooks/useToken";
import homeStyles from "./Home.module.scss";
import { icons } from "../logo";
import AppImage from "../components/AppImage";

export default function Home() {
  const loginModal = useLoginModal();
  const { token, setToken } = useTokenState();
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle
            style={{ color: "#594545", fontFamily: "Optima, sans-serif" }}
          >
            Welcome to CofBee
          </IonTitle>

          {token ? (
            <IonButton
              onClick={() => setToken("")}
              slot="end"
              fill="clear"
              className={homeStyles.exit}
            >
              Logout
            </IonButton>
          ) : (
            <IonButton
              fill="clear"
              onClick={() => loginModal.setShouldShowLoginModal(true)}
              slot="end"
              className={homeStyles.exit}
            >
              Login
            </IonButton>
          )}
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <IonHeader collapse="condense">
          <IonToolbar>
            <h1 className={cafeListStyles.outerHeading}>
              Welcome to CofBee
              <AppImage src={icons.cofbee} className={cafeListStyles.img} />
            </h1>
          </IonToolbar>
        </IonHeader>

        <CafeListSwiper />
        <IonCard style={{ height: "300px" }}>
          <Map height="100%" mapContainerClass="" />
        </IonCard>
        <CafeIgPost />
      </IonContent>
    </IonPage>
  );
}
