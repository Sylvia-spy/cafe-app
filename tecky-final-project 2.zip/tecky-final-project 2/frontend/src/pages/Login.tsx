import {
  IonButton,
  IonButtons,
  IonContent,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
  IonListHeader,
  IonNote,
  IonPage,
  IonTitle,
  useIonRouter,
  useIonToast,
} from "@ionic/react";
import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { fetchServerDataNonGet } from "../fetchDataUtilis";
import { JWTPayload } from "../store/userSlice";
import useLoginModal from "../hooks/useLoginModal";
import { useTokenState } from "../hooks/useToken";
import styles from "./Login.module.scss";
import jwtDecode from "jwt-decode";
import { routes } from "../routes";

const Login: React.FC = () => {
  return (
    <>
      <IonPage>
        <LoginContent />
      </IonPage>
    </>
  );
};

export const LoginContent = () => {
  //定義哂啲state
  const [loginData, setLoginData] = useState({
    user_name: "",
    hashed_pw: "",
  });

  const dispatch = useDispatch();

  //整toast比user睇有無漏
  const [presentToast] = useIonToast();

  const loginModal = useLoginModal();

  const { setToken } = useTokenState();

  const router = useIonRouter();

  async function submitToServer() {
    //step 1: checking
    if (!loginData.user_name) {
      presentToast({
        message: "Missing Username!!",
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }
    if (!loginData.hashed_pw) {
      presentToast({
        message: "Missing Password!!",
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }

    //step 2: pass to backend
    let json = await fetchServerDataNonGet("/users/login", "POST", loginData);

    //step 3: check 資料有無錯
    if (!json.token) {
      presentToast({
        message: "Wrong username and password!!",
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }

    //岩就去profile, 係app.tsx href寫咗
    if (json.token) {
      console.log("json.token:::::", json.token);

      setToken(json.token);
      // dispatch(loginWithToken(json));
      presentToast({
        message: "Login successfully!!",
        duration: 3000,
        color: "success",
        buttons: [{ text: "cancel", role: "cancel" }],
      });

      let payload: JWTPayload = jwtDecode(json.token);
      if (payload.is_admin) {
        router.push(routes.updateCafeInfo, "forward", "replace");
      }

      return;
    }
  }

  return (
    <IonContent fullscreen className={styles.background}>
      <IonList className={styles.formBox}>
        <p className={styles.title + " ion-text-center"}>Login</p>

        <IonItem fill="solid" className={styles.inputBox} mode="md">
          <IonLabel position="floating">Username</IonLabel>
          <IonInput
            type="text"
            clearInput={true}
            placeholder="Enter Your Username"
            value={loginData.user_name}
            onIonChange={(e) =>
              setLoginData({
                ...loginData,
                user_name: e.detail.value || "",
              })
            }
          ></IonInput>
        </IonItem>

        <IonItem className={styles.inputBox} mode="md">
          <IonLabel position="floating">Password: </IonLabel>
          <IonInput
            clearInput={true}
            type="password"
            placeholder="Enter Your Password"
            value={loginData.hashed_pw}
            onIonChange={(e) =>
              setLoginData({
                ...loginData,
                hashed_pw: e.detail.value || "",
              })
            }
          ></IonInput>
        </IonItem>

        <IonButtons className={styles.buttons}>
          <IonButton className={styles.submit} onClick={submitToServer}>
            Submit
          </IonButton>
        </IonButtons>

        <p className="ion-text-center">
          <IonNote>
            Don't have an account yet?{" "}
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                loginModal.setTab("Register");
              }}
            >
              Register
            </a>
          </IonNote>
        </p>
      </IonList>
    </IonContent>
  );
};

export default Login;
