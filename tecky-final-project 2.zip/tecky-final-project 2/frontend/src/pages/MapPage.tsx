import Map from "../components/Map";
import { IonContent, IonPage } from "@ionic/react";

export default function MapPage() {
  return (
    <IonPage>
      <IonContent>
        <Map height="100%" />
      </IonContent>
    </IonPage>
  );
}
