import { useState } from "react";
import styles from "./MenuList.module.scss";
import orderModalStyles from "../components/OrderModal.module.scss";
import {
  IonAvatar,
  IonBackButton,
  IonButtons,
  IonCard,
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
  IonButton,
  IonModal,
  IonItem,
  IonLabel,
  IonSegment,
  IonSegmentButton,
  IonCardHeader,
  IonCardTitle,
  IonIcon,
  IonText,
} from "@ionic/react";
import { OpeningHour } from "./AllCafeInfo";
import { useParams } from "react-router";
import useGet from "../hooks/useGet";
import { cartOutline } from "ionicons/icons";
import { routes } from "../routes";
import OrderModal from "../components/OrderModal";
import { useSelector } from "react-redux";
import { IRootState } from "../store/store";
import { toImageUrl } from "../api";
import AppImage from "../components/AppImage";

//-------------------------- GET info from DB--------------------------------------
type CafeDetail = {
  id: number;
  shop_name: string;
  address: string;
  district_name?: string;
  avatar: string;
  image: string;
  openingHours: OpeningHour[];
  menu: {
    id: number;
    coffee_name: string;
    coffee_category: string;
  }[];
  coffee_variant: {
    id: number;
    coffee_size: string;
    price: number;
    ice: boolean;
    hot: boolean;
    coffee_image: string;
    menu_id: number;
  }[];
};

export type GetShopDetailsPayload = { error?: string; shop?: CafeDetail };

//-------------------------- change to specific category--------------------------------------
type Category = {
  cat_name: string;
  coffees: Array<Coffee>;
  // element?: HTMLIonCardElement | null;
};

type Coffee = {
  id: number;
  coffee_name: string;
  variants: Variant[];
};

type Variant = {
  id: number;
  coffee_size: string;
  price: number;
  ice: boolean;
  hot: boolean;
  coffee_image: string;
};
//----- * 同於shoppingCart Slice * --- change to Confirm Data--------------------------------------
export type SubmitData = {
  coffee: Coffee;
  variant: Variant;
  count: number;
};

export default function MenuList() {
  let params = useParams<{ id: string }>();

  const shopData = useGet<GetShopDetailsPayload>({
    name: "menu",
    pathname: "/shops/" + params.id + "/menuList",
    defaultValue: {},
  });
  // --------由緊死既db filter data岩用既coffee_category and coffee_name-------------------------------
  let categories: Array<Category> = [];

  shopData.state.payload.shop?.menu.forEach((menu) => {
    let cat = categories.find((cat) => cat.cat_name == menu.coffee_category);
    if (!cat) {
      cat = { cat_name: menu.coffee_category, coffees: [] };
      categories.push(cat);
    }
    cat.coffees.push({
      id: menu.id,
      coffee_name: menu.coffee_name,
      variants:
        shopData.state.payload.shop?.coffee_variant.filter(
          (v) => v.menu_id == menu.id
        ) || [],
    });
  });
  const shoppingCartData = useSelector(
    (state: IRootState) => state.shoppingCart.data
  );
  // -------------- Open Modal logic -------------------------------------
  const [selectedCoffee, setSelectedCoffee] = useState<null | Coffee>(null);

  // --------------------------正文-------------------------------------
  return (
    <>
      <IonPage>
        {/* ----------------------------IonHeader------------------------------------ */}
        <IonHeader>
          <IonToolbar className={styles.font_theme}>
            <IonButtons slot="start">
              <IonBackButton defaultHref="/" className={styles.font_theme} />
            </IonButtons>
            <IonTitle>Cafe Menu</IonTitle>
            {/* ------------------------ ShoppingCart ------------------------------------ */}
            <IonButton slot="end" fill="clear" routerLink={routes.ShoppingCart}>
              <IonIcon
                icon={cartOutline}
                slot="icon-only"
                className={styles.font_theme}
              ></IonIcon>
              <IonText color="success">
                <div>
                  {shoppingCartData.reduce((acc, obj) => acc + obj.count, 0)}
                </div>
              </IonText>
            </IonButton>
          </IonToolbar>
        </IonHeader>
        {/* --------------------------IonContent------------------------------------ */}
        <IonContent className="ion-padding">
          {shopData.render((json) => {
            const shop = json.shop;
            if (!shop) return <p>shop not found</p>;
            return (
              <>
                <div className={styles.container} key={params.id}>
                  <div className={styles.top_container}>
                    <IonAvatar className={styles.avatar}>
                      <AppImage src={shop.avatar} />
                    </IonAvatar>
                    <div className={styles.nameAndAddress}>
                      <div className={styles.top_name}>{shop.shop_name}</div>
                      <div className={styles.address}>{shop?.address}</div>
                    </div>
                  </div>
                  {/* ---------------------------order_item_Container------------------------------------ */}
                  <div className={styles.order_item_Container}>
                    {/* --------------------------- Category Segment------------------------------------ */}
                    <div>
                      <IonSegment
                        select-on-focus={true}
                        scrollable={true}
                        className={styles.segmentBar}
                      >
                        {categories.map((category) => (
                          <IonSegmentButton
                            key={category.cat_name}
                            value={category.cat_name}
                            className={styles.segmentTag + " ion-text-wrap"}
                            onClick={(e) => {
                              let parent = e.currentTarget.closest(
                                "." + styles.container
                              );
                              let element = parent?.querySelector(
                                `[data-cat-name="${category.cat_name}"]`
                              );
                              element?.scrollIntoView({
                                behavior: "smooth",
                              });
                            }}
                          >
                            {category.cat_name}
                          </IonSegmentButton>
                        ))}
                      </IonSegment>
                    </div>
                    {/* ---------------------------Each  Category------------------------------------ */}
                  </div>
                  <div
                    className={styles.categories}
                    style={{ overflowY: "auto", height: "100px" }}
                  >
                    {categories.map((category) => (
                      <IonCard
                        data-cat-name={category.cat_name}
                        key={category.cat_name}
                        className={styles.categoryCard}
                      >
                        <IonCardHeader>
                          <IonCardTitle id={category.cat_name}>
                            <div className={styles.cat_name}>
                              {category.cat_name}
                            </div>
                          </IonCardTitle>
                        </IonCardHeader>
                        {/* ---------------------------Each  coffee------------------------------------ */}
                        <div>
                          {/* This placeholder item is to avoid iPhone 8 display the first time "specially" when unintended visual effect */}
                          <IonItem style={{ opacity: 0, height: 0 }}></IonItem>
                          {category.coffees.map((coffee) => (
                            <IonItem
                              button
                              key={coffee.id}
                              onClick={() => {
                                setSelectedCoffee(coffee);
                              }}
                              className={styles.categoryItem}
                            >
                              <IonLabel style={{ padding: "0 20px" }}>
                                <div className={styles.categoryName}>
                                  {coffee.coffee_name}
                                </div>
                                <div className={styles.categoryName}>
                                  $
                                  {coffee.variants.reduce(
                                    (acc, variant) =>
                                      Math.min(acc, variant.price),
                                    Number.MAX_VALUE
                                  )}
                                </div>
                              </IonLabel>
                            </IonItem>
                          ))}
                        </div>
                      </IonCard>
                    ))}
                  </div>
                </div>
              </>
            );
          })}
          {/* ----------------------------彈出黎既Modal------------------------------------ */}
        </IonContent>

        <IonModal
          backdropDismiss={false}
          isOpen={!!selectedCoffee}
          className={orderModalStyles.exampleModal}
        >
          {selectedCoffee ? (
            <OrderModal
              selectedCoffee={selectedCoffee}
              dismiss={() => setSelectedCoffee(null)}
            />
          ) : null}
        </IonModal>
      </IonPage>
    </>
  );
}
