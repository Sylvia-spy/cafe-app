import { useEffect } from "react";
import styles from "./MyOrder.module.scss";
import {
  IonAvatar,
  IonBackButton,
  IonButtons,
  IonCard,
  IonContent,
  IonFab,
  IonFabButton,
  IonHeader,
  IonIcon,
  IonItem,
  IonLabel,
  IonList,
  IonPage,
  IonThumbnail,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import { api_origin } from "../api";
import useGet from "../hooks/useGet";
import { useSelector } from "react-redux";
import { IRootState } from "../store/store";
import AppImage from "../components/AppImage";
import { refresh } from "ionicons/icons";

interface Order {
  id?: number;
  status?: string;
  item_id: number;
  order_id: number;
  menu_coffee_variant_id?: number;
  special_order?: string;
  is_ice?: string;
  count: number | string;
  variant_id: number;
  menu_id?: number;
  coffee_size?: string;
  price?: number | string;
  ice?: string;
  hot?: string;
  coffee_image: string;
  coffee_name?: string;
  coffee_category?: string;
  shop_id: number | string;
  cafe_id: number | string;
  cafe_name: string;
  cafe_address: string;
  cafe_avatar: string;
}

interface OrderDetail {
  id?: number;
  user_name?: string;
  phone?: number;
  birth_date?: string;
  email?: string;
  order?: Order[];
}

type MyOrder = {
  error?: string;
  user?: OrderDetail;
};
interface UIOrder {
  order_id: number;
  total_count: number;
  items: Order[];
}

export default function MyOrder() {
  const myOrderData = useGet<MyOrder>({
    name: "myOrder",
    pathname: "/myOrder",
    defaultValue: {},
  });

  const shoppingCartData = useSelector(
    (state: IRootState) => state.shoppingCart.data
  );

  useEffect(() => {
    if (shoppingCartData.length === 0) {
      myOrderData.reload();
    }
  }, [shoppingCartData]);

  const newOrders: UIOrder[] = [];
  const pendingOrders: UIOrder[] = [];
  const finishedOrders: UIOrder[] = [];

  myOrderData.state.payload.user?.order?.forEach((item) => {
    let orders =
      item.status == "New"
        ? newOrders
        : item.status == "Pending"
        ? pendingOrders
        : finishedOrders;

    //// -------------- 計total count --------------- ////
    let order = orders.find((order) => order.order_id == item.order_id);
    if (!order) {
      order = { order_id: item.order_id, total_count: 0, items: [] };
      orders.push(order);
    }
    order.total_count += +item.count;
    order.items.push(item);
  });

  //// -------------- 排次序 --------------- ////
  for (let orders of [newOrders, pendingOrders, finishedOrders]) {
    orders.sort((a, b) => b.order_id - a.order_id);
    for (let order of orders) {
      order.items.sort((a, b) => b.item_id - a.item_id);
    }
  }

  // useEffect(() => {
  //   // console.log("HELLO ORDER");
  // }, []);

  return (
    <IonPage>
      {/* ----------------------------Header------------------------------------ */}
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton className={styles.font_theme} defaultHref="/" />
          </IonButtons>
          <IonTitle className={styles.font_theme}>MyOrder</IonTitle>
        </IonToolbar>
      </IonHeader>
      {/* ----------------------------正文------------------------------------ */}
      <IonContent>
        <div>
          {myOrderData.render((json) => {
            let order = json.user?.order;
            if (!order) return <p>order not found</p>;
            return (
              <div style={{ padding: "16px" }}>
                <div className={styles.center}>
                  <div className={styles.order_header}>My Order:</div>
                </div>
                <IonFab
                  slot="fixed"
                  vertical="top"
                  horizontal="end"
                  className="fab_button"
                >
                  <IonFabButton
                    onClick={() => window.location.reload()}
                    size="small"
                    className={styles.fab}
                  >
                    <IonIcon icon={refresh}></IonIcon>
                  </IonFabButton>
                </IonFab>

                {newOrders.map((order) => (
                  <IonCard className={styles.order_card}>
                    <div style={{ padding: "0 16px" }}>
                      <div className={styles.font_theme}>
                        <div className={styles.order_ref}>
                          Order #{order.order_id}
                        </div>

                        {order.items
                          .reduce((uniqueAList: any[], item) => {
                            if (
                              uniqueAList.findIndex(
                                (v: any) => v.cafe_name === item.cafe_name
                              ) >= 0
                            ) {
                              return uniqueAList;
                            }
                            return [...uniqueAList, item];
                          }, [])
                          .map((orderItem) => (
                            <div className={styles.cafe_info}>
                              <div className={styles.center}>
                                <IonAvatar slot="start">
                                  <AppImage src={orderItem.cafe_avatar} />
                                </IonAvatar>
                              </div>

                              <div>
                                <div className={styles.cafe_name}>
                                  {orderItem.cafe_name}
                                </div>
                                <div className={styles.cafe_address}>
                                  {orderItem.cafe_address}
                                </div>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                    <div>
                      {order.items.map((orderItem) => (
                        <>
                          <IonList className={styles.order_list}>
                            <IonItem className={styles.order_item}>
                              <IonThumbnail
                                slot="start"
                                style={{
                                  margin: "0 10px ",
                                  marginLeft: "-10px",
                                }}
                              >
                                <AppImage
                                  style={{ borderRadius: "30px" }}
                                  src={orderItem.coffee_image}
                                />
                              </IonThumbnail>
                              <IonLabel>
                                <div className={styles.coffee_name}>
                                  {orderItem.coffee_name}
                                </div>
                                <div className={styles.font_theme}>
                                  ({orderItem.count} Cup)
                                </div>
                                <span className={styles.font_theme}>
                                  (
                                  {orderItem.coffee_size == "Big"
                                    ? "Venti"
                                    : orderItem.coffee_size == "Medium"
                                    ? "Grande"
                                    : "Tall"}
                                  )
                                </span>
                                <span className={styles.font_theme}>
                                  ({orderItem.ice ? "Ice" : "Hot"})
                                </span>
                              </IonLabel>
                              <IonLabel slot="end">
                                <div className={styles.font_theme}>
                                  HKD ${orderItem.price}
                                </div>
                              </IonLabel>
                            </IonItem>
                          </IonList>
                        </>
                      ))}
                    </div>
                  </IonCard>
                ))}

                <div className={styles.center}>
                  <div className={styles.order_header}>Pending:</div>
                </div>
                {pendingOrders.map((order) => (
                  <IonCard className={styles.order_card}>
                    <div style={{ padding: "0 16px" }}>
                      <div className={styles.font_theme}>
                        <div className={styles.order_ref}>
                          Order #{order.order_id}
                        </div>

                        {order.items
                          .reduce((uniqueAList: any[], item) => {
                            if (
                              uniqueAList.findIndex(
                                (v: any) => v.cafe_name === item.cafe_name
                              ) >= 0
                            ) {
                              return uniqueAList;
                            }
                            return [...uniqueAList, item];
                          }, [])
                          .map((orderItem) => (
                            <div className={styles.cafe_info}>
                              <div className={styles.center}>
                                <IonAvatar slot="start">
                                  <AppImage src={orderItem.cafe_avatar} />
                                </IonAvatar>
                              </div>

                              <div>
                                <div className={styles.cafe_name}>
                                  {orderItem.cafe_name}
                                </div>
                                <div className={styles.cafe_address}>
                                  {orderItem.cafe_address}
                                </div>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                    <div>
                      {order.items.map((orderItem) => (
                        <>
                          <IonList className={styles.order_list}>
                            <IonItem className={styles.order_item}>
                              <IonThumbnail
                                slot="start"
                                style={{
                                  margin: "0 10px ",
                                  marginLeft: "-10px",
                                }}
                              >
                                <AppImage
                                  style={{ borderRadius: "30px" }}
                                  src={orderItem.coffee_image}
                                />
                              </IonThumbnail>
                              <IonLabel>
                                <div className={styles.coffee_name}>
                                  {orderItem.coffee_name}
                                </div>
                                <div className={styles.font_theme}>
                                  ({orderItem.count}杯)
                                </div>
                                <span className={styles.font_theme}>
                                  (
                                  {orderItem.coffee_size == "Big"
                                    ? "特大"
                                    : orderItem.coffee_size == "Medium"
                                    ? "大杯"
                                    : "正常"}
                                  )
                                </span>
                                <span className={styles.font_theme}>
                                  ({orderItem.ice ? "凍飲" : "熱飲"})
                                </span>
                              </IonLabel>
                              <IonLabel slot="end">
                                <div className={styles.font_theme}>
                                  HKD ${orderItem.price}
                                </div>
                              </IonLabel>
                            </IonItem>
                          </IonList>
                        </>
                      ))}
                    </div>
                  </IonCard>
                ))}
                <div className={styles.center}>
                  <div className={styles.order_header}> Ready :</div>
                </div>
                {finishedOrders && (
                  <div>
                    {" "}
                    {finishedOrders.map((order) => (
                      <IonCard className={styles.order_card}>
                        <div style={{ padding: "0 16px" }}>
                          <div className={styles.font_theme}>
                            <div className={styles.order_ref}>
                              Order #{order.order_id}
                            </div>

                            {order.items
                              .reduce((uniqueAList: any[], item) => {
                                if (
                                  uniqueAList.findIndex(
                                    (v: any) => v.cafe_name === item.cafe_name
                                  ) >= 0
                                ) {
                                  return uniqueAList;
                                }
                                return [...uniqueAList, item];
                              }, [])
                              .map((orderItem) => (
                                <div className={styles.cafe_info}>
                                  <div className={styles.center}>
                                    <IonAvatar slot="start">
                                      <AppImage src={orderItem.cafe_avatar} />
                                    </IonAvatar>
                                  </div>

                                  <div>
                                    <div className={styles.cafe_name}>
                                      {orderItem.cafe_name}
                                    </div>
                                    <div className={styles.cafe_address}>
                                      {orderItem.cafe_address}
                                    </div>
                                  </div>
                                </div>
                              ))}
                          </div>
                        </div>
                        <div>
                          {order.items.map((orderItem) => (
                            <>
                              <IonList className={styles.order_list}>
                                <IonItem className={styles.order_item}>
                                  <IonThumbnail
                                    slot="start"
                                    style={{
                                      margin: "0 10px ",
                                      marginLeft: "-10px",
                                    }}
                                  >
                                    <AppImage
                                      style={{ borderRadius: "30px" }}
                                      src={orderItem.coffee_image}
                                    />
                                  </IonThumbnail>
                                  <IonLabel>
                                    <div className={styles.coffee_name}>
                                      {orderItem.coffee_name}
                                    </div>
                                    <div className={styles.font_theme}>
                                      ({orderItem.count}杯)
                                    </div>
                                    <span className={styles.font_theme}>
                                      (
                                      {orderItem.coffee_size == "Big"
                                        ? "特大"
                                        : orderItem.coffee_size == "Medium"
                                        ? "大杯"
                                        : "正常"}
                                      )
                                    </span>
                                    <span className={styles.font_theme}>
                                      ({orderItem.ice ? "凍飲" : "熱飲"})
                                    </span>
                                  </IonLabel>
                                  <IonLabel slot="end">
                                    <div className={styles.font_theme}>
                                      HKD ${orderItem.price}
                                    </div>
                                  </IonLabel>
                                </IonItem>
                              </IonList>
                            </>
                          ))}
                        </div>
                      </IonCard>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </IonContent>
    </IonPage>
  );
}
