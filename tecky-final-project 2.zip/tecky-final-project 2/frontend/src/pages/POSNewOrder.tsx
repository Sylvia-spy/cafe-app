import { useEffect, useState } from "react";

import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardTitle,
  IonCol,
  IonContent,
  IonFab,
  IonFabButton,
  IonIcon,
  IonItem,
  IonList,
  IonPage,
} from "@ionic/react";

import styles from "./POSNewOrder.module.scss";
import useGet from "../hooks/useGet";
import { useAPI } from "../hooks/useAPI";
import { refresh } from "ionicons/icons";

interface Order {
  id?: number;
  status?: string;
  item_id: number;
  order_id: number;
  menu_coffee_variant_id?: number;
  special_order?: string;
  is_ice?: string;
  count: number | string;
  variant_id: number;
  menu_id?: number;
  coffee_size?: string;
  price?: number | string;
  ice?: string;
  hot?: string;
  coffee_image?: string;
  coffee_name?: string;
  coffee_category?: string;
}

interface NewOrderbyUser {
  id?: number;
  user_name?: string;
  phone?: number;
  birth_date?: string;
  email?: string;
  order?: Order[];
}

type GetNewOrderByAdminPayload = {
  error?: string;
  user?: NewOrderbyUser;
};

interface UIOrder {
  order_id: number;
  total_count: number;
  items: Order[];
}

export default function POSNewOrder() {
  const getNewOrder = useGet<GetNewOrderByAdminPayload>({
    name: "getNewOrder",
    pathname: "/admin/getNewOrder",
    defaultValue: {},
  });
  const [selectedItem, setSelectedItem] = useState<UIOrder>();

  const newOrders: UIOrder[] = [];
  const pendingOrders: UIOrder[] = [];
  const finishedOrders: UIOrder[] = [];

  // useEffect(() => {}, []);
  getNewOrder.state.payload.user?.order?.forEach((item) => {
    let orders =
      item.status == "New"
        ? newOrders
        : item.status == "Pending"
        ? pendingOrders
        : item.status == "Finished"
        ? finishedOrders
        : null;
    //// -------------- 計total count --------------- ////
    let order = orders?.find((order) => order.order_id == item.order_id);
    if (!order) {
      order = { order_id: item.order_id, total_count: 0, items: [] };
      orders?.push(order);
    }
    order.total_count += +item.count;
    order.items.push(item);
  });
  //// -------------- 排次序 --------------- ////
  for (let orders of [newOrders, pendingOrders, finishedOrders]) {
    orders.sort((a, b) => a.order_id - b.order_id);
    for (let order of orders) {
      order.items.sort((a, b) => a.item_id - b.item_id);
    }
  }
  //// -------------- 轉status！--------------- ////

  const api = useAPI();
  const changeToReject = async (order_id: number) => {
    await api.fetch(`/updateOrderStatusToReject`, "POST", {
      order_id: order_id,
    });
    getNewOrder.reload();

    setSelectedItem(undefined);
  };
  const changeToNew = async (order_id: number) => {
    await api.fetch(`/updateOrderStatusToNew`, "POST", {
      order_id: order_id,
    });
    getNewOrder.reload();
    setSelectedItem(undefined);
  };
  const changeToPending = async (order_id: number) => {
    await api.fetch(`/updateOrderStatusToPending`, "POST", {
      order_id: order_id,
    });
    getNewOrder.reload();
    setSelectedItem(undefined);
  };

  const changeToFinished = async (order_id: number) => {
    await api.fetch(`/updateOrderStatusToFinished`, "POST", {
      order_id: order_id,
    });
    getNewOrder.reload();
    setSelectedItem(undefined);
  };
  const changeToReceived = async (order_id: number) => {
    await api.fetch(`/updateOrderStatusToReceived`, "POST", {
      order_id: order_id,
    });
    getNewOrder.reload();
    setSelectedItem(undefined);
  };

  return (
    <>
      <IonPage>
        <IonContent>
          <div className={styles.container}>
            <IonFab
              slot="fixed"
              vertical="top"
              horizontal="start"
              className="fab_button"
            >
              <IonFabButton
                onClick={() => window.location.reload()}
                size="small"
                className={styles.fab}
              >
                <IonIcon icon={refresh}></IonIcon>
              </IonFabButton>
            </IonFab>
            <div className={styles.leftContainer}>
              <div className={styles.center}>
                <div className={styles.order_header}>New Order:</div>
              </div>
              <IonList>
                {getNewOrder.render((json) =>
                  newOrders.map((order) => (
                    <IonItem
                      key={order.order_id}
                      onClick={() => setSelectedItem(order)}
                      className={styles.order_item}
                    >
                      <IonCol>Order # {order?.order_id}</IonCol>
                      <IonCol> Amount: {order?.total_count}</IonCol>
                      <IonButton
                        slot="end"
                        color="success"
                        size="default"
                        onClick={() => changeToPending(order.order_id)}
                      >
                        ACCEPT
                      </IonButton>
                      <IonButton
                        slot="end"
                        color="danger"
                        size="default"
                        onClick={() => changeToReject(order.order_id)}
                      >
                        REJECT
                      </IonButton>
                    </IonItem>
                  ))
                )}
              </IonList>
              <div className={styles.center}>
                <div className={styles.order_header}>Pending Order:</div>
              </div>

              <IonList>
                {getNewOrder.render((json) =>
                  pendingOrders.map((order) => (
                    <IonItem
                      key={order.order_id}
                      onClick={() => setSelectedItem(order)}
                      className={styles.order_item}
                    >
                      <IonCol>Order # {order?.order_id}</IonCol>
                      <IonCol> Amount: {order?.total_count}</IonCol>
                      <IonButton
                        slot="end"
                        color="success"
                        size="default"
                        onClick={() => changeToFinished(order.order_id)}
                      >
                        FINISH
                      </IonButton>
                      <IonButton
                        slot="end"
                        color="danger"
                        size="default"
                        onClick={() => changeToNew(order.order_id)}
                      >
                        BACK
                      </IonButton>
                    </IonItem>
                  ))
                )}
              </IonList>
              <div className={styles.center}>
                <div className={styles.order_header}>Finished Order:</div>
              </div>

              {getNewOrder.render((json) =>
                finishedOrders.map((order) => (
                  <IonItem
                    key={order.order_id}
                    onClick={() => setSelectedItem(order)}
                    className={styles.order_item}
                  >
                    <IonCol>Order # {order?.order_id}</IonCol>
                    <IonCol> Amount: {order?.total_count}</IonCol>
                    <IonButton
                      slot="end"
                      color="success"
                      size="default"
                      onClick={() => changeToReceived(order.order_id)}
                    >
                      RECEIVE
                    </IonButton>
                    <IonButton
                      slot="end"
                      color="danger"
                      size="default"
                      onClick={() => changeToPending(order.order_id)}
                    >
                      BACK
                    </IonButton>
                  </IonItem>
                ))
              )}
            </div>
            {/* ///------------ 右邊 Selected Order ------------///// */}
            <div className={styles.rightContainer}>
              {/* {selectedItem && <OrderDetailInfo order={selectedItem} />} */}
              <IonCard>
                <IonCardHeader>
                  {selectedItem?.items
                    .reduce((uniqueAList: any[], item) => {
                      if (
                        uniqueAList.findIndex(
                          (v: any) => v.status === item.status
                        ) >= 0
                      ) {
                        return uniqueAList;
                      }
                      return [...uniqueAList, item];
                    }, [])
                    .map((order) => (
                      <div className={styles.center}>
                        <div className={styles.order_header}>
                          {order.status} Order
                        </div>
                        {order.status == "New" ? (
                          <>
                            <IonButton
                              slot="end"
                              color="success"
                              size="default"
                              onClick={() => changeToPending(order.order_id)}
                            >
                              ACCEPT
                            </IonButton>
                            <IonButton
                              slot="end"
                              color="danger"
                              size="default"
                              onClick={() => changeToReject(order.order_id)}
                            >
                              REJECT
                            </IonButton>
                          </>
                        ) : order.status == "Pending" ? (
                          <>
                            <IonButton
                              slot="end"
                              color="success"
                              size="default"
                              onClick={() => changeToFinished(order.order_id)}
                            >
                              FINISH
                            </IonButton>
                            <IonButton
                              slot="end"
                              color="danger"
                              size="default"
                              onClick={() => changeToNew(order.order_id)}
                            >
                              BACK
                            </IonButton>
                          </>
                        ) : (
                          <>
                            <IonButton
                              slot="end"
                              color="success"
                              size="default"
                              onClick={() => changeToReceived(order.order_id)}
                            >
                              RECEIVE
                            </IonButton>
                            <IonButton
                              slot="end"
                              color="danger"
                              size="default"
                              onClick={() => changeToPending(order.order_id)}
                            >
                              BACK
                            </IonButton>
                          </>
                        )}
                      </div>
                    ))}
                </IonCardHeader>
                <IonCardContent>
                  <IonCard>
                    <div className={styles.order_it_em}>
                      <div className={styles.center}>
                        <div className={styles.order_id}>
                          Order # {selectedItem?.order_id}
                        </div>
                      </div>
                    </div>
                    {selectedItem?.items.map((item) => (
                      <IonCard key={item.item_id} className={styles.order_card}>
                        <IonCardHeader style={{ padding: "4px 22px" }}>
                          <IonCardTitle className={styles.font_theme}>
                            {item.coffee_name}
                          </IonCardTitle>
                        </IonCardHeader>
                        <IonItem className={styles.order_item}>
                          <div className={styles.font_theme}> 數量：</div>
                          <div slot="end"> {item.count} 杯</div>
                        </IonItem>

                        {/* ---------------------------------------------------------------- */}

                        <div>
                          <IonItem className={styles.order_item}>
                            <div> 凍飲 / 熱飲:</div>

                            <div slot="end" className={styles.font_theme}>
                              {item.ice ? "凍飲" : item.hot ? "熱飲" : "正常"}
                            </div>
                          </IonItem>

                          {/* ---------------------------------------------------------------- */}
                          <IonItem className={styles.order_item}>
                            <div> 容量:</div>
                            <div slot="end">
                              {item.coffee_size == "small"
                                ? "正常"
                                : item.coffee_size == "medium"
                                ? "大杯"
                                : "特大"}
                            </div>
                          </IonItem>
                        </div>
                        {/* ---------------------------------------------------------------- */}

                        {item.special_order && (
                          <IonItem className={styles.order_item}>
                            <div> 特別要求:</div>
                            <div slot="end"> {item.special_order}</div>
                          </IonItem>
                        )}
                      </IonCard>
                    ))}
                  </IonCard>
                </IonCardContent>
              </IonCard>
            </div>
          </div>
        </IonContent>
      </IonPage>
    </>
  );
}

// export function OrderDetailInfo({ order }: { order: UIOrder }) {
//   const getNewOrder = useGet({
//     name: "getNewOrder",
//     pathname: "/admin/getNewOrder",
//     defaultValue: {},
//   });

//   const api = useAPI();
//   const changeToReject = async (order_id: number) => {
//     await api.fetch(`/updateOrderStatusToReject`, "POST", {
//       order_id: order_id,
//     });
//     getNewOrder.reload();
//   };
//   const changeToNew = async (order_id: number) => {
//     await api.fetch(`/updateOrderStatusToNew`, "POST", {
//       order_id: order_id,
//     });
//     getNewOrder.reload();
//   };
//   const changeToPending = async (order_id: number) => {
//     await api.fetch(`/updateOrderStatusToPending`, "POST", {
//       order_id: order_id,
//     });
//     getNewOrder.reload();
//   };

//   const changeToFinished = async (order_id: number) => {
//     await api.fetch(`/updateOrderStatusToFinished`, "POST", {
//       order_id: order_id,
//     });
//     getNewOrder.reload();
//   };
//   const changeToReceived = async (order_id: number) => {
//     await api.fetch(`/updateOrderStatusToReceived`, "POST", {
//       order_id: order_id,
//     });
//     getNewOrder.reload();
//   };
//   return (
//     <>
//       <IonCard>
//         <IonCardHeader>
//           {order.items
//             .reduce((uniqueAList: any[], item) => {
//               if (
//                 uniqueAList.findIndex((v: any) => v.status === item.status) >= 0
//               ) {
//                 return uniqueAList;
//               }
//               return [...uniqueAList, item];
//             }, [])
//             .map((order) => (
//               <div className={styles.center}>
//                 <div className={styles.order_header}>{order.status} Order</div>
//                 {order.status === "New" ? (
//                   <>
//                     <IonButton
//                       slot="end"
//                       color="success"
//                       size="default"
//                       onClick={() => changeToPending(order.order_id)}
//                     >
//                       ACCEPT
//                     </IonButton>
//                     <IonButton
//                       slot="end"
//                       color="danger"
//                       size="default"
//                       onClick={() => changeToReject(order.order_id)}
//                     >
//                       REJECT
//                     </IonButton>
//                   </>
//                 ) : order.status === "Pending" ? (
//                   <>
//                     <IonButton
//                       slot="end"
//                       color="success"
//                       size="default"
//                       onClick={() => changeToFinished(order.order_id)}
//                     >
//                       FINISH
//                     </IonButton>
//                     <IonButton
//                       slot="end"
//                       color="danger"
//                       size="default"
//                       onClick={() => changeToNew(order.order_id)}
//                     >
//                       BACK
//                     </IonButton>
//                   </>
//                 ) : (
//                   <>
//                     <IonButton
//                       slot="end"
//                       color="success"
//                       size="default"
//                       onClick={() => changeToReceived(order.order_id)}
//                     >
//                       RECEIVE
//                     </IonButton>
//                     <IonButton
//                       slot="end"
//                       color="danger"
//                       size="default"
//                       onClick={() => changeToPending(order.order_id)}
//                     >
//                       BACK
//                     </IonButton>
//                   </>
//                 )}
//               </div>
//             ))}
//         </IonCardHeader>
//         <IonCardContent>
//           <IonCard>
//             <IonItem className={styles.order_it_em}>
//               <IonCardHeader style={{ padding: "4px 16px" }}>
//                 <IonCardTitle className={styles.font_theme}>
//                   Order # {order?.order_id}
//                 </IonCardTitle>
//               </IonCardHeader>
//             </IonItem>
//             {order.items.map((item) => (
//               <IonCard key={item.item_id} className={styles.order_card}>
//                 <IonCardHeader style={{ padding: "4px 16px" }}>
//                   <IonCardTitle className={styles.font_theme}>
//                     {item.coffee_name}
//                   </IonCardTitle>
//                 </IonCardHeader>
//                 <IonItem className={styles.order_item}>
//                   <div className={styles.font_theme}> 數量：</div>
//                   <div slot="end"> {item.count} 杯</div>
//                 </IonItem>

//                 {/* ---------------------------------------------------------------- */}

//                 <div>
//                   <IonItem className={styles.order_item}>
//                     <div> 凍飲 / 熱飲:</div>

//                     <div slot="end" className={styles.font_theme}>
//                       {item.ice ? "凍飲" : item.hot ? "熱飲" : "正常"}
//                     </div>
//                   </IonItem>

//                   {/* ---------------------------------------------------------------- */}
//                   <IonItem className={styles.order_item}>
//                     <div> 容量:</div>
//                     <div slot="end">
//                       {item.coffee_size == "small"
//                         ? "正常"
//                         : item.coffee_size == "medium"
//                         ? "大杯"
//                         : "特大"}
//                     </div>
//                   </IonItem>
//                 </div>
//                 {/* ---------------------------------------------------------------- */}

//                 {item.special_order && (
//                   <IonItem className={styles.order_item}>
//                     <div> 特別要求:</div>
//                     <div slot="end"> {item.special_order}</div>
//                   </IonItem>
//                 )}
//               </IonCard>
//             ))}
//           </IonCard>
//         </IonCardContent>
//       </IonCard>
//     </>
//   );
// }
