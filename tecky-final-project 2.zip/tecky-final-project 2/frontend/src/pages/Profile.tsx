import {
  IonButton,
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import { useEffect, useState } from "react";
import { api_origin } from "../api";
import useToken, { useTokenState } from "../hooks/useToken";

const Profile: React.FC = () => {
  const token = useToken();

  const [profile, setProfile] = useState();

  const { setToken } = useTokenState();

  const [checkStatus, setCheckStatus] = useState();

  function logoutClear() {
    console.log("logout ?");
    const status = setCheckStatus(checkStatus);
    setToken("");
  }

  useEffect(() => {
    fetch(api_origin + "/user/profile", {
      headers: {
        Authorization: "Bearer " + token,
      },
    })
      .then((res) => res.json())
      .then((json) => {
        if (json.error) {
          console.log("error");
        }
        if (json.profile) {
          setProfile(json.profile);
        }
      });
  }, [token]);

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>
            Profile
            <IonButton onClick={logoutClear} href={"/"}>
              Logout
            </IonButton>
          </IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>{JSON.stringify(profile)}</IonContent>
    </IonPage>
  );
};

export default Profile;
