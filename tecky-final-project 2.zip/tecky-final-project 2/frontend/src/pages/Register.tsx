import {
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
  IonListHeader,
  IonNote,
  IonPage,
  IonRadio,
  IonRadioGroup,
  IonTitle,
  IonToolbar,
  useIonToast,
} from "@ionic/react";
import { useState } from "react";
import { fetchServerDataNonGet } from "../fetchDataUtilis";
import useLoginModal from "../hooks/useLoginModal";
import { useTokenState } from "../hooks/useToken";
import styles from "./Register.module.scss";

const Register: React.FC = () => {
  return (
    <>
      <IonPage>
        <RegisterContent />
      </IonPage>
    </>
  );
};

export const RegisterContent = () => {
  //定義哂啲state
  const [registerData, setRegisterData] = useState({
    user_name: "",
    phone: "",
    gender: "",
    birth_date: "",
    hashed_pw: "",
    email: "",
  });

  const loginModal = useLoginModal();

  // const dispatch = useDispatch();
  const { setToken } = useTokenState();

  //整toast比user睇有無漏
  const [presentToast] = useIonToast();

  async function submitToServer() {
    //step 1: checking
    if (!registerData.user_name) {
      presentToast({
        message: "Missing Username!!",
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }
    if (!registerData.phone) {
      presentToast({
        message: "Missing Phone Number!!",
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }
    if (!registerData.gender) {
      presentToast({
        message: "Missing Gender!!",
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }
    if (!registerData.birth_date) {
      presentToast({
        message: "Missing birthday!!",
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }
    if (!registerData.hashed_pw) {
      presentToast({
        message: "Missing Password!!",
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }
    if (!registerData.email) {
      presentToast({
        message: "Missing Email!!",
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }

    //step 2: pass to backend
    let json = await fetchServerDataNonGet(
      "/users/register",
      "POST",
      registerData
    );

    //step 3: check 資料有無錯
    if (!json.token) {
      presentToast({
        message: "Wrong username and password!!",
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }

    //岩就去profile, 係app.tsx href寫咗
    if (json.token) {
      // dispatch(loginWithToken(json));
      setToken(json.token);
      // json.token?.find((is_admin == true?))
      presentToast({
        message: "Login successfully!!",
        duration: 3000,
        color: "success",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }
    console.log(json);
  }

  return (
    <>
      <IonContent fullscreen className={styles.background}>
        <IonList className={styles.formBox}>
          <p className={styles.title + " ion-text-center"}>Register</p>
          <IonItem className={styles.inputBox} mode="md">
            <IonLabel position="floating">Username</IonLabel>
            <IonInput
              clearInput={true}
              placeholder="Enter Your Username"
              value={registerData.user_name}
              onIonChange={(e) =>
                setRegisterData({
                  ...registerData,
                  user_name: e.detail.value || "",
                })
              }
            ></IonInput>
          </IonItem>

          <IonItem className={styles.inputBox} mode="md">
            <IonLabel position="floating">Phone</IonLabel>
            <IonInput
              type="tel"
              clearInput={true}
              placeholder="Enter Your Phone"
              value={registerData.phone}
              onIonChange={(e) =>
                setRegisterData({
                  ...registerData,
                  phone: e.detail.value || "",
                })
              }
            ></IonInput>
          </IonItem>

          <IonItem className={styles.inputBox} mode="md">
            <IonLabel position="floating">Email</IonLabel>
            <IonInput
              type="email"
              clearInput={true}
              placeholder="Enter Your Email"
              value={registerData.email}
              onIonChange={(e) =>
                setRegisterData({
                  ...registerData,
                  email: e.detail.value || "",
                })
              }
            ></IonInput>
          </IonItem>

          <IonRadioGroup
            value={registerData.gender}
            onIonChange={(e) =>
              setRegisterData({
                ...registerData,
                gender: e.detail.value || "",
              })
            }
          >
            <IonItem className={styles.inputBox}>
              Gender
              <div>
                <IonItem>
                  <IonRadio value="male" slot="start"></IonRadio>
                  <IonLabel>Male</IonLabel>
                </IonItem>
                <IonItem>
                  <IonRadio value="female" slot="start"></IonRadio>
                  <IonLabel>Female</IonLabel>
                </IonItem>
                <IonItem>
                  <IonRadio value="other" slot="start"></IonRadio>
                  <IonLabel>Other</IonLabel>
                </IonItem>
              </div>
            </IonItem>
          </IonRadioGroup>

          <IonItem className={styles.inputBox}>
            <IonLabel> Birth Date: </IonLabel>
            <IonInput
              className={styles.birth}
              type="date"
              clearInput={true}
              value={registerData.birth_date}
              onIonChange={(e) =>
                setRegisterData({
                  ...registerData,
                  birth_date: e.detail.value || "",
                })
              }
            ></IonInput>
          </IonItem>

          <IonItem className={styles.inputBox} mode="md">
            <IonLabel position="floating">Password: </IonLabel>
            <IonInput
              clearInput={true}
              type="password"
              placeholder="Enter Your Password"
              value={registerData.hashed_pw}
              onIonChange={(e) =>
                setRegisterData({
                  ...registerData,
                  hashed_pw: e.detail.value || "",
                })
              }
            ></IonInput>
          </IonItem>

          <IonButtons className={styles.buttons}>
            <IonButton onClick={submitToServer} className={styles.submit}>
              Submit
            </IonButton>
          </IonButtons>
        </IonList>

        <p className="ion-text-center">
          <IonNote>
            Already have an account?{" "}
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                loginModal.setTab("Login");
              }}
            >
              Login
            </a>
          </IonNote>
        </p>
      </IonContent>
    </>
  );
};

export default Register;
