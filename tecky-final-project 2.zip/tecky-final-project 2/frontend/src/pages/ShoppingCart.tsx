import {
  IonBackButton,
  IonButtons,
  IonCard,
  IonCardHeader,
  IonCardSubtitle,
  IonContent,
  IonFooter,
  IonHeader,
  IonIcon,
  IonItem,
  IonItemOption,
  IonItemOptions,
  IonItemSliding,
  IonLabel,
  IonList,
  IonModal,
  IonPage,
  IonThumbnail,
  IonTitle,
  IonToolbar,
  useIonRouter,
  useIonToast,
} from "@ionic/react";
import { useState } from "react";
import styles from "./ShoppingCart.module.scss";
import { useDispatch, useSelector } from "react-redux";
import { IRootState } from "../store/store";
import { useParams } from "react-router";
import useGet from "../hooks/useGet";
import { GetShopDetailsPayload } from "./MenuList";
import { api_origin, toImageUrl } from "../api";
import { trash } from "ionicons/icons";
import OrderModal from "../components/OrderModal";
import orderModalStyles from "../components/OrderModal.module.scss";
import {
  SubmitData,
  clearShoppingCart,
  removeShoppingCartItem,
} from "../store/shoppingCartSlice";
import AppImage from "../components/AppImage";
import { useAPI } from "../hooks/useAPI";
type Category = {
  cat_name: string;
  coffees: Array<Coffee>;
  element?: HTMLIonCardElement | null;
};

type Coffee = {
  id: number;
  coffee_name: string;
  variants: Variant[];
};

type Variant = {
  id: number;
  coffee_size: string;
  price: number;
  ice: boolean;
  hot: boolean;
  coffee_image: string;
};

export default function ShoppingCart() {
  const router = useIonRouter();
  // -------------- Open Modal logic -------------------------------------
  const [selectedCoffee, setSelectedCoffee] = useState<null | Coffee>(null);

  ///////////////// Redux logic //////////////////////////
  // -------------- Redux 拎資料------------------------------------
  const dispatch = useDispatch();
  const shoppingCartData = useSelector(
    (state: IRootState) => state.shoppingCart.data
  );
  // -------------- Redux DEL 資料------------------------------------
  const removeItem = (order: SubmitData) => {
    dispatch(removeShoppingCartItem(order));
  };

  // -------------- Submit All logic -------------------------------------
  const [presentToast] = useIonToast();
  const api = useAPI();

  const submitAllItem = async () => {
    // console.log("Submit All logic :", shoppingCartData);

    let json = await api.fetch(
      "/postMyOrder",
      "POST",
      shoppingCartData.map((item) => ({
        variants_id: item.variant.id,
        count: item.count,
      }))
    );
    if (json.error) {
      presentToast({
        message: "您仲未登入呀～",
        duration: 3000,
        color: "danger",
        buttons: [{ text: "OK", role: "cancel" }],
      });
      return;
    }

    presentToast({
      message: "收到您既訂單啦～懇請耐心等候",
      duration: 3000,
      color: "success",
      buttons: [{ text: "OK", role: "cancel" }],
    });

    dispatch(clearShoppingCart());
    router.push("/MyOrder");
  };
  return (
    <IonPage>
      {/* ---------------------------- Header ------------------------------------ */}
      <IonHeader>
        <IonToolbar className={styles.font_theme}>
          <IonButtons slot="start">
            <IonBackButton defaultHref="/" className={styles.font_theme} />
          </IonButtons>
          <IonTitle>Shopping Cart</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        {/* ---------------------------- 預計完成時間： ------------------------------------ */}
        <IonCard className={styles.backgrount_theme}>
          <IonCardHeader>
            <IonCardSubtitle className={styles.font_theme}>
              預計完成時間：
            </IonCardSubtitle>
            <IonCardSubtitle className={styles.font_theme}>
              10分鐘
            </IonCardSubtitle>
          </IonCardHeader>
        </IonCard>
        <IonList>
          {/* ---------------------------- 每個item ------------------------------------ */}
          {shoppingCartData.map((submitData) => (
            <IonItemSliding key={submitData.uuid}>
              <IonItem
                className={styles.item_theme}
                onClick={() => {
                  setSelectedCoffee(submitData.coffee);
                }}
              >
                <IonThumbnail slot="start">
                  <AppImage src={submitData.variant.coffee_image} />
                </IonThumbnail>
                <IonLabel>
                  <div className={styles.font_theme}>
                    <span> {submitData.coffee.coffee_name} </span>
                    <span> * {submitData.count}杯 </span>
                  </div>
                  <div className={styles.font_theme}>
                    (
                    {submitData.variant.coffee_size == "big"
                      ? "特大"
                      : submitData.variant.coffee_size == "medium"
                      ? "大杯"
                      : "正常"}
                    ) & (
                    {submitData.variant.ice
                      ? "凍飲"
                      : submitData.variant.ice
                      ? "熱飲"
                      : "正常"}
                    )
                  </div>
                </IonLabel>
                <IonLabel slot="end">
                  <div className={styles.font_theme}>
                    HK${submitData.variant.price}
                  </div>
                </IonLabel>
              </IonItem>
              <IonItemOptions side="end">
                <IonItemOption
                  onClick={() => removeItem(submitData)}
                  className={styles.del_btn}
                >
                  <IonIcon slot="icon-only" icon={trash}></IonIcon>
                </IonItemOption>
              </IonItemOptions>
            </IonItemSliding>
          ))}
        </IonList>
        <div className={styles.del_info}>{"<-向左拉可以刪除"}</div>

        <h3 className={styles.center}>
          <div className={styles.font_theme}>
            一共 {shoppingCartData.reduce((acc, obj) => acc + obj.count, 0)} 杯
          </div>
        </h3>
      </IonContent>
      {/*------------------Footer------------------------------------ */}
      <IonFooter style={{ padding: "0 " }}>
        <IonToolbar style={{ padding: "0 16px" }}>
          <div className={styles.confirmAmount}>
            <div> Total Price:</div>
            <div>
              {"HKD $ "}
              {shoppingCartData.reduce(
                (acc, obj) => acc + obj.count * obj.variant.price,
                0
              )}
            </div>
          </div>
          {/* -------------------Submit All Item------------------------------------ */}
          <div className={styles.center}>
            <button className={styles.confirmBtn} onClick={submitAllItem}>
              Confirm Order
            </button>
          </div>
        </IonToolbar>
      </IonFooter>

      <IonModal
        backdropDismiss={false}
        isOpen={!!selectedCoffee}
        className={orderModalStyles.exampleModal}
      >
        {selectedCoffee ? (
          <OrderModal
            selectedCoffee={selectedCoffee}
            dismiss={() => setSelectedCoffee(null)}
          />
        ) : null}
      </IonModal>
    </IonPage>
  );
}
