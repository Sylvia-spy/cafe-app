import { useState } from "react";
import {
  IonAvatar,
  IonButton,
  IonCard,
  IonContent,
  IonHeader,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
  IonListHeader,
  IonPage,
  IonThumbnail,
  IonTitle,
  IonToggle,
  IonToolbar,
  useIonToast,
} from "@ionic/react";
import styles from "./UpdateCafeInfo.module.scss";
import Icon from "../logo/Icon";
import useGet from "../hooks/useGet";
import { Point } from "leaflet";
import { OpeningHour } from "./AllCafeInfo";
import { useParams } from "react-router";
import { features } from "./features";
import { useDispatch } from "react-redux";
import { useTokenState } from "../hooks/useToken";
import { useAPI } from "../hooks/useAPI";
import AppImage from "../components/AppImage";

type CafeDetail = {
  id: number;
  shop_name: string;
  tel?: string;
  latlng?: Point[];
  instagram?: string;
  facebook?: string;
  address: string;
  avatar: string;
  image: string;
  openingHours: OpeningHour[];

  features: {
    name: string;
    has: number | null;
  }[];
};

type GetShopDetailsPayload = { error?: string; cafeProfile?: CafeDetail };

export default function UpdateCafeInfo() {
  const shopData = useGet<GetShopDetailsPayload>({
    name: "cafeProfile",
    pathname: "/admin/profile",
    defaultValue: {},
  });
  const shop_id = useParams<{ id: string }>().id;

  const dispatch = useDispatch();

  const api = useAPI();

  const [presentToast] = useIonToast();

  // --------------------- logout -------------------------------------------

  const { setToken } = useTokenState();
  const [checkStatus, setCheckStatus] = useState();

  function logoutClear() {
    console.log("logout ?");
    const status = setCheckStatus(checkStatus);
    setToken("");
  }
  // --------------------- other -------------------------------------------

  const now = new Date();
  const weekDay = now.getDay();

  async function updateBasicInformation() {
    let profile = shopData.state.payload.cafeProfile;
    let json = await api.fetch("/admin/shop/basicInformation", "PATCH", {
      name: profile?.shop_name,
      address: profile?.address,
      tel: profile?.tel,
      instagram: profile?.instagram,
      facebook: profile?.facebook,
    });
    if (json.error) {
      presentToast({
        message: json.error,
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }
    presentToast({
      message: "Updated Cafe Information Successfully!!",
      duration: 3000,
      color: "success",
      buttons: [{ text: "Dismiss", role: "cancel" }],
    });
    shopData.reload();
    return;
  }

  async function updateOpeningHours() {
    let openingHours = shopData.state.payload.cafeProfile?.openingHours;
    let json = await api.fetch(
      "/admin/shop/operationTime",
      "PATCH",
      openingHours
    );
    if (json.error) {
      presentToast({
        message: json.error,
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }
    presentToast({
      message: "Updated Operation Time Successfully!!",
      duration: 3000,
      color: "success",
      buttons: [{ text: "Dismiss", role: "cancel" }],
    });
    shopData.reload();
    return;
  }

  async function updateFeatures() {
    let json = await api.fetch(
      "/admin/shop/features",
      "PATCH",
      shopData.state.payload.cafeProfile?.features
        .filter((feature) => feature.has)
        .map((feature) => feature.name)
    );
    if (json.error) {
      presentToast({
        message: json.error,
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }
    presentToast({
      message: "Updated Features Successfully!!",
      duration: 3000,
      color: "success",
      buttons: [{ text: "Dismiss", role: "cancel" }],
    });
    shopData.reload();
    return;
  }
  return (
    <>
      <IonPage>
        <IonHeader className="ion-text-center">
          <IonToolbar>
            <IonTitle style={{ fontFamily: "Optima, sans-serif" }}>
              Manage your Cafe Profile
            </IonTitle>
            <IonButton
              slot="end"
              onClick={logoutClear}
              href={"/"}
              className={styles.exit}
            >
              Logout
            </IonButton>
          </IonToolbar>
        </IonHeader>
        <IonContent fullscreen>
          {/* ///////////////////check bug///////////////////// */}
          {/* {JSON.stringify(shopData)} */}
          {/* ///////////////////check bug///////////////////// */}

          <div>
            <div id="appShow">
              {shopData.render((json) => {
                const shop = json.cafeProfile;
                if (!shop) return <p>shop not found</p>;
                return (
                  <div key={shop.id} className={styles.main_Container}>
                    <div className={styles.left_Container}>
                      <IonCard className={styles.card}>
                        <div className={styles.left_Container_header}>
                          <div> Background Image</div>
                        </div>
                        <div className={styles.center}>
                          <AppImage className={styles.image} src={shop.image} />
                        </div>
                        <div className={styles.center}>
                          <IonButton
                            onClick={updateBasicInformation}
                            className={styles.update_btn}
                          >
                            <div> Updated</div>
                          </IonButton>
                        </div>
                      </IonCard>

                      <IonCard
                        className={styles.card}
                        style={{ height: "150px" }}
                      >
                        <div className={styles.left_Container_header}>
                          Avatar
                          <div className={styles.center}>
                            <IonAvatar>
                              <AppImage
                                className={styles.avatar}
                                src={shop.avatar}
                              />
                            </IonAvatar>
                          </div>{" "}
                          <div className={styles.center}>
                            <IonButton
                              onClick={updateBasicInformation}
                              className={styles.update_btn}
                            >
                              Updated
                            </IonButton>
                          </div>
                        </div>
                      </IonCard>
                    </div>

                    <div className={styles.middle_Container}>
                      {/* //////////////////////////////////Basic Information////////////////////////////////// */}
                      <IonList className={styles.middle_Container_list}>
                        <IonListHeader>
                          <div className={styles.middle_Container_header}>
                            Basic Information
                          </div>
                          <IonButton
                            onClick={updateBasicInformation}
                            className={styles.middle_Container_update_btn}
                          >
                            Updated
                          </IonButton>
                        </IonListHeader>

                        <IonItem>
                          <IonLabel>Shop Name: </IonLabel>
                          <IonInput
                            value={shop.shop_name}
                            onIonChange={(e) =>
                              shopData.setState({
                                ...shopData.state,
                                payload: {
                                  ...shopData.state.payload,
                                  cafeProfile: {
                                    ...shop,
                                    shop_name: e.detail.value || "",
                                  },
                                },
                              })
                            }
                          />
                        </IonItem>
                        <IonItem>
                          <IonLabel>Address: </IonLabel>
                          <IonInput
                            value={shop.address}
                            onIonChange={(e) =>
                              shopData.setState({
                                ...shopData.state,
                                payload: {
                                  ...shopData.state.payload,
                                  cafeProfile: {
                                    ...shop,
                                    address: e.detail.value || "",
                                  },
                                },
                              })
                            }
                          ></IonInput>
                        </IonItem>
                        <IonItem>
                          <IonLabel>Tel: </IonLabel>
                          <IonInput
                            value={shop.tel}
                            onIonChange={(e) =>
                              shopData.setState({
                                ...shopData.state,
                                payload: {
                                  ...shopData.state.payload,
                                  cafeProfile: {
                                    ...shop,
                                    tel: e.detail.value || "",
                                  },
                                },
                              })
                            }
                          ></IonInput>
                        </IonItem>
                        <IonItem>
                          <IonLabel>Instagram: </IonLabel>
                          <IonInput
                            value={shop.instagram}
                            onIonChange={(e) =>
                              shopData.setState({
                                ...shopData.state,
                                payload: {
                                  ...shopData.state.payload,
                                  cafeProfile: {
                                    ...shop,
                                    instagram: e.detail.value || "",
                                  },
                                },
                              })
                            }
                          ></IonInput>
                        </IonItem>
                        <IonItem>
                          <IonLabel>Facebook: </IonLabel>
                          <IonInput
                            value={shop.facebook}
                            onIonChange={(e) =>
                              shopData.setState({
                                ...shopData.state,
                                payload: {
                                  ...shopData.state.payload,
                                  cafeProfile: {
                                    ...shop,
                                    facebook: e.detail.value || "",
                                  },
                                },
                              })
                            }
                          ></IonInput>
                        </IonItem>
                      </IonList>
                      {/* //////////////////////////////////My operation time////////////////////////////////// */}
                      <IonList className={styles.middle_Container_list}>
                        <IonListHeader>
                          <div className={styles.middle_Container_header}>
                            My Operation Time{" "}
                          </div>

                          <IonButton
                            onClick={updateOpeningHours}
                            className={styles.middle_Container_update_btn}
                          >
                            Updated
                          </IonButton>
                        </IonListHeader>

                        {[
                          "Sunday",
                          "Monday",
                          "Tuesday",
                          "Wednesday",
                          "Thursday",
                          "Friday",
                          "Saturday",
                        ].map((day, weekday) => {
                          let openingHours = shop?.openingHours.find(
                            (item) => item.weekday == weekday
                          );
                          let startTime = openingHours?.start_time.replace(
                            /:00$/,
                            ""
                          );
                          let endTime = openingHours?.end_time.replace(
                            /:00$/,
                            ""
                          );
                          return (
                            <IonItem key={day}>
                              <IonLabel style={{ minWidth: "6rem" }}>
                                {day}
                              </IonLabel>
                              <div
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                }}
                              >
                                <IonInput
                                  type="time"
                                  value={startTime}
                                  onIonChange={(e) => {
                                    let value = e.detail.value + ":00";
                                    let profile =
                                      shopData.state.payload.cafeProfile;
                                    if (!profile) {
                                      return;
                                    }
                                    shopData.setState({
                                      ...shopData.state,
                                      payload: {
                                        ...shopData.state.payload,
                                        cafeProfile: {
                                          ...profile,
                                          openingHours:
                                            profile.openingHours.map((hours) =>
                                              hours == openingHours
                                                ? {
                                                    ...hours,
                                                    start_time: value,
                                                  }
                                                : hours
                                            ),
                                        },
                                      },
                                    });
                                  }}
                                ></IonInput>
                                <span style={{ margin: "1rem" }}>to</span>
                                <IonInput
                                  type="time"
                                  value={endTime}
                                  onIonChange={(e) => {
                                    let value = e.detail.value + ":00";
                                    let profile =
                                      shopData.state.payload.cafeProfile;
                                    if (!profile) {
                                      return;
                                    }
                                    shopData.setState({
                                      ...shopData.state,
                                      payload: {
                                        ...shopData.state.payload,
                                        cafeProfile: {
                                          ...profile,
                                          openingHours:
                                            profile.openingHours.map((hours) =>
                                              hours == openingHours
                                                ? {
                                                    ...hours,
                                                    end_time: value,
                                                  }
                                                : hours
                                            ),
                                        },
                                      },
                                    });
                                  }}
                                ></IonInput>
                              </div>
                            </IonItem>
                          );
                        })}
                      </IonList>
                    </div>
                    {/* //////////////////////////////////Features Information////////////////////////////////// */}
                    <div className={styles.right_container}>
                      <IonList className={styles.right_container_list}>
                        <IonListHeader
                          className={styles.right_container_header}
                        >
                          Features
                          <IonButton
                            onClick={updateFeatures}
                            className={styles.right_container_list_update_btn}
                          >
                            Update
                          </IonButton>
                        </IonListHeader>
                        {features.map((featureGroup) => (
                          <IonList key={featureGroup.category}>
                            <IonHeader
                              style={{ padding: "0 16px", fontSize: "30px" }}
                            >
                              {featureGroup.category}
                            </IonHeader>
                            {featureGroup.data.map((feature) => (
                              <IonItem key={feature.feature_name}>
                                <IonThumbnail slot="start">
                                  <AppImage src={feature.icon}></AppImage>
                                </IonThumbnail>
                                <IonLabel>{feature.title}</IonLabel>
                                <IonToggle
                                  className={styles.right_container_toggle}
                                  checked={
                                    !!shop?.features.find(
                                      (DBfeature) =>
                                        DBfeature.name == feature.feature_name
                                    )?.has
                                  }
                                  onIonChange={(e) => {
                                    let cafeProfile =
                                      shopData.state.payload.cafeProfile;
                                    if (!cafeProfile) return;
                                    let features = [...cafeProfile.features];
                                    let idx = features.findIndex(
                                      (f) => f.name == feature.feature_name
                                    );
                                    let has = e.detail.checked ? shop.id : null;
                                    if (idx == -1) {
                                      features.push({
                                        name: feature.feature_name,
                                        has,
                                      });
                                    } else {
                                      features[idx] = {
                                        name: feature.feature_name,
                                        has,
                                      };
                                    }
                                    shopData.setState({
                                      ...shopData.state,
                                      payload: {
                                        ...shopData.state.payload,
                                        cafeProfile: {
                                          ...cafeProfile,
                                          features,
                                        },
                                      },
                                    });
                                  }}
                                ></IonToggle>
                              </IonItem>
                            ))}
                          </IonList>
                        ))}
                      </IonList>
                    </div>

                    <IonList hidden>
                      {features.map((featureGroup) => (
                        <>
                          <IonHeader> {featureGroup.category} </IonHeader>
                          <IonItem className={styles.signature}>
                            <div>
                              {featureGroup.data.map((feature) => (
                                <div key={feature.feature_name}>
                                  <span
                                    className={
                                      //db: shop 有無 feature.name => 對上面signatureArr的feature_name
                                      shop?.features.find(
                                        (DBfeature) =>
                                          DBfeature.name == feature.feature_name
                                      )?.has
                                        ? styles.each_signature
                                        : styles.no_signature
                                    }
                                  >
                                    <Icon icon={feature.icon}></Icon>
                                    <span className={styles.signature_content}>
                                      {feature.title}
                                    </span>
                                  </span>
                                </div>
                              ))}
                            </div>
                          </IonItem>
                        </>
                      ))}
                    </IonList>
                  </div>
                );
              })}
            </div>
          </div>
        </IonContent>
      </IonPage>
    </>
  );
}
