import { useState } from "react";
import {
  IonButton,
  IonButtons,
  IonCard,
  IonCardSubtitle,
  IonContent,
  IonHeader,
  IonIcon,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
  IonPage,
  IonTitle,
  IonToolbar,
  useIonToast,
} from "@ionic/react";
import styles from "./UpdatePost.module.scss";
import useGet from "../hooks/useGet";
import { image, trashOutline } from "ionicons/icons";
import { selectImage } from "@beenotung/tslib/file";
import { format_byte } from "@beenotung/tslib/format";
import { compressMobilePhoto, dataURItoBlob } from "@beenotung/tslib/image";
import { useAPI } from "../hooks/useAPI";
import AppImage from "../components/AppImage";

interface PostRecord {
  id: number;
  shop_id: number;
  image: string | null;
  title: string;
  content: string;
}

type GetPostByAdminPayload = {
  error?: string;
  allPost?: PostRecord[];
};
export default function CafePostManage() {
  const [newPostData, setNewPostData] = useState({
    title: "",
    content: "",
    imagePreview: "",
    file: null as File | null,
  });
  const api = useAPI();

  const [presentToast] = useIonToast();

  async function submitToServer() {
    if (!newPostData.title) {
      presentToast({
        message: "Missing Title!!",
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }
    if (!newPostData.content) {
      presentToast({
        message: "Missing Content!!",
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }
    if (!newPostData.file) {
      presentToast({
        message: "Missing Image!!",
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });

      return;
    }
    let formData = new FormData();
    formData.set("title", newPostData.title);
    formData.set("content", newPostData.content);
    formData.set("image", newPostData.file);
    let json = await api.upload(`/admin/shop/posts`, "POST", formData);

    if (json.error) {
      presentToast({
        message: json.error,
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }
    if (!json.error) {
      presentToast({
        message: "Created Post Successfully!!",
        duration: 3000,
        color: "warning",
        buttons: [{ text: "Dismiss", role: "cancel" }],
      });
      setNewPostData({
        title: "",
        content: "",
        imagePreview: "",
        file: null,
      });
      allPost.reload();
      return;
    }
  }

  async function pickImage() {
    let [file] = await selectImage();
    if (!file) return;
    let dataUrl = await compressMobilePhoto({
      image: file,
      maximumSize: 200 * 1024,
    });
    let blob = dataURItoBlob(dataUrl);
    file = new File([blob], file.name, {
      lastModified: file.lastModified,
      type: blob.type,
    });
    setNewPostData({ ...newPostData, imagePreview: dataUrl, file });
  }

  const allPost = useGet<GetPostByAdminPayload>({
    name: "shops",
    pathname: "/admin/getAllPost",
    defaultValue: {},
  });

  async function deletePost(id: number) {
    let json = await api.fetch("/admin/post/" + id, "DELETE", {});
    if (json.error) {
      presentToast({
        message: json.error,
        duration: 3000,
        color: "danger",
        buttons: [{ text: "cancel", role: "cancel" }],
      });
      return;
    }
    if (!json.error) {
      presentToast({
        message: "Deleted Post Successfully!!",
        duration: 3000,
        color: "success",
        buttons: [{ text: "Dismiss", role: "cancel" }],
      });
    }
    allPost.reload();
    return;
  }

  return (
    <>
      <IonPage>
        <IonHeader className="ion-text-center">
          <IonToolbar>
            <IonTitle style={{ fontFamily: "Optima, sans-serif" }}>
              Manage your Cafe Post
            </IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonContent>
          <div>
            <div className={styles.left_Container}>
              <IonCard className="ion-padding">
                <div className={styles.post_id}>Add New Post: </div>
                <IonList>
                  <IonItem>
                    <IonLabel position="stacked">Title </IonLabel>
                    <IonInput
                      clearInput={true}
                      type="text"
                      value={newPostData.title}
                      onIonChange={(e) =>
                        setNewPostData({
                          ...newPostData,
                          title: e.detail.value || "",
                        })
                      }
                    ></IonInput>
                  </IonItem>
                  <IonItem>
                    <IonLabel position="stacked">Content </IonLabel>
                    <IonInput
                      clearInput={true}
                      type="text"
                      value={newPostData.content}
                      onIonChange={(e) =>
                        setNewPostData({
                          ...newPostData,
                          content: e.detail.value || "",
                        })
                      }
                    ></IonInput>
                  </IonItem>
                  <IonItem>
                    <IonLabel position="stacked">Image </IonLabel>
                    <IonInput
                      clearInput
                      readonly
                      value={
                        newPostData.file
                          ? `${newPostData.file.name} (${format_byte(
                              newPostData.file.size
                            )})`
                          : ""
                      }
                      type="text"
                    ></IonInput>
                    <IonButtons slot="end">
                      <IonButton onClick={pickImage}>
                        <IonIcon slot="icon-only" icon={image}></IonIcon>
                      </IonButton>
                    </IonButtons>
                  </IonItem>
                  <AppImage
                    src={newPostData.imagePreview}
                    className="ion-padding"
                  ></AppImage>
                  <IonButton
                    onClick={submitToServer}
                    className={styles.submit_button}
                  >
                    Upload
                  </IonButton>
                </IonList>
              </IonCard>
            </div>
            <div className={styles.right_Container}>
              {allPost.render((json) => {
                return json.allPost?.map((post) => (
                  <IonCard key={post.id} style={{ padding: "16px" }}>
                    <div className={styles.post_id + " ion-text-center"}>
                      POST #{post.id}
                      <IonButtons className={styles.buttons}>
                        <IonButton
                          color="danger"
                          onClick={() => deletePost(post.id)}
                        >
                          <IonIcon slot="icon-only" icon={trashOutline} />
                        </IonButton>
                      </IonButtons>
                    </div>
                    <AppImage
                      src={post.image}
                      className={styles.postImage}
                    ></AppImage>
                    <IonCardSubtitle className={styles.color_and_font}>
                      {post.title}
                    </IonCardSubtitle>
                    <div className={styles.color_and_font}>{post.content} </div>
                  </IonCard>
                ));
              })}
            </div>
          </div>
        </IonContent>
      </IonPage>
    </>
  );
}
