import { icons } from "../logo";

export let features = [
  {
    category: "Savour",
    data: [
      {
        feature_name: "bean_for_sale",
        title: "Bean Sale",
        icon: icons.coffee_beans,
      },
      {
        feature_name: "milk_choices",
        title: "Milk Choices",
        icon: icons.milk,
      },
      {
        feature_name: "decaf",
        title: "Decaf",
        icon: icons.decaf,
      },
      {
        feature_name: "awarded",
        title: "Awarded",
        icon: icons.award,
      },
    ],
  },
  {
    category: "Amenities",
    data: [
      {
        feature_name: "tables_seats",
        title: "Tables & Seats",
        icon: icons.armchair,
      },
      {
        feature_name: "outdoor",
        title: "Outdoor",
        icon: icons.chairs,
      },
      {
        feature_name: "bright",
        title: "Bright",
        icon: icons.brightness,
      },
      {
        feature_name: "socket",
        title: "Sockets",
        icon: icons.socket,
      },
      {
        feature_name: "wifi",
        title: "WIFI",
        icon: icons.wifi,
      },
      {
        feature_name: "parking",
        title: "Parking",
        icon: icons.parking_area,
      },
      {
        feature_name: "washroom",
        title: "Washroom",
        icon: icons.toilet,
      },
    ],
  },

  {
    category: "Vibes",
    data: [
      {
        feature_name: "CBD",
        title: "CBD",
        icon: icons.cbd,
      },
      {
        feature_name: "vibes",
        title: "Vibes",
        icon: icons.joy,
      },
      {
        feature_name: "pets_friendly",
        title: "Pets Friendly",
        icon: icons.petfriendly,
      },
      {
        feature_name: "pets_in_store",
        title: "Pets In Store",
        icon: icons.petwithin,
      },
      {
        feature_name: "BYOC",
        title: "BYOC",
        icon: icons.solocup,
      },
    ],
  },
  {
    category: "Gourmet",
    data: [
      {
        feature_name: "meals",
        title: "Meals",
        icon: icons.food,
      },
      {
        feature_name: "sweets_bites",
        title: "Snacks",
        icon: icons.snake,
      },
      {
        feature_name: "vegan",
        title: "Vegan",
        icon: icons.vegan,
      },
      {
        feature_name: "vegetarian",
        title: "Vegetarian",
        icon: icons.vegeterian,
      },
    ],
  },
];
