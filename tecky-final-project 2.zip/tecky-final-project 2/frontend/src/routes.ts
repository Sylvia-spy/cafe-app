//集中改個routes, 咁typescript 會提我
//eg. routerLink={routes.cafeDetail(shop.id)}

export let routes = {
  home: "/home",
  cafeList: "/allCafeInfo",
  cafeDetail: (id: number | string) => "/shops/" + id,
  mapPage: "/map",
  profile: "/profile",
  login: "/login",
  register: "/Register",
  updateCafeInfo: "/admin/profile",
  POSNewOrder: "/POSNewOrder",
  updatePost: "/updatePost",
  menuList: (id: number | string) => "/shops/" + id + "/menuList",
  ShoppingCart: "/ShoppingCart",
  MyOrder: "/MyOrder",
};
