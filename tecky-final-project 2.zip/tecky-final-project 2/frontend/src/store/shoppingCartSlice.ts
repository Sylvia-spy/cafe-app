import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { uuidGen } from "./uuidUtilis";

type Coffee = {
  id: number;
  coffee_name: string;
  variants: Variant[];
};

type Variant = {
  id: number;
  coffee_size: string;
  price: number;
  ice: boolean;
  hot: boolean;
  coffee_image: string;
};
//----- * 同於shoppingCart Slice * --- change to Confirm Data--------------------------------------
export type SubmitData = {
  uuid: string;
  coffee: Coffee;
  variant: Variant;
  count: number;
};
export interface ShoppingCartState {
  data: SubmitData[];
}

const initialState: ShoppingCartState = {
  data: [],
};

const ShoppingCartSlice = createSlice({
  name: "ShoppingCart",
  initialState: initialState,
  reducers: {
    addShoppingCartItem(
      state: ShoppingCartState,
      action: PayloadAction<SubmitData>
    ) {
      state.data.push({
        ...action.payload,
        uuid: uuidGen(),
      });

      // let data = JSON.stringify(state.data);
    },
    removeShoppingCartItem(
      state: ShoppingCartState,
      action: PayloadAction<SubmitData>
    ) {
      // console.log("PPPP", action.payload);
      const targetId = action.payload.uuid;

      state.data = state.data.filter((v) => v.uuid !== targetId);

      // state.data.slice(action.payload.variant.id, 1);
      // let data = JSON.stringify(state.data);
    },
    clearShoppingCart(state: ShoppingCartState) {
      state.data = [];
    },
  },
});

export const {
  addShoppingCartItem,
  removeShoppingCartItem,
  clearShoppingCart,
} = ShoppingCartSlice.actions;
export default ShoppingCartSlice.reducer;
