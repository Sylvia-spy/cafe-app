import { configureStore } from "@reduxjs/toolkit";
import userReducer from "./userSlice";
import shoppingCartReducer from "./shoppingCartSlice";

// Config a store to index.tsx, for Provider to use
export let store = configureStore({
  reducer: {
    // user: userReducer,
    shoppingCart: shoppingCartReducer,
  },
});

export type IRootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
