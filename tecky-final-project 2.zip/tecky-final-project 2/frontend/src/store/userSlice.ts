//reduce: function to change the state
//state: shared variables, userSlice.ts
//action: how to change the state according to reduce
//store: combined state storages
//RTK combined reduce and action in createSlice

import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import jwtDecode from "jwt-decode";

//對番backend user.service 嘅JWTPayload
export type JWTPayload = {
  id: number;
  is_admin: boolean;
  username: string;
  is_cafe_admin: boolean;
};

//login register個時睇吓有無token同JWTPayload嘅資料
export interface UserState {
  token?: string;
  user?: JWTPayload;
}

//一開始就無野
function initialState(): UserState {
  try {
    let token = localStorage.getItem("token");

    if (token) {
      return { token, user: jwtDecode(token) };
    }
  } catch (error) {
    // invalid token?
  }

  return {};
}

//收到token就做野, 唔洗理係login定register
const userSlice = createSlice({
  name: "users",
  initialState: initialState(),
  //how to change the value of array
  reducers: {
    //loginWithToken係個action
    loginWithToken(state: UserState, action: PayloadAction<{ token: string }>) {
      //儲低token

      console.log("action.payload.token", action.payload.token);

      localStorage.setItem("token", action.payload.token);
      state.token = action.payload.token;
      //拆個token
      state.user = jwtDecode(action.payload.token);

      setInterval(
        () => localStorage.setItem("token", action.payload.token),
        1000
      );
      //儲低user 係咪admin
    },

    logout(state: UserState, action: PayloadAction<{ token: string }>) {
      console.log("logout...");
      localStorage.removeItem("token");
      state.token = undefined;
      state.user = undefined;
    },
  },
});

export const { loginWithToken, logout } = userSlice.actions;
export default userSlice.reducer;
